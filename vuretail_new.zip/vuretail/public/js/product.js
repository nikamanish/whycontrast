window.PRODUCT_SLUGS = {
  VUSTORE_GLO_LED_TV_43: 'vu-glo-led-tv',
  VUSTORE_GLO_LED_TV_50: 'vu-glo-led-tv-50',
  VUSTORE_GLO_LED_TV_55: 'vu-glo-led-tv-55',
  VUSTORE_GLO_LED_TV_65: 'vu-glo-led-tv-65',
  VUSTORE_MASTERPIECE_TV_55: 'vu-masterpiece-tv',
  VUSTORE_MASTERPIECE_TV_65: 'vu-masterpiece-tv-65',
  VUSTORE_MASTERPIECE_TV_75: 'vu-masterpiece-tv-75',
  VUSTORE_PREMIUM_GOOGLE_OS_TV_43: 'vu-premium-4k-tv',
  VUSTORE_PREMIUM_GOOGLE_OS_TV_55: 'vu-premium-google-os-4k-tv-55',
  VUSTORE_PREMIUM_FHD_TV_43: 'vu-premium-fhd-tv',
  VUSTORE_MASTERPIECE_QLED_TV_85: 'vu-masterpiece-qled-tv-85',
  VUSTORE_MASTERPIECE_QLED_TV_98: 'vu-masterpiece-qled-tv-98',
  VUSTORE_CINEMA_2024_43: 'vu-cinema-tv-43-2024',
  VUSTORE_CINEMA_2024_55: 'vu-cinema-tv-55-2024',
};

window.COMING_SOON_PRODUCTS = [
  PRODUCT_SLUGS.VUSTORE_PREMIUM_GOOGLE_OS_TV_55,
  // PRODUCT_SLUGS.VUSTORE_GLO_LED_TV_55,
  // PRODUCT_SLUGS.VUSTORE_GLO_LED_TV_65,
];
window.DIWALI_LAUNCH_PRODUCTS = [
  // PRODUCT_SLUGS.VUSTORE_GLO_LED_TV_43
];
window.VIEW_ONLY_PRODUCTS = [
  // PRODUCT_SLUGS.VUSTORE_GLO_LED_TV_43,
  // PRODUCT_SLUGS.VUSTORE_GLO_LED_TV_50,
  // PRODUCT_SLUGS.VUSTORE_GLO_LED_TV_55,
  // PRODUCT_SLUGS.VUSTORE_GLO_LED_TV_65,
  PRODUCT_SLUGS.VUSTORE_PREMIUM_GOOGLE_OS_TV_55,
];

window.RESOLUTION_MAP = {
  [PRODUCT_SLUGS.VUSTORE_GLO_LED_TV_43]: '4K 3840 x 2160 Pixels',
  [PRODUCT_SLUGS.VUSTORE_GLO_LED_TV_50]: '4K 3840 x 2160 Pixels',
  [PRODUCT_SLUGS.VUSTORE_GLO_LED_TV_55]: '4K 3840 x 2160 Pixels',
  [PRODUCT_SLUGS.VUSTORE_GLO_LED_TV_65]: '4K 3840 x 2160 Pixels',
  [PRODUCT_SLUGS.VUSTORE_MASTERPIECE_TV_55]: '4K 3824 x 2160 Pixels',
  [PRODUCT_SLUGS.VUSTORE_MASTERPIECE_TV_65]: '4K 3824 x 2160 Pixels',
  [PRODUCT_SLUGS.VUSTORE_MASTERPIECE_TV_75]: '4K 3824 x 2160 Pixels',
  [PRODUCT_SLUGS.VUSTORE_PREMIUM_GOOGLE_OS_TV_43]: '4K 3824 x 2160 Pixels',
  [PRODUCT_SLUGS.VUSTORE_PREMIUM_GOOGLE_OS_TV_55]: '4K 3824 x 2160 Pixels',
  [PRODUCT_SLUGS.VUSTORE_MASTERPIECE_QLED_TV_85]: '4K 3824 x 2160 Pixels',
  [PRODUCT_SLUGS.VUSTORE_MASTERPIECE_QLED_TV_98]: '4K 3824 x 2160 Pixels',
  [PRODUCT_SLUGS.VUSTORE_CINEMA_2024_43]: '4K 3824 x 2160 Pixels',
  [PRODUCT_SLUGS.VUSTORE_CINEMA_2024_55]: '4K 3824 x 2160 Pixels',
  [PRODUCT_SLUGS.VUSTORE_PREMIUM_FHD_TV_43]: 'Full HD 1920 x 1080 Pixels',
};

window.OS_MAP = {
  [PRODUCT_SLUGS.VUSTORE_GLO_LED_TV_43]: 'Google TV OS',
  [PRODUCT_SLUGS.VUSTORE_GLO_LED_TV_50]: 'Google TV OS',
  [PRODUCT_SLUGS.VUSTORE_GLO_LED_TV_55]: 'Google TV OS',
  [PRODUCT_SLUGS.VUSTORE_GLO_LED_TV_65]: 'Google TV OS',
  [PRODUCT_SLUGS.VUSTORE_CINEMA_2024_43]: 'webOS',
  [PRODUCT_SLUGS.VUSTORE_CINEMA_2024_55]: 'webOS',
  //   [PRODUCT_SLUGS.PREMIUM_WEBOS_4K_TV_43]: 'webOS',
  //   [PRODUCT_SLUGS.PREMIUM_WEBOS_4K_TV_55]: 'webOS',
  [PRODUCT_SLUGS.VUSTORE_PREMIUM_FHD_TV_43]: 'Official Android',
  [PRODUCT_SLUGS.VUSTORE_PREMIUM_GOOGLE_OS_TV_43]: 'Google OS',
  [PRODUCT_SLUGS.VUSTORE_PREMIUM_GOOGLE_OS_TV_43]: 'Google OS',
};

window.VU_GROUP_SLUGS = {
  VUSTORE_CINEMA_TV_2024: 'vu-cinema-tv-2024',
  VUSTORE_MASTERPIECE_GLO_QLED_TV: 'vu-masterpiece-tv',
  VUSTORE_GLO_LED_TV: 'vu-glo-led-tv',
  VUSTORE_PREMIUM_GOOGLE_OS_TV: 'vu-premium-google-os-4k-tv', //
  VUSTORE_PREMIUM_FHD_TV: 'vu-premium-fhd-tv', //
  VUSTORE_MASTERPIECE_QLED_TV: 'vu-masterpiece-qled-tv', //
};

window.VU_GROUP_PRODUCT_MAP = {
  [VU_GROUP_SLUGS.VUSTORE_CINEMA_TV_2024]: [
    PRODUCT_SLUGS.VUSTORE_CINEMA_2024_43,
    PRODUCT_SLUGS.VUSTORE_CINEMA_2024_55,
  ],
  [VU_GROUP_SLUGS.VUSTORE_GLO_LED_TV]: [
    PRODUCT_SLUGS.VUSTORE_GLO_LED_TV_43,
    PRODUCT_SLUGS.VUSTORE_GLO_LED_TV_50,
    PRODUCT_SLUGS.VUSTORE_GLO_LED_TV_55,
    PRODUCT_SLUGS.VUSTORE_GLO_LED_TV_65,
  ],
  [VU_GROUP_SLUGS.VUSTORE_MASTERPIECE_GLO_QLED_TV]: [
    PRODUCT_SLUGS.VUSTORE_MASTERPIECE_TV_55,
    PRODUCT_SLUGS.VUSTORE_MASTERPIECE_TV_65,
    PRODUCT_SLUGS.VUSTORE_MASTERPIECE_TV_75,
  ],
  [VU_GROUP_SLUGS.VUSTORE_PREMIUM_GOOGLE_OS_TV]: [
    PRODUCT_SLUGS.VUSTORE_PREMIUM_GOOGLE_OS_TV_43,
    PRODUCT_SLUGS.VUSTORE_PREMIUM_GOOGLE_OS_TV_55,
  ],
  [VU_GROUP_SLUGS.VUSTORE_PREMIUM_FHD_TV]: [
    PRODUCT_SLUGS.VUSTORE_PREMIUM_FHD_TV_43,
  ],
  [VU_GROUP_SLUGS.VUSTORE_MASTERPIECE_QLED_TV]: [
    PRODUCT_SLUGS.VUSTORE_MASTERPIECE_QLED_TV_85,
    PRODUCT_SLUGS.VUSTORE_MASTERPIECE_QLED_TV_98,
  ],
};

window.nArray = (n) => [...Array(n).keys()].map((key) => key + 1);

window.IMAGE_RESOURCE_MAP = {
  [PRODUCT_SLUGS.VUSTORE_GLO_LED_TV_43]: nArray(72).map((index) =>
    getCdnUrl(
      `https://dukaan-us.s3.us-west-2.amazonaws.com/vu-images/43inch-vu-gloled-tv-360deg-images/${
        73 - index
      }.png`,
      700
    )
  ),
  [PRODUCT_SLUGS.VUSTORE_GLO_LED_TV_50]: nArray(72).map((index) =>
    getCdnUrl(
      `https://dukaan-us.s3.us-west-2.amazonaws.com/vu-images/VuGloLed360/${
        73 - index
      }.png`,
      700
    )
  ),
  [PRODUCT_SLUGS.VUSTORE_GLO_LED_TV_55]: nArray(72).map((index) =>
    getCdnUrl(
      `https://dukaan-us.s3.us-west-2.amazonaws.com/vu-images/VuGloLed360/${
        73 - index
      }.png`,
      700
    )
  ),
  [PRODUCT_SLUGS.VUSTORE_GLO_LED_TV_65]: nArray(72).map((index) =>
    getCdnUrl(
      `https://dukaan-us.s3.us-west-2.amazonaws.com/vu-images/VuGloLed360/${
        73 - index
      }.png`,
      700
    )
  ),
  [PRODUCT_SLUGS.VUSTORE_PREMIUM_GOOGLE_OS_TV_43]: nArray(72).map((index) =>
    getCdnUrl(
      `https://dukaan-us.s3.us-west-2.amazonaws.com/vu-images/VuPremium4kNew360Images/${
        73 - index
      }.png`,
      700
    )
  ),
  [PRODUCT_SLUGS.VUSTORE_PREMIUM_GOOGLE_OS_TV_55]: nArray(72).map((index) =>
    getCdnUrl(
      `https://dukaan-us.s3.us-west-2.amazonaws.com/vu-images/VuPremium4kNew360Images/${
        73 - index
      }.png`,
      700
    )
  ),
  [PRODUCT_SLUGS.VUSTORE_PREMIUM_FHD_TV_43]: nArray(72).map((index) =>
    getCdnUrl(
      `https://dukaan-us.s3.us-west-2.amazonaws.com/vu-images/Vu+Premium+FHD+TV+43+New/${
        73 - index
      }.png`,
      700
    )
  ),
  [PRODUCT_SLUGS.VUSTORE_MASTERPIECE_TV_55]: nArray(72).map((index) =>
    getCdnUrl(
      `https://dukaan.b-cdn.net/original/dukaan-media/vu-images/Vu%20Masterpiece%20Glo%20QLED%20TV/${
        73 - index
      }.jpg`,
      700
    )
  ),
  [PRODUCT_SLUGS.VUSTORE_MASTERPIECE_TV_65]: nArray(72).map((index) =>
    getCdnUrl(
      `https://dukaan.b-cdn.net/original/dukaan-media/vu-images/Vu%20Masterpiece%20Glo%20QLED%20TV/${
        73 - index
      }.jpg`,
      700
    )
  ),
  [PRODUCT_SLUGS.VUSTORE_MASTERPIECE_TV_75]: nArray(72).map((index) =>
    getCdnUrl(
      `https://dukaan.b-cdn.net/original/dukaan-media/vu-images/Vu%20Masterpiece%20Glo%20QLED%20TV/${
        73 - index
      }.jpg`,
      700
    )
  ),
};

window.WARRANTY_TEXT_MAP = {
  '1 Year Warranty': 'One year',
  '3 Years Warranty': 'Three years',
};

window.appInitializer = () => {
  window.BUY_NOW_TEXT =
    window.DukaanData.DUKAAN_LANGUAGE.ADD_TO_CART ?? 'Add to Cart';
  window.GO_TO_BAG_TEXT =
    window.DukaanData.DUKAAN_LANGUAGE.ADD_TO_CART ?? 'Add to Cart';

  druidProductPageView();
  GAPage();

  // setting active vu category tab item & bringing it into view
  const vuCategoryTabItems = window.q$.selectAll('.vu-category-tab-item').elem;
  [...vuCategoryTabItems].forEach((tab) => {
    if (
      tab.getAttribute('href').includes(window.DukaanData.DUKAAN_PRODUCT.slug)
    ) {
      tab.classList.add(
        'vu-category-tab-active-item',
        'text-decoration-underline'
      );
      tab.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  });

  // rendering pdp products
  const vuProductListingSection = window.q$.select(
    '.vu-pdp-product-listing-section'
  ).elem;
  const productListLoadPoint = window.q$.select(
    '.vu-pdp-product-listing-section product-list-mount-point'
  ).elem;

  const defaultActiveGroup =
    vuProductListingSection.getAttribute('data-active-group');
  const productSlugsToFetch = window.VU_GROUP_PRODUCT_MAP[defaultActiveGroup];

  const fetchVuPdpProducts = async () => {
    const request = (productSlug) =>
      fetch(
        `${window.DukaanData.CLIENT_API2_ENDPOINT}/api/product/buyer/${window.DukaanData.DUKAAN_STORE.link}/product/${productSlug}/v2/`,
        {
          method: 'GET',
        }
      ).catch((e) => console.log(e));

    const requests = productSlugsToFetch.map((productSlug) =>
      request(productSlug)
    );

    return Promise.all(requests).then((responses) =>
      Promise.all(responses.map((res) => res.json())).then((res) => {
        const products = res.map((r) => r.data);
        if (products?.length) {
          productListLoadPoint.innerHTML = '';
          products.forEach((prod, index) => {
            productCardRenderer(productListLoadPoint, prod, {
              templateId: 'dkn-pdp-product-card-template',
              additionalRenderer: vuProductCardAdditionalRenderer,
              getCustomOriginalPriceText: (originalPrice) =>
                `MRP : ${window.formatMoney(originalPrice)}`,
            });
            const productCard = window.q$.select(
              `.dkn-product-card[data-product-id='${prod.id}']`,
              productListLoadPoint
            ).elem;
            const product360Images = window.IMAGE_RESOURCE_MAP[prod.slug] || [];
            if (typeof dkn360ImageViewerInit === 'function')
              dkn360ImageViewerInit(productCard, product360Images, {
                clickHandlerTargetSelector: '.dkn-product-card-image-wrapper',
                percentageTextSelector: '.dkn-360-image-viewer-percentage',
                elementToReplace: '.dkn-product-card-image',
              });

            const splideParent = q$
              .select('.dkn-product-card-splide', productCard)
              .setAttribute('id', `splide-${index}-${prod.slug}`).elem;

            if (prod?.all_images?.length > 1 && splideParent) {
              const splideList = q$.select(
                '.dkn-product-card-splide-list',
                splideParent
              ).elem;
              prod?.all_images?.forEach((image) => {
                const imageCard = q$
                  .selectById('splide-image-template')
                  .getTemplateContent().elem;
                q$.select('.dkn-product-card-image', imageCard).setAttribute(
                  'src',
                  getCdnUrl(image, 800)
                );
                splideList.appendChild(imageCard);
              });
              const productCardSplide = new Splide(
                `#splide-${index}-${prod.slug}`,
                {
                  type: 'slide',
                  autoplay: false,
                  pagination: true,
                  arrows: true,
                  drag: false,
                  perPage: 1,
                }
              );
              productCardSplide.mount();
            }
          });
          const paramString = new URLSearchParams(window.location.search);
          const productSlug = paramString.get('product_slug');

          if (productSlug) {
            q$.select(
              `product-list-mount-point .dkn-product-card[data-product-slug="${productSlug}"]`
            ).elem?.scrollIntoView({ behavior: 'smooth', block: 'center' });
          }
        } else {
          productListLoadPoint.classList.add('hidden');
        }
      })
    );
  };

  fetchVuPdpProducts();
};

window.vuProductCardAdditionalRenderer = (productCard, product, options) => {
  if (
    COMING_SOON_PRODUCTS.includes(product.slug) ||
    DIWALI_LAUNCH_PRODUCTS.includes(product.slug)
  ) {
    window.q$
      .select('.dkn-product-card-coming-soon-text', productCard)
      .removeClass('hidden');
  }
  if (!product.in_stock) {
    window.q$.select('.dkn-sold-out-label', productCard).removeClass('hidden');
  }
  if (product.in_stock && VIEW_ONLY_PRODUCTS.includes(product.slug)) {
    window.q$.select('.pdp-button-wrapper', productCard).addClass('hidden');
  }

  window.q$
    .select('.dkn-product-card-resolution-value', productCard)
    .modifyTextContent(`Resolution: ${RESOLUTION_MAP[product.slug]}`);

  if (OS_MAP[product.slug]) {
    window.q$
      .select('.dkn-product-card-operating-system-value', productCard)
      .modifyTextContent(`OS: ${OS_MAP[product.slug] || 'Official Android'}`);
  } else {
    window.q$
      .select('.dkn-product-card-operating-system-value-wrapper', productCard)
      .addClass('hidden');
  }
  window.q$
    .select('.dkn-product-card-warranty-text', productCard)
    .modifyTextContent(
      `${WARRANTY_TEXT_MAP['3 Years Warranty']} brand warranty` // TODO : get from active sku ka value
    );
  const variantFormElement = window.q$.select(
    '.dkn-variant-selection-form-wrapper',
    productCard
  ).elem;
  const actionButtonsElements = window.q$.selectAll(
    '.pdp-button-wrapper',
    productCard
  ).elem;

  window.q$
    .selectAll('.dkn-product-card', productCard)
    .setAttributeAll('data-product-slug', `${product.slug}`);

  retrieveVuProductSKUs(product, () => {}, {
    variantFormElement,
    actionButtonsElements,
  });
};

window.retrieveVuProductSKUs = (
  productFromClient,
  successCallback = () => {},
  options = {}
) => {
  fetch(
    `${window.DukaanData.CLIENT_API2_ENDPOINT}/api/product/buyer/${productFromClient.id}/product-details/`,
    {
      method: 'get',
      headers: {
        'Content-Type': 'application/json',
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
      },
    }
  )
    .then((res) => res.json())
    .then((res) => {
      const skus = res?.data.skus || [];
      const rawProduct = {
        ...productFromClient,
        skus,
        skusApi: true,
      };
      dknAddProductsToProductsMap([rawProduct]);
      const product = DukaanData.PRODUCTS_MAP[productFromClient.uuid];
      const activeSKU = dknGetFirstAvailableSKU(product.skus);
      const key = 'productPage';
      const productUUID = product.uuid;
      const productContext = {
        key,
        productUUID,
        skuUUID: activeSKU.uuid,
      };
      const renderAddons = DukaanData.DUKAAN_STORE.store_category === 6;
      const { variantFormElement, actionButtonsElements } = options;

      if (variantFormElement) {
        variantFormElement.innerHTML = '';
        dknRenderProductVariantForm(productContext, variantFormElement, {
          renderAddons,
        });
      }

      actionButtonsElements?.forEach((actionButtonsElement) => {
        actionButtonsElement.innerHTML = '';
        actionButtonsElement.appendChild(
          window.q$.selectById('pdp-button-wrapper').getTemplateContent().elem
        );
        dknRenderActionButtons(productContext, actionButtonsElement);
      });

      dknViewContentEvent(activeSKU, product);
      successCallback();
    })
    .catch((err) => {
      console.log(`retrieveProductSKUs error : ${err}`);
      if (typeof options.errorCallback === 'function') {
        options.errorCallback();
      }
    });
};
