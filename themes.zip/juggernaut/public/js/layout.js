window.fetchProductsFromParentId = ({
  cb,
  mountElem,
  parentIds,
  splideId,
  splideOptions = {},
  templateId = 'dkn-product-card-template',
  restPayload,
  options = {},
  ...rest
}) => {
  if (!parentIds) return;
  const categoryIds = parentIds.map((el) => +el);

  const payload = {
    category_ids: categoryIds,
    offset: 0,
    page_size: 8,
    show_out_of_stock_products: true,
    continue_selling_when_oos: true,
    ...restPayload,
  };

  fetch(
    `${window.DukaanData.DUKAAN_ADVANCED_SEARCH_API_BASE_URL}/api/advanced-search/${DukaanData.DUKAAN_STORE.id}/`,
    {
      method: 'post',
      body: JSON.stringify(payload),
      headers: {
        'Content-Type': 'application/json',
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
      },
    }
  )
    .then((res) => res.json())
    .then((res) => {
      if (res && res.data) {
        const { products, total_count: totalCount } = res.data;
        window.hashProductMapper(products);

        if (typeof cb === 'function') {
          cb({ products });
          return;
        }

        productListRenderer(mountElem, products, {
          templateId,
          additionalRenderer: window.productCardAdditionalRenderer,
        });
        if (splideId !== undefined) {
          renderProductsListSplide(products, splideId, splideOptions);
        }
        if (typeof options?.additionalRenderer === 'function') {
          options.additionalRenderer(mountElem, products, {
            templateId,
            additionalRenderer: window.productCardAdditionalRenderer,
            totalCount,
            ...options,
          });
        }
      } else {
        // categoryProductListRenderer(null, []);
      }
    })
    .catch((err) => {
      console.log(err);
      //   renderCategoryProductList([]);
    });
};

window.renderProductsListSplide = (
  products,
  section = 'frequently-bought-products',
  splideOptions = {}
) => {
  const splideObj = new Splide(`#${section}`, {
    type: 'slide',
    autoplay: false,
    arrows: products.length > 2,
    pauseOnHover: false,
    perPage: 2,
    perMove: 1,
    gap: 24,
    pagination: false,
    classes: {
      pagination: `splide__pagination ${section}-pagination`,
    },
    breakpoints: {
      992: {
        perPage: 2,
        arrows: false,
        gap: 16,
        pagination: true,
        padding: { right: products.length > 1 ? 24 : 0 },
        classes: {
          pagination: `splide__pagination ${section}-pagination`,
        },
      },
    },
    ...splideOptions,
  }).mount();

  if (document.querySelector(`.${section}-pagination`)) {
    const splideCatLi = document
      .querySelector(`.${section}-pagination`)
      .getElementsByTagName('li');
    const { perPage } = splideObj.options;
    const productsLength = products.length;
    const paginationWidth = `${100 / Math.ceil(productsLength / perPage)}%`;
    for (let i = splideCatLi.length - 1; i >= 0; i--) {
      splideCatLi[i].style.width = paginationWidth;
    }
  }
};

window.getSerializedItem = (data) => {
  if (!data?.length) return {};
  const serializedData = {};
  data?.forEach((item) => {
    serializedData[item.title] = item;
  });
  return serializedData;
};

window.getSerializedThemeSectionsData = (themeData) => {
  if (!themeData?.length) return {};
  const serializedThemeData = {};
  themeData?.forEach((item) => {
    serializedThemeData[item.title] = getSerializedItem(item.sections);
  });
  return serializedThemeData;
};

window.getDataFromLocalStorageV2 = (key) =>
  JSON.parse(localStorage.getItem(key)) || [];

window.getHistoryStoragekey = () =>
  `v3-${window.DukaanData.DUKAAN_STORE.link}-search-history`;

window.setDataFromLocalStorage = (key, value) => {
  localStorage.setItem(getHistoryStoragekey(), JSON.stringify(value));
};

window.setHistory = (term) => {
  const prevHistory = getDataFromLocalStorageV2(getHistoryStoragekey());
  let newHistory;
  if (prevHistory.some((historyItem) => historyItem.term === term)) {
    newHistory = [
      { term },
      ...prevHistory.filter((historyItem) => historyItem.term !== term),
    ];
  } else {
    newHistory = [{ term }, ...prevHistory.slice(0, 3)];
  }
  setDataFromLocalStorage(getHistoryStoragekey(), newHistory);
  return newHistory;
};

window.clearRecentSearches = () => {
  localStorage.removeItem(getHistoryStoragekey());
  renderRecentSearches();
};

window.clearInputSearch = () => {
  document.querySelector('.search-input').value = '';
  document.querySelector('.search-meta').classList.remove('hidden');
  document.querySelector('.search-predictions').classList.add('hidden');
  document.querySelector('.prediction-section-heading').classList.add('hidden');
  document.querySelector('.cancel-btn').classList.add('hidden');
};

// Search
window.debounce = (callback, timeout = 300) => {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => {
      callback.apply(this, args);
    }, timeout);
  };
};

// window.fillPrediction = () => {};

window.renderPredictions = (predictions) => {
  const searchPredictionsElement = document.querySelector(
    '.search-predictions'
  );
  searchPredictionsElement.replaceChildren();
  searchPredictionsElement.classList.remove('hidden');
  document.querySelector('.search-meta').classList.add('hidden');

  // search prediction title
  const searchPredictionTitle = document.createElement('h6');
  searchPredictionTitle.setAttribute('class', 'search-predictions-title  mb-3');
  searchPredictionTitle.innerHTML = 'Products';
  searchPredictionsElement.appendChild(searchPredictionTitle);

  const searchPredictionsTemplate = document.getElementById(
    'search-prediction-item'
  );

  if (predictions.length === 0) {
    // add no prediction error text
    const noPredictionText = document.createElement('p');
    noPredictionText.innerText = 'We found no search results';
    noPredictionText.setAttribute('class', 'no-prediction-text');
    searchPredictionsElement.appendChild(noPredictionText);
    return;
  }

  predictions.forEach((prediction) => {
    const categoryItemElement = document.importNode(
      searchPredictionsTemplate.content,
      true
    );
    categoryItemElement
      .querySelector('.search-prediction-item')
      .setAttribute(
        'href',
        `${DukaanData.DUKAAN_BASE_URL}/products/${prediction.slug}`
      );
    categoryItemElement
      .querySelector('.fill-prediction')
      .setAttribute('onclick', `fillPrediction(event, '${prediction.name}')`);
    categoryItemElement
      .querySelector('.prediction-image')
      .setAttribute('src', getCdnUrl(prediction.image, 100));
    categoryItemElement.querySelector('.prediction-label').textContent =
      prediction.name;
    const categoryName = prediction?.categories?.[0]?.name;
    categoryItemElement.querySelector(
      '.prediction-subcategory'
    ).textContent = `In ${categoryName}`;
    searchPredictionsElement.appendChild(categoryItemElement);
  });
};

window.handleSearchRedirection = (event) => {
  window.location.href = dknGetSearchUrl(event.target.value);
};
window.renderCategoryList = (categories, nextUrl) => {
  const categoryListElement = document.querySelector(
    '.truke-search-bar .category-list'
  );
  const categoryItemTemplate = document.getElementById('category-list-item');
  categories.forEach((category) => {
    const categoryItemElement = document.importNode(
      categoryItemTemplate.content,
      true
    );
    const categoryUrl = `${window.DukaanData.DUKAAN_BASE_URL}/collections/${category.slug}`;
    // if (category.subcategories_count > 0) {
    //   categoryUrl = `${categoryUrl}/subcategories`;
    // }
    categoryItemElement.querySelector('a').setAttribute('href', categoryUrl);
    categoryItemElement.querySelector('.category-name').textContent =
      category.name;
    categoryItemElement
      .querySelector('.category-image')
      .setAttribute('src', getCdnUrl(category.image, 500));
    categoryListElement.appendChild(categoryItemElement);
  });

  const currentEventObserver = document.getElementById(
    'search-categories-list-observer'
  );

  if (nextUrl) {
    if (currentEventObserver) {
      currentEventObserver?.remove();
    }

    const newObserverElement = document.createElement('div');
    newObserverElement.setAttribute('id', 'search-categories-list-observer');
    categoryListElement.appendChild(newObserverElement);

    const observerElement = document.getElementById(
      'search-categories-list-observer'
    );

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          fetchStoreCategories({ nextUrl, cb: renderCategoryList });
        }
      },
      {
        threshold: 1,
      }
    );
    observer.observe(observerElement);
  } else {
    currentEventObserver?.remove();
  }
};

window.renderCategoryList = (categories, nextUrl) => {
  const shimmerElems = document.querySelectorAll(
    '.search-category-item-shimmer'
  );
  if (shimmerElems) {
    shimmerElems.forEach((shimmerElem) => shimmerElem.remove());
  }

  const categoryListElement = document.querySelector('.category-list');
  const categoryItemTemplate = document.getElementById('category-list-item');

  categories.forEach((category) => {
    const categoryItemElement = document.importNode(
      categoryItemTemplate.content,
      true
    );
    if (category?.parent_id !== null) {
      categoryItemElement
        .querySelector('a')
        .setAttribute(
          'href',
          `${window.DukaanData.DUKAAN_BASE_URL}/categories/${category.slug}?category_ids=${category.id}`
        );
    } else {
      categoryItemElement
        .querySelector('a')
        .setAttribute(
          'href',
          `${getCategoryCardLink(category, DukaanData?.DUKAAN_BASE_URL)}`
        );
    }
    categoryItemElement.querySelector('.category-name').textContent =
      category.name;
    categoryItemElement
      .querySelector('.category-image')
      .setAttribute('src', `${getCdnUrl(category.image, 500)}`);
    categoryListElement.appendChild(categoryItemElement);
  });

  const currentEventObserver = document.getElementById(
    'search-categories-list-observer'
  );

  if (nextUrl) {
    if (currentEventObserver) {
      currentEventObserver?.remove();
    }

    const newObserverElement = document.createElement('div');
    newObserverElement.setAttribute('id', 'search-categories-list-observer');
    categoryListElement.appendChild(newObserverElement);

    const observerElement = document.getElementById(
      'search-categories-list-observer'
    );

    const observer = new IntersectionObserver((entries) => {
      if (entries[0].isIntersecting) {
        fetchStoreCategoriesSearchDrawer({ nextUrl, cb: renderCategoryList });
      }
    });
    observer.observe(observerElement);
  } else {
    currentEventObserver?.remove();
  }
};

window.renderRecentSearches = () => {
  const recentSearchList = getDataFromLocalStorageV2(getHistoryStoragekey());
  if (recentSearchList.length > 0) {
    document
      .querySelectorAll('.recent-searches')
      .forEach((el) => el.classList.remove('hidden'));
    const recentSearchListElements = document.querySelectorAll(
      '.recent-searches-list'
    );
    recentSearchListElements.forEach((recentSearchListEl) => {
      recentSearchListEl.replaceChildren();

      const recentSearchItemTemplate = document.getElementById(
        'recent-searches-template'
      );

      recentSearchList.forEach((search) => {
        const resentSearchItemElement = document.importNode(
          recentSearchItemTemplate.content,
          true
        );
        resentSearchItemElement.querySelector(
          '.recent-search-item-text'
        ).textContent = search.term;
        resentSearchItemElement
          .querySelector('.recent-search-item')
          .setAttribute('onclick', `handleQuerySearch(null, '${search.term}')`);
        recentSearchListEl.appendChild(resentSearchItemElement);
      });
    });
  } else {
    document
      .querySelectorAll('.recent-searches')
      .forEach((el) => el.classList.add('hidden'));
  }
};

window.initSearchBar = () => {
  const categoryListElm = document.querySelector(
    '.truke-search-bar .category-list'
  );
  if (categoryListElm.children.length <= 0) {
    window.fetchSearchStoreCategoriesInit = window.fetchStoreCategories();
    window.fetchSearchStoreCategoriesInit({
      cb: window.renderCategoryList,
      firstFetch: true,
    });
  }
};

window.fetchStoreCategoriesSearchDrawer = null;

window.additionalCategoryProductCardChanges = (
  categoryProductCard,
  product
) => {
  const productPriceContainer =
    categoryProductCard.querySelector('.price-information');
  if (product.in_stock) {
    productPriceContainer.style.display = 'block';
  } else {
    productPriceContainer.style.display = 'none';
  }
};

window.handleInputChange = (event) => {
  const query = event.target.value;

  if (query.length === 0) {
    handleEmptySearchInput();
    return;
  }
  if (query.length < 2) {
    return;
  }
  const extraParams =
    window?.searchConfig?.extraParamsForFetchingPredictions || {};
  fetch(
    `${window.DukaanData.DUKAAN_ADVANCED_SEARCH_API_BASE_URL}/api/advanced-search/${window.DukaanData.DUKAAN_STORE.id}/`,
    {
      method: 'post',
      body: JSON.stringify({ query, page_size: 12, ...extraParams }),
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
      },
    }
  )
    .then((res) => res.json())
    .then((res) => {
      const predictions = res?.data || [];
      renderPredictions(predictions.products);
    })
    .catch((err) => {
      console.log(err);
    });
};

window.onInputChange = (event) => {
  const query = event.target.value;
  if (query.length === 0) {
    document
      .querySelectorAll('.search-meta')
      .forEach((el) => el.classList.remove('hidden'));
    document
      .querySelectorAll('.search-predictions')
      .forEach((el) => el.classList.add('hidden'));
    renderRecentSearches();
  }
  if (event.target.value.length > 0 && event.keyCode === 13) {
    // on enter key
    handleQuerySearch(event);
    return;
  }
  document
    .querySelector('.input-wrapper .clear-btn')
    .classList.remove('d-none');
  debounce(handleInputChange(event), 300);
};

window.onInputClear = () => {
  handleEmptySearchInput();
};

window.splideSlideIndex = (allImages, primaryImage) => {
  const index = allImages?.indexOf(primaryImage);
  window?.splideSlider?.go(index);
};

window.handleModalChanges = (product, currentSKU) => {
  const element = document.querySelector('.product-variant-selection-modal');
  if (!element) return;

  // if (element.querySelector('.product-modal-badge .bxgy-badge')) {
  //   handleProductCardChange(element, product);
  // }
  if (element !== null) {
    if (element.querySelector('.product-name')) {
      element.querySelector('.product-name').textContent = `${product.name}`;
    }

    if (element.querySelector('.stock-left-message')) {
      if (currentSKU.inventory <= 10 && !!currentSKU.inventory) {
        element.querySelector('.stock-left-message').classList.remove('hidden');
        element.querySelector('.stock-left-message').textContent =
          `${DukaanData.DUKAAN_LANGUAGE.ONLY__INVENTORY_LEFT_IN_STOCK_HURRY_UP}!`.injectText(
            {
              inventory: currentSKU.inventory,
            }
          );
      } else {
        element.querySelector('.stock-left-message').classList.add('hidden');
        element.querySelector('.stock-left-message').textContent = ``;
      }
    }

    const originalPrice = currentSKU?.original_price;
    const sellingPrice = currentSKU?.selling_price;

    if (element.querySelector('.product-selling-price')) {
      element.querySelector('.product-selling-price').textContent =
        formatMoney(sellingPrice);
    }

    if (
      (((originalPrice - sellingPrice) / originalPrice) * 100).toFixed(0) > 0
    ) {
      if (element.querySelector('.product-original-price')) {
        element.querySelector('.product-original-price').textContent =
          formatMoney(originalPrice);
      }

      if (element.querySelector('.product-discount-badge')) {
        element.querySelector(
          '.product-discount-badge'
        ).textContent = `(${calculateDiscount(
          originalPrice,
          sellingPrice
        )}% off)`;
      }
      element
        .querySelector('.product-original-price')
        .classList.remove('hidden');
      element
        .querySelector('.product-discount-badge')
        .classList.remove('hidden');
    } else {
      element.querySelector('.product-original-price').classList.add('hidden');
      element.querySelector('.product-discount-badge').classList.add('hidden');
    }

    // renders product modal carousel with splide if exist.
    const productSplideTemplate = document.querySelector(
      '#product-modal-splide-container,#product-modal-splide-container_thumbnail'
    );

    if (productSplideTemplate) {
      const productSplideList = element.querySelector('.splide__list');
      const productThumbnailList = element.querySelector(
        '.splide__list_thumbnail'
      );

      if (typeof splideSlider === 'undefined') {
        if (product.all_images?.length > 1) {
          // main splide
          productSplideList.replaceChildren();
          // eslint-disable-next-line no-restricted-syntax
          for (const image of product?.all_images || []) {
            const productSplide = document.importNode(
              productSplideTemplate.content,
              true
            );
            productSplide
              .querySelector('.product-modal-splide-image')
              .setAttribute(
                'src',
                `${getCdnUrl(image || currentSKU.primary_image, 700)}`
              );
            productSplideList.appendChild(productSplide);
          }

          window.splideSlider = new Splide('#splide-product-modal-images', {
            type: 'loop',
            delay: '5000',
            rewind: true,
            autoplay: false,
            arrows: false,
            pauseOnHover: false,
            pagination: false,
            updateOnMove: true,
            classes: {
              arrows: 'splide__arrows',
            },
          });

          // thumbnail splide

          productThumbnailList.replaceChildren();
          // eslint-disable-next-line no-restricted-syntax
          for (const image of product?.all_images || []) {
            const productSplide = document.importNode(
              productSplideTemplate.content,
              true
            );
            productSplide
              .querySelector('.product-modal-splide-image')
              .setAttribute(
                'src',
                `${getCdnUrl(image || currentSKU.primary_image, 700)}`
              );
            productThumbnailList.appendChild(productSplide);
          }

          window.thumbnailSplideSlider = new Splide(
            '#splide-product-thumbnail-image',
            {
              type: 'slide',
              autoplay: false,
              arrows: true,
              pauseOnHover: false,
              pagination: false,
              interval: 1000,
              isNavigation: true,
              fixedWidth: '88px',
              fixedHeight: '110px',
              focus: 'center',
              height: '465px',
              classes: {
                arrows: 'splide__arrows',
              },
            }
          );

          window.splideSlider.sync(window.thumbnailSplideSlider);
          window.splideSlider.mount();
          window.thumbnailSplideSlider.mount();
        } else if (element.querySelector('.product-images')) {
          element.querySelector('.product-images').replaceChildren();
          const wrapper = element.querySelector('.product-images');

          const imageWrapper = document.createElement('div');
          imageWrapper.classList.add('image-wrapper');
          const imgElem = document.createElement('img');
          imgElem.setAttribute('class', 'product-image');
          imageWrapper.appendChild(imgElem);
          wrapper.appendChild(imageWrapper);

          element
            .querySelector('.product-image')
            .setAttribute(
              'src',
              `${getCdnUrl(product.image || currentSKU.primary_image, 700)}`
            );
        }
      }
      if (!currentSKU?.primary_image.includes('category-def.jpg')) {
        const allImages = product?.all_images || product?.image;
        if (typeof splideSlideIndex !== 'undefined')
          splideSlideIndex(allImages, currentSKU.primary_image);
      }
    }

    if (currentSKU.meta.size) {
      const sizeListHeadingLabel = element.querySelector(
        '.size-selection-heading'
      );
      if (sizeListHeadingLabel) {
        if (currentSKU.meta.size.attributeLabel) {
          sizeListHeadingLabel.innerHTML =
            DukaanData.DUKAAN_LANGUAGE.SELECT__ATTRIBUTE.injectText({
              attribute: currentSKU.meta.size.attributeLabel,
            });
          // `Select ${currentSKU.meta.size.attributeLabel}`;
        } else {
          sizeListHeadingLabel.innerHTML =
            DukaanData.DUKAAN_LANGUAGE.SELECT_SIZE;
        }
      }
    }

    if (currentSKU.meta.color) {
      const colorListHeadingLabel = element.querySelector(
        '.color-selection-heading'
      );
      if (colorListHeadingLabel) {
        if (currentSKU.meta.color.attributeLabel) {
          colorListHeadingLabel.innerHTML =
            DukaanData.DUKAAN_LANGUAGE.SELECT__ATTRIBUTE.injectText({
              attribute: currentSKU.meta.color.attributeLabel,
            });
          // `Select ${currentSKU.meta.color.attributeLabel}`;
        } else {
          colorListHeadingLabel.innerHTML =
            DukaanData.DUKAAN_LANGUAGE.SELECT_COLOR;
        }
      }
    }
  }
};

window.redirectToSearchPage = (value) => {
  value = value.trim();
  if (Boolean(value) && value.length > 0) {
    setHistory(value);
    window.location.href = dknGetSearchUrl(value);
  }
};

window.handleQuerySearch = (e, query = '') => {
  // let target = null;
  if (e !== null) {
    e.preventDefault();
    // target = e.target;
  }
  const rawQuery = query || e.target.value;
  setHistory(rawQuery);
  window.location.href = dknGetSearchUrl(rawQuery);
};

window.APP_IDS = {
  ...(window.APP_IDS || {}),
  STORE_LOCATOR: '6286104b4f1ca25e2256f6b7',
};

window.addEventListener('load', () => {
  axios
    .get(
      `https://apps.mydukaan.io/public/v2/apps/store/${DukaanData.DUKAAN_STORE.id}/`
    )
    .then((response) => {
      const { store_apps_list: appList } = response?.data || {};
      const availablePlugins = appList?.reduce((acc, item) => {
        if (item.isActive) {
          // eslint-disable-next-line no-underscore-dangle
          acc[item._id] = item;
        }
        return acc;
      }, {});
      const isStoreLocatorPresent = Boolean(
        !!availablePlugins && availablePlugins[APP_IDS.STORE_LOCATOR]
      );
      const storeLocatorTags = document.querySelectorAll('.store-locator-link');
      if (isStoreLocatorPresent) {
        storeLocatorTags.forEach((tag) => tag.classList.remove('hidden'));
      } else {
        storeLocatorTags.forEach((tag) => tag.remove());
      }
    });
});

window.getCustomDiscountText = (discount) => `(${discount}% OFF)`;

window.productCardRenderedCount = 0;

window.productCardAdditionalRenderer = (productCard, product, options) => {
  productCardRenderedCount += 1;
  q$.select('.dkn-product-card', productCard).setAttribute(
    'data-product-card-key',
    `${productCardRenderedCount}-${product.uuid}`
  );
  window.renderColorVariantsOnProductCard(productCard, product, options);
  window.handleProductCardSplideInit(productCard, product);

  // productCardImageCarouselRenderer(product, productCard);
};

window.redirectToSearchPageOnSubmit = (e) => {
  e.preventDefault();
  const formData = new FormData(document.querySelector('form#search-form'));
  const value = formData.get('search');
  redirectToSearchPage(value);
};

window.removeOverflowFromBody = () => {
  document.querySelector('body').classList.remove('overflow-hidden');
};

window.handleEmptySearchInput = () => {
  document.querySelector('.search-input').value = '';
  document.querySelector('.search-predictions').classList.add('hidden');
  document.querySelector('.search-meta').classList.remove('hidden');
  document.querySelector('.input-wrapper .clear-btn').classList.add('d-none');
};

window.fetchCustomStoreSubCategories = () => {
  // Common function
  let offset = 0;
  let initialized = true;
  const offsetCount = 10;

  // eslint-disable-next-line no-undef, no-return-assign
  return (fetchFn = ({
    nextUrl = false,
    cb,
    loadPoint = null,
    firstFetch = false,
    ...rest
  } = {}) => {
    const { categorySlug } = rest;
    if (!categorySlug) return;

    const fetchUrl = `https://api2.mydukaan.io/api/product/buyer/${window.DukaanData.DUKAAN_STORE.link}/product-category-list/?parent_slug=${categorySlug}&offset=${offset}`;

    if (nextUrl) {
      offset += offsetCount;
      initialized = false;
      firstFetch = false;
    }

    if (initialized) offset += offsetCount;

    fetch(fetchUrl, {
      method: 'get',
      headers: {
        'Content-Type': 'application/json',
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
        // 'Content-Type': 'application/x-www-form-urlencoded',
      },
    })
      .then((res) => res.json())
      .then((res) => {
        const categories = res?.results || [];
        const next = !(categories.length < offsetCount);
        DukaanData.DUKAAN_CLIENT_SUB_CATEGORY_LIST = {
          ...DukaanData?.DUKAAN_CLIENT_SUB_CATEGORY_LIST,
          ...categories?.reduce((map, category) => {
            map[category.uuid] = { ...category };
            return map;
          }, {}),
        };
        cb(loadPoint, categories, next, firstFetch, rest);
      })
      .catch((err) => {
        // console.log('fetchStoreSubCategories error : ', err);
        cb([], null);
      });
  });
};

window.subCategoriesRenderer = (
  mountElement,
  categories,
  nextUrl,
  firstFetch,
  { templateId = 'header-all-category-card-template', additionalRenderer }
) => {
  if (firstFetch) {
    mountElement.innerHTML = '';
  }
  const categoryCardTemplate = document.getElementById(templateId);

  categories?.forEach((category) => {
    const categoryCard = document.importNode(
      categoryCardTemplate.content,
      true
    );

    const categoryUrl = getCategoryCardLink(category);

    categoryCard
      .querySelectorAll('a')
      .forEach((el) => el.setAttribute('href', categoryUrl));

    categoryCard.querySelector('.header-dropdown-item').textContent =
      category.name;

    if (typeof additionalRenderer !== 'undefined') {
      additionalRenderer(categoryCard, category);
    }

    mountElement.appendChild(categoryCard);
  });
};

window.initSubcategoryHeader = (event) => {
  const { categorySlug, categoryCount } = event.dataset;

  if (categoryCount) {
    window.q$
      .select('.header-sub-category-item-dropdown')
      .elem.classList.add('hidden');
    window.fetchHeaderSubCategoriesInit =
      window.fetchCustomStoreSubCategories();

    if (categorySlug) {
      window.fetchHeaderSubCategoriesInit({
        cb: window.subCategoriesRenderer,
        categorySlug,
        firstFetch: true,
        templateId: 'header-all-category-card-template',
        loadPoint: window.q$.select('header-all-sub-category-list-load-point')
          .elem,
        additionalRenderer: () => {
          window.q$
            .select('.header-sub-category-item-dropdown')
            .removeClass('hidden');
        },
      });
    }
  }
};

window.commonInitializer = () => {
  dknInitHeader();
  GAPage();
};

window.dropDownClose = () => {
  window.q$.select('.header-sub-category-item-dropdown').addClass('hidden');
};

window.getCustomTotalWishlistCountText = (totalWishlistCount) =>
  `${
    window.DukaanData.DUKAAN_LANGUAGE.MY_WISHLIST || 'My wishlist'
  } (${totalWishlistCount})`;

window.couponPageProductCardTemplateId = 'dkn-product-card-template';
window.productCardTemplateId = 'dkn-product-card-template';

window.renderColorVariantsOnProductCard = (productCard, product, options) => {
  const { skus = [], attributes = {} } = DukaanData.PRODUCTS_MAP[product.uuid];
  const colorListWrapper = q$.select(
    '.dkn-product-card-color-list',
    productCard
  ).elem;
  const productKey =
    q$.select('.dkn-product-card', productCard).elem?.dataset?.productCardKey ||
    product.uuid;
  if (skus?.length && attributes?.color?.length && colorListWrapper) {
    q$.select('.dkn-product-card-variant-form', productCard).setAttribute(
      'id',
      `dkn-product-card-variant-form-${productKey}`
    );
    colorListWrapper.classList.remove('hidden');
    attributes.color.forEach((color, index) => {
      const colorItem = q$
        .selectById('dkn-color-variant-item-template')
        .getTemplateContent().elem;
      const colorItemInput = colorItem.querySelector('input');
      const colorSVG = colorItem.querySelector('svg');
      const colorSVGPath = colorItem.querySelector('svg path');

      if (index === 0) {
        colorItemInput.checked = true;
      }

      const { isLight } = colorLightOrDark(color);
      colorSVG?.setAttribute('color', isLight ? '#1a181e' : '#ffffff');
      if (colorSVGPath) {
        colorSVGPath.style.setProperty(
          'color',
          `${isLight ? '#1a181e' : '#ffffff'}`
        );
      }
      colorItemInput.setAttribute('id', `color-${color}-${productKey}`);
      colorItemInput.setAttribute('value', color);
      colorItemInput.setAttribute('onchange', () => {});
      colorItemInput.setAttribute(
        'onclick',
        `handleProductCardColorClick('${color}','${product.uuid}', '${productKey}')`
      );
      colorItem
        .querySelector('label')
        .setAttribute('for', `color-${color}-${productKey}`);
      colorItem.querySelector('.dkn-color-variant-bg-color').style.background =
        color;
      colorListWrapper.appendChild(colorItem);
    });
    const activeColor = attributes.color[0];
    const skuWithCurrentColor = skus.find(
      (sku) => sku?.meta?.color?.value === activeColor
    );

    if (skuWithCurrentColor) {
      skuAdditionalModifiers(productCard, skuWithCurrentColor, product);
      renderJuggernautAddToBagOnProductCard(productCard, {
        productUUID: product.uuid,
        skuUUID: skuWithCurrentColor.uuid,
      });
    }
  } else {
    renderJuggernautAddToBagOnProductCard(productCard, {
      productUUID: product.uuid,
      skuUUID: product?.skus[0]?.uuid,
    });
  }
};

window.renderJuggernautAddToBagOnProductCard = (
  productCard,
  { productUUID, skuUUID } = {}
) => {
  const addToBagElement = q$.select('add-to-bag-button', productCard).elem;
  if (!addToBagElement) return;

  addToBagElement.dataset.productUuid = productUUID;
  addToBagElement.dataset.skuUuid = skuUUID;
  addToBagButtonRenderer(addToBagElement);
};

const SLUG_MAP = {
  BESTSELLER: 'bestseller',
};

window.skuAdditionalModifiers = (productCard, currentSKU, product) => {
  q$.select('.dkn-product-card-selling-price', productCard).modifyTextContent(
    formatMoney(currentSKU.selling_price)
  );
  q$.select('.dkn-product-card-original-price', productCard).modifyTextContent(
    formatMoney(currentSKU.original_price)
  );

  const inStock = currentSKU.inventory === null || currentSKU.inventory > 0;

  if (!inStock) {
    window.q$
      .select('.dkn-product-card-sold-out-badge', productCard)
      .removeClass('d-none');
  } else {
    const discount = window.getDiscountPercentValue(
      currentSKU.selling_price,
      currentSKU.original_price
    );
    if (discount) {
      window.q$
        .select('.dkn-product-card-sale-badge', productCard)
        .removeClass('d-none');
    }
  }

  const hasBestsellerCategory = product?.categories?.find(
    (c) => c?.slug === SLUG_MAP.BESTSELLER
  );
  if (hasBestsellerCategory) {
    window.q$
      .select('.dkn-product-card-bestseller-badge', productCard)
      .removeClass('d-none');
  }
};

window.handleProductCardColorClick = (color, productUUID, key) => {
  const product = DukaanData.PRODUCTS_MAP[productUUID];
  const { skus } = product;
  const currentSKU = skus.find((sku) => sku.meta.color.value === color);
  const primaryImage = currentSKU.primary_image;
  let productCardSplide = new Splide(
    `#dkn-product-card-image-carousel-wrapper-${key}`
  );
  productCardSplide.destroy();
  let index = 0;
  if (
    typeof productCardSplide !== 'undefined' &&
    !!productCardSplide &&
    primaryImage
  ) {
    const allSKUImages = skus.map((sku) => sku.primary_image).filter(Boolean);
    const allImages = allSKUImages.length ? allSKUImages : product.all_images;
    if (allImages.length > 0) {
      index = allImages.indexOf(primaryImage);
      if (index < 0) index = 0;
    }
  }
  productCardSplide = new Splide(
    `#dkn-product-card-image-carousel-wrapper-${key}`,
    {
      type: 'slide',
      autoplay: false,
      interval: 1500,
      arrows: false,
      pauseOnHover: false,
      pagination: false,
      rewind: true,
      start: index,
    }
  );
  productCardSplide.mount();
  const productCard = q$.select(`[data-product-card-key="${key}"]`).elem;

  if (currentSKU && productCard) {
    skuAdditionalModifiers(productCard, currentSKU, product);
    renderJuggernautAddToBagOnProductCard(productCard, {
      productUUID: product.uuid,
      skuUUID: currentSKU.uuid,
    });
  }
};

window.handleProductCardSplideInit = (productCard, product) => {
  const productCardId =
    q$.select('.dkn-product-card', productCard).elem?.dataset?.productCardKey ||
    product.uuid;
  const { all_images: allProductImages, skus } = product;

  const imageSlideTemplateId = 'product-splide-container';
  const imageListContainer = productCard.querySelector(
    '.dkn-product-card-image-carousel'
  );

  const productCardCarouselWrapper = productCard.querySelector(
    `.dkn-product-card-image-carousel-wrapper`
  );
  productCardCarouselWrapper?.setAttribute(
    'id',
    `dkn-product-card-image-carousel-wrapper-${productCardId}`
  );
  // debugger;
  const allSKUImages = skus.map((sku) => sku.primary_image).filter(Boolean);
  const productImagesArray =
    allSKUImages.length > 1 ? allSKUImages : allProductImages;

  if (imageListContainer && productImagesArray?.length > 0) {
    // render image carousel

    productImagesArray?.forEach((image) => {
      const imageSlideContainer = window.q$
        .selectById(imageSlideTemplateId)
        .getTemplateContent().elem;
      window.q$
        .select('.dkn-product-card-image-carousel-item', imageSlideContainer)
        .setAttribute('src', `${window.getCdnUrl(image, 700)}`);
      imageListContainer.appendChild(imageSlideContainer);
    });

    // initialize splide
    const productCardCarousel = new Splide(productCardCarouselWrapper, {
      type: 'slide',
      autoplay: false,
      interval: 1500,
      arrows: false,
      pauseOnHover: false,
      pagination: false,
      rewind: true,
    });
    productCardCarousel.mount();
  }
};

// custom star renderer
window.dknRatingStarsRenderer = () => {
  const mountElems = window.q$.selectAll('dkn-rating-stars').elem;
  if (!mountElems?.length) {
    return;
  }

  mountElems.forEach((mountElem) => {
    mountElem.innerHTML = '';
    const { rating, templateId } = mountElem?.dataset || {};
    if (!templateId || !rating) {
      return;
    }

    mountElem.classList.remove('hidden');

    const ratingIntegerPart = Math.floor(Number(rating));
    const ratingDecimalPart = parseFloat((Number(rating) % 1).toFixed(1));

    for (let i = 0; i < ratingIntegerPart; i += 1) {
      const ratingStar = window.q$
        .selectById(templateId)
        .getTemplateContent().elem;

      mountElem.appendChild(ratingStar);
    }

    if (ratingDecimalPart) {
      const ratingStar = window.q$
        .selectById(templateId)
        .getTemplateContent().elem;

      const randomHash = generateRandomString(16);

      window.q$
        .select('.dkn-rating-star', ratingStar)
        .setAttribute('data-hash', randomHash);

      mountElem.appendChild(ratingStar);

      const svgElem = window.q$.select(
        `.dkn-rating-star[data-hash="${randomHash}"]`
      ).elem;

      const width = Number(svgElem.attributes.width.value) || 24;
      const height = Number(svgElem.attributes.height.value) || 24;

      const newWidth = Math.round(ratingDecimalPart * width);

      svgElem.setAttribute('width', newWidth);
      svgElem.setAttribute('viewBox', `0 0 ${newWidth} ${height}`);
    }
  });
};
