window.fetchFeaturedProduct = (productSlug, mountElement) => {
  fetch(
    `${window.DukaanData.CLIENT_API_ENDPOINT}/api/product/buyer/${DukaanData.DUKAAN_STORE.link}/product/${productSlug}/v2`,
    {
      headers: {
        'Content-Type': 'application/json',
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
      },
    }
  )
    .then((res) => res.json())
    .then((res) => {
      const product = res.data;
      hashProduct(product);
      renderFeaturedProduct(product, mountElement);
    })
    .catch((err) => {
      console.log(err);
    });
};

window.renderFeaturedProduct = (featuredProduct, mountElement) => {
  const { uuid } = featuredProduct;
  const product = DukaanData.PRODUCTS_MAP[uuid];
  const {
    name,
    description,
    slug,
    all_images: allImages,
  } = DukaanData.PRODUCTS_MAP[uuid];

  const featuredProductCard = q$
    .selectById('feature-product-template')
    .getTemplateContent().elem;

  q$.select('.dkn-product-name', featuredProductCard).modifyTextContent(name);
  q$.select('.dkn-product-description', featuredProductCard).modifyInnerHTML(
    HtmlSanitizer?.SanitizeHtml(description) || description
  );
  q$.select('.dkn-fp-know-more', featuredProductCard).setAttribute(
    'onclick',
    `window.location.href= '${getProductPageUrl(product)}'`
  );

  const carouselListElement = q$.select(
    '.feature-product-carousel-list',
    featuredProductCard
  ).elem;

  allImages?.forEach((image) => {
    const imageItem = q$
      .selectById('feature-product-image-item-template')
      .getTemplateContent().elem;
    q$.select('.dkn-fp-image', imageItem).setAttribute(
      'src',
      getCdnUrl(image, 501)
    );
    carouselListElement.appendChild(imageItem);
  });

  const addToBagElement = q$.select(
    'add-to-bag-button-with-variants',
    featuredProductCard
  ).elem;
  if (addToBagElement) {
    addToBagElement.dataset.productUuid = uuid;
    addToBagButtonWithVariantsRenderer(addToBagElement);
  }

  mountElement.appendChild(featuredProductCard);
  const featureProductCarousel = new Splide('#feature-product-carousel', {
    type: 'slide',
    interval: 5000,
    autoplay: false,
    pagination: true,
    arrows: false,
    pauseOnHover: false,
    pauseOnFocus: false,
    // height: '430px',
    // fixedWidth: '430px',
    breakpoints: {
      992: {
        // height: '328px',
        fixedWidth: '100%',
      },
    },
  });

  featureProductCarousel.mount();
};

// window.renderProductsListSplide = () => {
//   const bestsellerElements = document.querySelectorAll(
//     '.homepage-bestseller-product-splide'
//   );

//   bestsellerElements.forEach((elm) => {
//     const splideId = elm.getAttribute('id');

//     if (splideId && window[splideId]) {
//       return;
//     }
//     window[splideId] = new Splide(elm, {
//       type: 'slide',
//       autoplay: false,
//       pauseOnHover: false,
//       pagination: false,
//       arrows: false,
//       drag: false,
//       grid: {
//         perPage: 8,
//         rows: 2,
//         cols: 4,
//         gap: {
//           row: 32,
//           col: 32,
//         },
//       },
//       breakpoints: {
//         768: {
//           drag: true,
//           perPage: 1,
//           type: 'loop',
//           gap: 16,
//           pagination: true,
//           grid: false,
//           trimSpace: true,
//           padding: { right: '144px' },
//         },
//       },
//     });

//     window[splideId].mount(window.splide.Extensions);

//     if (elm.querySelector(`.splide__pagination`)) {
//       const splideCatLi = elm
//         .querySelector(`.splide__pagination`)
//         .getElementsByTagName('li');

//       const { perPage } = window[splideId].options;
//       const productsLength = splideCatLi.length;
//       // // if (productsLength > 5) {
//       // //   productsLength += 1;
//       // // }
//       const paginationWidth = `${100 / Math.ceil(productsLength / perPage)}%`;
//       for (let i = splideCatLi.length - 1; i >= 0; i -= 1) {
//         splideCatLi[i].style.width = paginationWidth;
//       }
//     }
//   });
// };

// feature product splide
window.handleProductCardSplideInit = (productCard, product) => {
  // const productCardId = productCard.dataset;
  const { all_images: productImagesArray } = product;
  const imageSlideTemplateId = 'product-splide-container';
  const imageListContainer = productCard.querySelector(
    '.dkn-product-card-image-carousel'
  );

  const productCardCarouselWrapper = productCard.querySelector(
    `#dkn-product-card-image-carousel-wrapper`
  );

  if (productImagesArray?.length > 0) {
    // render image carousel
    productImagesArray?.forEach((image) => {
      const imageSlideContainer = window.q$
        .selectById(imageSlideTemplateId)
        .getTemplateContent().elem;
      window.q$
        .select('.dkn-product-card-image-carousel-item', imageSlideContainer)
        .setAttribute('src', `${window.getCdnUrl(image, 701)}`);
      imageListContainer.appendChild(imageSlideContainer);
    });
  } else {
    const imageSlideContainer = window.q$
      .selectById(imageSlideTemplateId)
      .getTemplateContent().elem;
    window.q$
      .select('.dkn-product-card-image-carousel-item', imageSlideContainer)
      .setAttribute('src', product.image);
    imageListContainer.appendChild(imageSlideContainer);
  }
  // initialize splide
  const productCardCarousel = new Splide(productCardCarouselWrapper, {
    type: 'loop',
    autoplay: false,
    pauseOnHover: false,
    width: '100%',
    pagination: true,
    arrows: false,
  });

  productCardCarousel.mount();
};

window.renderViewAllButton = (
  mountElement,
  viewAllLink,
  bestsellerRenderedCount
) => {
  const parentElement = mountElement
    ? mountElement.querySelector('product-card-load-point')
    : window.q$.selectAll('product-card-load-point')?.elem?.[
        bestsellerRenderedCount
      ];
  if (!parentElement) return;

  const childElement = document.createElement('div');
  childElement.setAttribute(
    'class',
    'cards_item d-lg-none dkn-product-card scroller-product-card d-flex flex-column justify-content-center text-c-white'
  );

  childElement.innerHTML = `
        <div class="d-flex flex-column justify-content-between align-items-center text-center">
          <a href=${viewAllLink} class="text-16_24 btn-primary px-2_5">
            ${window.DukaanData.DUKAAN_LANGUAGE.VIEW_ALL_PRODUCTS}
          </a>
        </div>
        `;
  parentElement.appendChild(childElement);
};

window.appInitializer = () => {
  hashProductMap(window.DukaanData.DUKAAN_CATALOG);
  druidStorePageView();
  fetchCouponsAndOffersOnIndex();

  if (document.querySelector('#hero-splide-image'))
    new Splide('#hero-splide-image', {
      type: 'loop',
      autoplay: true,
      interval: 5000,
      pagination: DukaanData?.DUKAAN_WEB_BANNERS.length > 1 || false,
      arrows: false,
      perPage: 1,
    }).mount();

  if (document.querySelector('#hero-splide-image-mobile'))
    new Splide('#hero-splide-image-mobile', {
      type: 'loop',
      autoplay: true,
      interval: 5000,
      pagination: DukaanData?.DUKAAN_MOBILE_BANNERS.length > 1 || false,
      arrows: false,
      perPage: 1,
    }).mount();

  let loading = false;
  const offsetCount = 4;
  let offset = 0;
  let hasMore = true;
  let bestsellerRenderedCount = 0;

  const homeSectionParentElement = q$.select('.sc-home-page-sections').elem;
  const bestsellerLoadPoints = q$.selectAll(
    '.sc-home-page-sections bestseller-category-mount-point'
  ).elem;

  const fetchBestSellers = async () => {
    if (loading) return;
    loading = true;
    const response = await fetch(
      `${window.DukaanData.CLIENT_API2_ENDPOINT}/api/store/buyer/${window.DukaanData.DUKAAN_STORE.link}/bestseller/v3/?offset=${offset}`
    );
    const res = await response?.json();
    const { results: rawResults = [] } = res || {};
    const count = rawResults?.length;
    const results = rawResults?.filter((rR) => rR.products.length > 0);
    hashProductMap(results);
    hashCategory(results);
    if (results?.length) {
      results.forEach((category) => {
        const mountElement =
          bestsellerLoadPoints?.[bestsellerRenderedCount] ||
          homeSectionParentElement;
        if (mountElement === bestsellerLoadPoints?.[bestsellerRenderedCount]) {
          mountElement.innerHTML = '';
        }
        renderSingleBestSellerCategory(category, mountElement, 8);

        if (category.product_count > 8) {
          const viewAllLink = `${window.DukaanData.DUKAAN_BASE_URL}/categories/${category.slug}`;
          window.renderViewAllButton(
            bestsellerLoadPoints?.[bestsellerRenderedCount],
            viewAllLink,
            bestsellerRenderedCount
          );
        }

        // window.renderProductsListSplide();

        bestsellerRenderedCount += 1;
      });
      if (bestsellerRenderedCount < bestsellerLoadPoints?.length) {
        [...bestsellerLoadPoints]
          .slice(bestsellerRenderedCount)
          .forEach((loadPoint) => loadPoint.classList.add('hidden'));
      }
    } else {
      bestsellerLoadPoints?.forEach((loadPoint) =>
        loadPoint.classList.add('hidden')
      );
    }

    if (count < offsetCount) {
      hasMore = false;
      removeScroller({ observeThis: 'bestseller-observer' });
    } else {
      hasMore = true;
      offset += offsetCount;
      loading = false;
    }
    loading = false;
  };

  applyScroller({
    loading,
    hasMore,
    cb: fetchBestSellers,
    observeThis: 'bestseller-observer',
    loadPoint: q$.select('.sc-home-page-sections').elem,
  });
  fetchBestSellers();

  if (document.getElementById('customer-review-splide')) {
    const testimonialSplide = new Splide('#customer-review-splide', {
      type: 'loop',
      autoplay: true,
      interval: 5000,
      pauseOnHover: false,
      width: '100%',
      pagination: true,
      arrows: true,
    });
    testimonialSplide.mount();
  }

  const featuredProductMountElement = q$.select(
    'feature-product-load-point'
  ).elem;
  if (featuredProductMountElement) {
    const { productSlug } = featuredProductMountElement.dataset;
    fetchFeaturedProduct(productSlug, featuredProductMountElement);
  }
};
