const dropdownSvgWrapper = document.querySelector(
  '.shop-dropdown-chevron-svg-wrapper'
);
if (dropdownSvgWrapper) {
  dropdownSvgWrapper.addEventListener('click', (evt) => {
    evt.preventDefault();
    if (dropdownSvgWrapper.classList.contains('rotate-180deg')) {
      dropdownSvgWrapper.classList.remove('rotate-180deg');
    } else {
      dropdownSvgWrapper.classList.add('rotate-180deg');
    }
  });
}

// const leftMenuDrawerElem = document.getElementById('offcanvasLeftMenu');
// if (leftMenuDrawerElem) {
//   leftMenuDrawerElem.addEventListener('hide.bs.offcanvas', (evt) => {
//     const accordionElem = document.getElementById('shop-dropdown');
//   });
// }
