window.getDataFromLocalStorageV2 = (key) =>
  JSON.parse(localStorage.getItem(key)) || [];

window.getHistoryStoragekey = () =>
  `v3-${window.DukaanData.DUKAAN_STORE.link}-search-history`;

window.setDataFromLocalStorage = (key, value) => {
  localStorage.setItem(getHistoryStoragekey(), JSON.stringify(value));
};

window.setHistory = (term) => {
  const prevHistory = getDataFromLocalStorageV2(getHistoryStoragekey());
  let newHistory;
  if (prevHistory.some((historyItem) => historyItem.term === term)) {
    newHistory = [
      { term },
      ...prevHistory.filter((historyItem) => historyItem.term !== term),
    ];
  } else {
    newHistory = [{ term }, ...prevHistory.slice(0, 3)];
  }
  setDataFromLocalStorage(getHistoryStoragekey(), newHistory);
  return newHistory;
};

window.clearRecentSearches = () => {
  localStorage.removeItem(getHistoryStoragekey());
  renderRecentSearches();
};

window.clearInputSearch = () => {
  document.querySelector('.search-input').value = '';
  document.querySelector('.search-meta').classList.remove('hidden');
  document.querySelector('.search-predictions').classList.add('hidden');
  document.querySelector('.prediction-section-heading').classList.add('hidden');
  document.querySelector('.cancel-btn').classList.add('hidden');
};

// Search
window.debounce = (callback, timeout = 300) => {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => {
      callback.apply(this, args);
    }, timeout);
  };
};

// window.fillPrediction = () => {};

window.renderRecentSearches = () => {
  const recentSearchList = getDataFromLocalStorageV2(getHistoryStoragekey());
  if (recentSearchList.length > 0) {
    document
      .querySelectorAll('.recent-searches')
      .forEach((el) => el.classList.remove('hidden'));

    const recentSearchListElements = document.querySelectorAll(
      '.recent-searches-list'
    );
    recentSearchListElements.forEach((recentSearchListEl) => {
      recentSearchListEl.replaceChildren();

      const recentSearchItemTemplate = document.getElementById(
        'recent-searches-template'
      );

      recentSearchList.forEach((search) => {
        const resentSearchItemElement = document.importNode(
          recentSearchItemTemplate.content,
          true
        );
        resentSearchItemElement.querySelector(
          '.recent-search-item-text'
        ).textContent = search.term;
        resentSearchItemElement
          .querySelector('.recent-search-item')
          .setAttribute('onclick', `redirectToSearchPage('${search.term}')`);
        recentSearchListEl.appendChild(resentSearchItemElement);
      });
    });
  } else {
    document
      .querySelectorAll('.recent-searches')
      .forEach((el) => el.classList.add('hidden'));
  }
};

window.renderPredictions = (predictions) => {
  const searchPredictionsElement = document.querySelector(
    '.search-predictions'
  );
  const heading = document.querySelector('.prediction-section-heading');
  document.querySelector('.cancel-btn').classList.remove('hidden');
  searchPredictionsElement.innerHTML = '';
  searchPredictionsElement.classList.remove('hidden');
  heading.classList.remove('hidden');
  document.querySelector('.search-meta').classList.add('hidden');

  const searchPredictionsTemplate = document.getElementById(
    'search-prediction-item'
  );

  if (!predictions.length) {
    document
      .querySelector('.prediction-section-heading')
      .classList.add('hidden');
    searchPredictionsElement.innerHTML = `<p class="no-prediction text-16 text-lg-20-28 font-regular">${DukaanData.DUKAAN_LANGUAGE.WE_FOUND_NO_SEARCH_RESULTS}!</p>`;
    return;
  }

  predictions.forEach((prediction) => {
    const categoryItemElement = document.importNode(
      searchPredictionsTemplate.content,
      true
    );
    categoryItemElement
      .querySelector('.search-prediction-item')
      .setAttribute(
        'href',
        `${DukaanData.DUKAAN_BASE_URL}/products/${prediction.slug}`
      );
    // categoryItemElement.querySelector('.fill-prediction').setAttribute('onclick', `fillPrediction(event, '${prediction.name}')`)
    categoryItemElement.querySelector('.prediction-label').textContent =
      prediction.name;

    const searchValues = DukaanData.DUKAAN_CATEGORY_LIST;
    const predictSubCategory = searchValues.find((searchSubCategory) => {
      if (searchSubCategory.parent_id == null) {
        return searchSubCategory.name;
      }
    });

    categoryItemElement.querySelector('.prediction-subcategory').textContent =
      predictSubCategory.name;

    categoryItemElement
      .querySelector('.prediction-image')
      .setAttribute('src', getCdnUrl(prediction.image, 100));

    searchPredictionsElement.appendChild(categoryItemElement);
  });
};

window.handleSearchRedirection = (event) => {
  window.location.href = dknGetSearchUrl(event.target.value);
};

// window.fetchStoreCategories = ({ cb, nextUrl = null, pageNumber = 1, isFirstFetch = true } = {}) => {
//   if (nextUrl) {
//     pageNumber += 1;
//     isFirstFetch = false;
//   }

//   if(isFirstFetch){
//     document.querySelector(".category-list").innerHTML = '';
//   }

//   fetch(`https://api2.mydukaan.io/api/product/buyer/${window.DukaanData.DUKAAN_STORE.link}/product-category-list/?page=${pageNumber}`, {
//     method: "GET",
//     headers: {
//       "Content-Type": "application/json",
//       // 'Content-Type': 'application/x-www-form-urlencoded',
//     },
//   })
//     .then((res) => {
//       return res.json();
//     })
//     .then((res) => {
//       let categories = res.results || [];
//       let next = res.next;
//       // categories = categories?.filter((category) => isParentCategory(category));

//       if (res && !!res.results && !!res.results.length) {
//         DukaanData.DUKAAN_CLIENT_CATEGORY_LIST = {
//           ...DukaanData.DUKAAN_CLIENT_CATEGORY_LIST,
//           ...categories.reduce((map, category) => {
//             map[category.uuid] = { ...category };
//             return map;
//           }, {}),
//         };
//       }
//       cb({ categories, next, pageNumber, isFirstFetch });

//     })
//     .catch((err) => {
//       console.log("fetchStoreCategories error : ", err);
//       cb({ categories: [], next: null, pageNumber: 1, isFirstFetch: true });
//     });
// };

window.renderCategoryList = (categories, nextUrl) => {
  // const { categories, next, pageNumber, isFirstFetch } = props;

  const categoryListElement = document.querySelector('.category-list');
  const categoryItemTemplate = document.getElementById('category-list-item');

  // if(isFirstFetch){
  //   categoryListElement.innerHTML = ''
  // }

  categories.forEach((category) => {
    const categoryItemElement = document.importNode(
      categoryItemTemplate.content,
      true
    );
    if (category?.parent_id !== null) {
      categoryItemElement
        .querySelector('a')
        .setAttribute(
          'href',
          `${window.DukaanData.DUKAAN_BASE_URL}/categories/${category.slug}?category_ids=${category.id}`
        );
    } else {
      categoryItemElement
        .querySelector('a')
        .setAttribute(
          'href',
          `${getCategoryCardLink(category, DukaanData?.DUKAAN_BASE_URL)}`
        );
    }
    categoryItemElement.querySelector('.category-name').textContent =
      category.name;
    categoryItemElement
      .querySelector('.category-image')
      .setAttribute('src', `${getCdnUrl(category.image, 500)}`);
    categoryListElement.appendChild(categoryItemElement);
  });

  const currentEventObserver = document.getElementById(
    'search-categories-list-observer'
  );

  if (nextUrl) {
    if (currentEventObserver) {
      currentEventObserver?.remove();
    }

    const newObserverElement = document.createElement('div');
    newObserverElement.setAttribute('id', 'search-categories-list-observer');
    categoryListElement.appendChild(newObserverElement);
    const viewallcategories = document.querySelector('.search-list-shimmer');
    viewallcategories?.classList.add('d-none');

    const observerElement = document.getElementById(
      'search-categories-list-observer'
    );

    const observer = new IntersectionObserver((entries) => {
      if (entries[0].isIntersecting) {
        fetchStoreCategoriesSearchDrawer({ nextUrl, cb: renderCategoryList });
      }
    });
    observer.observe(observerElement);
  } else {
    currentEventObserver?.remove();
  }
};

window.closeSearchDrawer = () => {
  const modal = document.getElementById('search-drawer');
  modal.classList.add('hidden');
  const searchCategoriesListElem = document.querySelector('.category-list');
  searchCategoriesListElem.innerHTML = '';
};

window.fetchStoreCategoriesSearchDrawer = null;

window.openSearchDrawer = () => {
  const modal = document.getElementById('search-drawer');
  modal.classList.remove('hidden');
  renderRecentSearches();
  fetchStoreCategoriesSearchDrawer = fetchStoreCategories();
  fetchStoreCategoriesSearchDrawer({ cb: renderCategoryList });
};

window.handleInputChange = (event) => {
  const query = event.target.value;
  if (query.length === 0) {
    document
      .querySelectorAll('.search-meta')
      .forEach((el) => el.classList.remove('hidden'));
    document
      .querySelectorAll('.search-predictions')
      .forEach((el) => el.classList.add('hidden'));
    renderRecentSearches();
  }
  if (query.length < 2) return;
  // setHistory(query);
  fetch(
    `${window.DukaanData.DUKAAN_ADVANCED_SEARCH_API_BASE_URL}/api/advanced-search/${window.DukaanData.DUKAAN_STORE.id}/`,
    {
      method: 'post',
      body: JSON.stringify({ query, page_size: 15 }),
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
      },
    }
  )
    .then((res) => res.json())
    .then((res) => {
      const predictions = res?.data?.products || [];
      renderPredictions(predictions);
    })
    .catch(() => {});
};
window.additionalCategoryProductCardChanges = (
  categoryProductCard,
  product
) => {
  const productPriceContainer =
    categoryProductCard.querySelector('.price-information');
  if (product.in_stock) {
    productPriceContainer.style.display = 'block';
  } else {
    productPriceContainer.style.display = 'none';
  }
};

window.splideSlideIndex = (allImages, primaryImage) => {
  const index = allImages?.indexOf(primaryImage);
  window?.splideSlider?.go(index);
};

window.handleModalChanges = (product, currentSKU) => {
  const element = document.querySelector('.product-variant-selection-modal');
  if (!element) return;

  // if (element.querySelector('.product-modal-badge .bxgy-badge')) {
  //   handleProductCardChange(element, product);
  // }
  if (element !== null) {
    if (element.querySelector('.product-name')) {
      element.querySelector('.product-name').textContent = `${product.name}`;
    }

    if (element.querySelector('.stock-left-message')) {
      if (currentSKU.inventory <= 10 && !!currentSKU.inventory) {
        element.querySelector('.stock-left-message').classList.remove('hidden');
        element.querySelector('.stock-left-message').textContent =
          `${DukaanData.DUKAAN_LANGUAGE.ONLY__INVENTORY_LEFT_IN_STOCK_HURRY_UP}!`.injectText(
            {
              inventory: currentSKU.inventory,
            }
          );
      } else {
        element.querySelector('.stock-left-message').classList.add('hidden');
        element.querySelector('.stock-left-message').textContent = ``;
      }
    }

    const originalPrice = currentSKU?.original_price;
    const sellingPrice = currentSKU?.selling_price;

    if (element.querySelector('.product-selling-price')) {
      element.querySelector('.product-selling-price').textContent =
        formatMoney(sellingPrice);
    }

    if (
      (((originalPrice - sellingPrice) / originalPrice) * 100).toFixed(0) > 0
    ) {
      if (element.querySelector('.product-original-price')) {
        element.querySelector('.product-original-price').textContent =
          formatMoney(originalPrice);
      }

      if (element.querySelector('.product-discount-badge')) {
        element.querySelector(
          '.product-discount-badge'
        ).textContent = `(${calculateDiscount(
          originalPrice,
          sellingPrice
        )}% off)`;
      }
      element
        .querySelector('.product-original-price')
        .classList.remove('hidden');
      element
        .querySelector('.product-discount-badge')
        .classList.remove('hidden');
    } else {
      element.querySelector('.product-original-price').classList.add('hidden');
      element.querySelector('.product-discount-badge').classList.add('hidden');
    }

    // renders product modal carousel with splide if exist.
    const productSplideTemplate = document.querySelector(
      '#product-modal-splide-container,#product-modal-splide-container_thumbnail'
    );

    if (productSplideTemplate) {
      const productSplideList = element.querySelector('.splide__list');
      const productThumbnailList = element.querySelector(
        '.splide__list_thumbnail'
      );

      if (typeof splideSlider === 'undefined') {
        if (product.all_images?.length > 1) {
          // main splide
          productSplideList.replaceChildren();
          // eslint-disable-next-line no-restricted-syntax
          for (const image of product?.all_images || []) {
            const productSplide = document.importNode(
              productSplideTemplate.content,
              true
            );
            productSplide
              .querySelector('.product-modal-splide-image')
              .setAttribute(
                'src',
                `${getCdnUrl(image || currentSKU.primary_image, 700)}`
              );
            productSplideList.appendChild(productSplide);
          }

          window.splideSlider = new Splide('#splide-product-modal-images', {
            type: 'loop',
            delay: '5000',
            rewind: true,
            autoplay: false,
            arrows: true,
            pauseOnHover: false,
            pagination: false,
            updateOnMove: true,
            classes: {
              arrows: 'splide__arrows',
            },
          });

          // thumbnail splide

          productThumbnailList.replaceChildren();
          // eslint-disable-next-line no-restricted-syntax
          for (const image of product?.all_images || []) {
            const productSplide = document.importNode(
              productSplideTemplate.content,
              true
            );
            productSplide
              .querySelector('.product-modal-splide-image')
              .setAttribute(
                'src',
                `${getCdnUrl(image || currentSKU.primary_image, 700)}`
              );
            productThumbnailList.appendChild(productSplide);
          }

          window.thumbnailSplideSlider = new Splide(
            '#splide-product-thumbnail-image',
            {
              type: 'slide',
              autoplay: false,
              arrows: true,
              pauseOnHover: false,
              pagination: false,
              interval: 1000,
              isNavigation: true,
              fixedWidth: '88px',
              fixedHeight: '110px',
              focus: 3,
              height: '465px',
              classes: {
                arrows: 'splide__arrows',
              },
            }
          );

          window.splideSlider.sync(window.thumbnailSplideSlider);
          window.splideSlider.mount();
          window.thumbnailSplideSlider.mount();
        } else if (element.querySelector('.product-images')) {
          element.querySelector('.product-images').replaceChildren();
          const wrapper = element.querySelector('.product-images');

          const imageWrapper = document.createElement('div');
          imageWrapper.classList.add('image-wrapper');
          const imgElem = document.createElement('img');
          imgElem.setAttribute('class', 'product-image');
          imageWrapper.appendChild(imgElem);
          wrapper.appendChild(imageWrapper);

          element
            .querySelector('.product-image')
            .setAttribute(
              'src',
              `${getCdnUrl(product.image || currentSKU.primary_image, 700)}`
            );
        }
      }
      if (!currentSKU?.primary_image.includes('category-def.jpg')) {
        const allImages = product?.all_images || product?.image;
        if (typeof splideSlideIndex !== 'undefined')
          splideSlideIndex(allImages, currentSKU.primary_image);
      }
    }

    if (currentSKU.meta.size) {
      const sizeListHeadingLabel = element.querySelector(
        '.size-selection-heading'
      );
      if (sizeListHeadingLabel) {
        if (currentSKU.meta.size.attributeLabel) {
          sizeListHeadingLabel.innerHTML =
            DukaanData.DUKAAN_LANGUAGE.SELECT__ATTRIBUTE.injectText({
              attribute: currentSKU.meta.size.attributeLabel,
            });
          // `Select ${currentSKU.meta.size.attributeLabel}`;
        } else {
          sizeListHeadingLabel.innerHTML =
            DukaanData.DUKAAN_LANGUAGE.SELECT_SIZE;
        }
      }
    }

    if (currentSKU.meta.color) {
      const colorListHeadingLabel = element.querySelector(
        '.color-selection-heading'
      );
      if (colorListHeadingLabel) {
        if (currentSKU.meta.color.attributeLabel) {
          colorListHeadingLabel.innerHTML =
            DukaanData.DUKAAN_LANGUAGE.SELECT__ATTRIBUTE.injectText({
              attribute: currentSKU.meta.color.attributeLabel,
            });
          // `Select ${currentSKU.meta.color.attributeLabel}`;
        } else {
          colorListHeadingLabel.innerHTML =
            DukaanData.DUKAAN_LANGUAGE.SELECT_COLOR;
        }
      }
    }
  }
};

// window.clearInputSearch = () => {
//   document.getElementById('search-input').value = '';
//   document.querySelector('.search-meta')?.classList.remove('hidden');
//   document.querySelector('search-predictions')?.classList.add('hidden');
// };
window.redirectToSearchPage = (value) => {
  value = value.trim();
  if (Boolean(value) && value.length > 0) {
    setHistory(value);
    window.location.href = dknGetSearchUrl(value);
  }
};

window.APP_IDS = {
  ...(window.APP_IDS || {}),
  STORE_LOCATOR: '6286104b4f1ca25e2256f6b7',
};

window.addEventListener('load', () => {
  axios
    .get(
      `https://apps.mydukaan.io/public/v2/apps/store/${DukaanData.DUKAAN_STORE.id}/`
    )
    .then((response) => {
      const { store_apps_list: appList } = response?.data || {};
      const availablePlugins = appList?.reduce((acc, item) => {
        if (item.isActive) {
          // eslint-disable-next-line no-underscore-dangle
          acc[item._id] = item;
        }
        return acc;
      }, {});
      const isStoreLocatorPresent = Boolean(
        !!availablePlugins && availablePlugins[APP_IDS.STORE_LOCATOR]
      );
      const storeLocatorTags = document.querySelectorAll('.store-locator-link');
      if (isStoreLocatorPresent) {
        storeLocatorTags.forEach((tag) => tag.classList.remove('hidden'));
      } else {
        storeLocatorTags.forEach((tag) => tag.remove());
      }
    });
});

window.getCustomDiscountText = (discount) => `(${discount}% OFF)`;

window.productCardAdditionalRenderer = (productCard, product) => {
  productCardImageCarouselRenderer(product, productCard);
};
window.redirectToSearchPageOnSubmit = (e) => {
  e.preventDefault();
  const formData = new FormData(document.querySelector('form#search-form'));
  const value = formData.get('search');
  redirectToSearchPage(value);
};

window.onInputChange = debounce((event) => handleInputChange(event), 300);

window.removeOverflowFromBody = () => {
  document.querySelector('body').classList.remove('overflow-hidden');
};

// Later must be changed to buy one get one offer

window.productCardAdditionalRenderer = (productCard, product) => {
  const {
    in_stock: inStock,
    selling_price: sellingPrice,
    original_price: originalPrice,
  } = product;
  if (!inStock) {
    window.q$
      .select('.dkn-product-card-sold-out-badge', productCard)
      .removeClass('d-none');
  } else {
    const discount = window.getDiscountPercentValue(
      sellingPrice,
      originalPrice,
      window.q$
    );
    if (discount) {
      window.q$;
      // .select('.dkn-product-card-sale-badge', productCard)
      // .removeClass('d-none');
    }
  }
};

window.fetchCustomStoreSubCategories = () => {
  // Common function
  let offset = 0;
  let initialized = true;
  const offsetCount = 10;

  // eslint-disable-next-line no-undef, no-return-assign
  return (fetchFn = ({
    nextUrl = false,
    cb,
    loadPoint = null,
    firstFetch = false,
    ...rest
  } = {}) => {
    const { categorySlug } = rest;
    if (!categorySlug) return;

    const fetchUrl = `https://api2.mydukaan.io/api/product/buyer/${window.DukaanData.DUKAAN_STORE.link}/product-category-list/?parent_slug=${categorySlug}&offset=${offset}`;

    if (nextUrl) {
      offset += offsetCount;
      initialized = false;
      firstFetch = false;
    }

    if (initialized) offset += offsetCount;

    fetch(fetchUrl, {
      method: 'get',
      headers: {
        'Content-Type': 'application/json',
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
        // 'Content-Type': 'application/x-www-form-urlencoded',
      },
    })
      .then((res) => res.json())
      .then((res) => {
        const categories = res?.results || [];
        const next = !(categories.length < offsetCount);
        DukaanData.DUKAAN_CLIENT_SUB_CATEGORY_LIST = {
          ...DukaanData?.DUKAAN_CLIENT_SUB_CATEGORY_LIST,
          ...categories?.reduce((map, category) => {
            map[category.uuid] = { ...category };
            return map;
          }, {}),
        };
        cb(loadPoint, categories, next, firstFetch, rest);
      })
      .catch((err) => {
        console.log('fetchStoreSubCategories error : ', err);
        cb([], null);
      });
  });
};

window.subCategoriesRenderer = (
  mountElement,
  categories,
  nextUrl,
  firstFetch,
  { templateId = 'header-all-category-card-template', additionalRenderer }
) => {
  if (firstFetch) {
    mountElement.innerHTML = '';
  }
  const categoryCardTemplate = document.getElementById(templateId);

  categories?.forEach((category) => {
    const categoryCard = document.importNode(
      categoryCardTemplate.content,
      true
    );

    const categoryUrl = getCategoryCardLink(category);

    categoryCard
      .querySelectorAll('a')
      .forEach((el) => el.setAttribute('href', categoryUrl));

    categoryCard.querySelector('.header-dropdown-item').textContent =
      category.name;

    if (typeof additionalRenderer !== 'undefined') {
      additionalRenderer(categoryCard, category);
    }

    mountElement.appendChild(categoryCard);
  });
};

window.initSubcategoryHeader = (event) => {
  const { categorySlug, categoryCount } = event.dataset;

  if (categoryCount) {
    window.q$
      .select('.header-sub-category-item-dropdown')
      .elem.classList.add('hidden');
    window.fetchHeaderSubCategoriesInit =
      window.fetchCustomStoreSubCategories();

    if (categorySlug) {
      window.fetchHeaderSubCategoriesInit({
        cb: window.subCategoriesRenderer,
        categorySlug,
        firstFetch: true,
        templateId: 'header-all-category-card-template',
        loadPoint: window.q$.select('header-all-sub-category-list-load-point')
          .elem,
        additionalRenderer: () => {
          window.q$
            .select('.header-sub-category-item-dropdown')
            .removeClass('hidden');
        },
      });
    }
  }
};

window.commonInitializer = () => {
  dknInitHeader();
  GAPage();
};

// const formSearch = document.querySelector('#search-form');
// window.changeSVGcolor = () => {
//   formSearch.addEventListener('mousedown', (e) => {
//     if (!(e.target.value > 0)) {
//       document
//         .querySelector('.searchCircle')
//         .setAttribute('fill', 'var( --black-12)');
//       document
//         .querySelector('.searchline')
//         .setAttribute('fill', 'var( --black-12)');
//     }
//   });
// };
// changeSVGcolor();

window.dropDownClose = () => {
  window.q$.select('.header-sub-category-item-dropdown').addClass('hidden');
};

window.getCustomTotalWishlistCountText = (totalWishlistCount) =>
  `${
    window.DukaanData.DUKAAN_LANGUAGE.MY_WISHLIST || 'My wishlist'
  } (${totalWishlistCount})`;

window.couponPageProductCardTemplateId = 'dkn-product-card-template';
window.productCardTemplateId = 'dkn-product-card-template';
