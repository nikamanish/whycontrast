window.getSerializedItem = (data) => {
  if (!data?.length) return {};
  const serializedData = {};
  data?.forEach((item) => {
    serializedData[item.title] = item;
  });
  return serializedData;
};
window.getSerializedThemeSectionsData = (themeData) => {
  if (!themeData?.length) return {};
  const serializedThemeData = {};
  themeData?.forEach((item) => {
    serializedThemeData[item.title] = getSerializedItem(item.sections);
  });
  return serializedThemeData;
};
window.appInitializer = () => {
  hashProductMap(window.DukaanData.DUKAAN_CATALOG);
  druidStorePageView();
  fetchCouponsAndOffersOnIndex();
  if (document.querySelector('#hero-splide-image'))
    new Splide('#hero-splide-image', {
      type: 'loop',
      autoplay: true,
      interval: 5000,
      padding: '8rem',
      gap: 40,
      pagination: DukaanData?.DUKAAN_WEB_BANNERS.length > 1 || false,
      arrows: true,
      perPage: 1,
    }).mount();
  if (document.querySelector('#hero-splide-image-mobile'))
    new Splide('#hero-splide-image-mobile', {
      type: 'loop',
      autoplay: false,
      interval: 5000,
      pagination: DukaanData?.DUKAAN_MOBILE_BANNERS.length > 1 || false,
      arrows: false,
      perPage: 1,
    }).mount();
  const renderCategoryDesktop = () => {
    section = 'splide-scrolling-cards';
    const scrollingcards = new Splide(`#${section}`, {
      type: 'slide',
      autoplay: false,
      arrows: false,
      pauseOnHover: false,
      perPage: 3,
      focus: 0,
      gap: 32,
      pagination: DukaanData?.DUKAAN_CATEGORY_LIST.length > 3 || false,
      classes: {
        pagination: `splide__pagination ${section}-pagination`,
      },
    });
    scrollingcards.mount();
    if (document.querySelector(`.${section}-pagination`)) {
      const splideCatLi = document
        .querySelector(`.${section}-pagination`)
        .getElementsByTagName('li');
      const productsLength = DukaanData?.DUKAAN_CATEGORY_LIST.length + 1;
      const paginationWidth = `${100 / Math.ceil(productsLength / 1)}%`;
      for (let i = splideCatLi.length - 1; i >= 0; i--) {
        splideCatLi[i].style.width = paginationWidth;
      }
    }
  };
  if (document.querySelector('#splide-scrolling-cards')) {
    renderCategoryDesktop();
  }

  const renderCategoryMobile = () => {
    section = 'splide-scrolling-cards-mobile';
    const scrollingcardsmobile = new Splide(`#${section}`, {
      type: 'slide',
      perPage: 1,
      autoplay: false,
      arrows: false,
      gap: 24,
      pagination: true,
      classes: {
        pagination: `splide__pagination ${section}-pagination`,
      },
      // padding: { right: 140 },
    });
    scrollingcardsmobile.mount();
    if (document.querySelector(`.${section}-pagination`)) {
      const splideCatLi = document
        .querySelector(`.${section}-pagination`)
        .getElementsByTagName('li');
      const { perPage } = scrollingcardsmobile.options;
      const productsLength = DukaanData?.DUKAAN_CATEGORY_LIST.length + 1;
      const paginationWidth = `${100 / Math.ceil(productsLength / perPage)}%`;
      for (let i = splideCatLi.length - 1; i >= 0; i--) {
        splideCatLi[i].style.width = paginationWidth;
      }
    }
  };
  if (document.querySelector('#splide-scrolling-cards-mobile')) {
    renderCategoryMobile();
  }

  const renderTestimonial = () => {
    section = 'customer-testimonials-home-page';
    // products = 4;
    const customertestimonials = new Splide(`#${section}`, {
      type: 'slide',
      autoplay: false,
      arrows: false,
      pauseOnHover: false,
      perPage: 2,
      gap: 32,
      // padding: { right: products > 2 ? 110 : 0 },
      pagination: true,
      classes: {
        pagination: `splide__pagination ${section}-pagination`,
      },
      breakpoints: {
        768: {
          perPage: 1,
          arrows: false,
          pagination: true,
          gap: 16,
        },
      },
    });
    customertestimonials.mount();
    if (document.querySelector(`.${section}-pagination`)) {
      const splideCatLi = document
        .querySelector(`.${section}-pagination`)
        .getElementsByTagName('li');
      const { perPage } = customertestimonials.options;
      const productsLength = document.querySelectorAll(
        `#customer-testimonials-home-page .splide__slide`
      ).length;
      // const productsLength = products.length;
      const paginationWidth = `${100 / Math.ceil(productsLength / perPage)}%`;
      for (let i = splideCatLi.length - 1; i >= 0; i--) {
        splideCatLi[i].style.width = paginationWidth;
      }
    }
  };
  if (document.querySelector('#customer-testimonials-home-page')) {
    renderTestimonial();
  }
  const categoryListElements = q$.selectAll(
    '.home-page-category-product-list'
  ).elem;
  categoryListElements.forEach((categoryElem) => {
    const categoryIds = [Number(categoryElem.dataset.categoryId)];
    const payload = {
      category_ids: categoryIds,
      page_size: 8,
      offset: 0,
    };
    axios
      .post(
        `${window.DukaanData.DUKAAN_ADVANCED_SEARCH_API_BASE_URL}/api/advanced-search/${DukaanData.DUKAAN_STORE.id}/`,
        {
          ...payload,
        },
        {
          headers: {
            'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
          },
        }
      )
      .then((response) => {
        const { products } = response?.data?.data || [];
        const bestsell = document.querySelector('.latestdropshimmer');
        bestsell.classList.add('d-none');
        DukaanData.PRODUCTS_MAP = {
          ...DukaanData.PRODUCTS_MAP,
          ...products?.reduce((map, product) => {
            const serializedSKUs = serializeSKUs(product.skus || []);
            const attributes = getAllProductAttributeValues(serializedSKUs);
            map[product.uuid] = {
              ...product,
              skus: serializedSKUs,
              attributes,
            };
            return map;
          }, {}),
        };
        productListRenderer(categoryElem, products, {
          getCustomDiscountText: window.getCustomDiscountText,
          templateId: 'product-card-template',
          additionalRenderer: productCardAdditionalRenderer,
        });
      })
      .catch(() => {});
  });
};
