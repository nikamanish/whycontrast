window.scrollToSKUImage = (activeSKU) => {
  const primaryImage = activeSKU?.primary_image;
  const allImages = DukaanData?.DUKAAN_PRODUCT?.all_images;
  if (allImages?.length > 0) {
    const index = allImages?.indexOf(primaryImage);
    if (index >= 0) {
      window?.mainSplide?.go(index);
      window?.thumbnailSplide?.go(index);
    }
  }
};

window.appInitializer = () => {
  const { isMobile } = deviceType();
  SIMILAR_PRODUCT_LIMIT = isMobile ? 6 : 8;

  const productFromServer = DukaanData.DUKAAN_PRODUCT;
  const serializedSKUs = serializeSKUs(productFromServer.skus || []);
  const attributes = getAllProductAttributeValues(serializedSKUs);
  const product = {
    ...productFromServer,
    skus: serializedSKUs,
    attributes,
  };
  window.DukaanData.PRODUCTS_DETAILS = product;
  window.DukaanData.PRODUCTS_MAP = {
    ...(DukaanData.PRODUCTS_MAP || []),
    [product.uuid]: product,
  };

  productPageCommonFnCalls(product);

  window.mainSplide = new Splide('#splide-product-main', {
    type: 'loop',
    delay: '5000',
    autoplay: false,
    rewind: true,
    pagination: false,
    arrows: DukaanData.DUKAAN_PRODUCT.all_images.length > 1,
    width: 514,
    fixedHeight: '646px',
    updateOnMove: true,
    breakpoints: {
      992: {
        gap: '16px',
        width: '100%',
        fixedHeight: '410px',
        pagination: false,
        arrows: DukaanData.DUKAAN_PRODUCT.all_images.length > 1,
      },
    },
  });

  window.mainSplide.on('click', (e) => {
    window.playProductVideo(e);
  });

  window.thumbnailSplide = new Splide('#splide-product-thumbnail', {
    type: 'slide',
    autoplay: false,
    arrows: false,
    direction: 'ttb',
    perPage: 4,
    fixedWidth: '167px',
    fixedHeight: '209px',
    height: '100%',
    pagination: false,
    isNavigation: true,
    breakpoints: {
      767: {
        direction: 'ltr',
        arrows: false,
        pagination: false,
      },
    },
  });

  window.thumbnailSplide.on('click', () => {
    window.pauseAllProductVideos();
  });

  window?.mainSplide?.sync(window.thumbnailSplide);
  window?.mainSplide?.mount();
  window?.thumbnailSplide?.mount();
  window.splideCarousel = undefined;
};
