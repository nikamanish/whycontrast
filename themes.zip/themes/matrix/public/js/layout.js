window.showMenuDropdown = (event, parentId, index) => {
  const { target } = event;
  if (index === '0') {
    q$.selectAll(`.second-menu-item-list ul.menu-items-list`).addClassAll(
      'hidden'
    );
    q$.selectAll(`.third-menu-item-list ul.menu-items-list`).addClassAll(
      'hidden'
    );
    q$.selectAll(`.first-menu-item-list ul li`).removeClassAll(
      'active-nav-item'
    );
    q$.selectAll(`.second-menu-item-list ul li`).removeClassAll(
      'active-nav-item'
    );
    q$.selectAll(`.third-menu-item-list ul li`).removeClassAll(
      'active-nav-item'
    );
  } else if (index === '1') {
    q$.selectAll(`.third-menu-item-list ul.menu-items-list`).addClassAll(
      'hidden'
    );
    q$.selectAll(`.second-menu-item-list ul li`).removeClassAll(
      'active-nav-item'
    );
    q$.selectAll(`.third-menu-item-list ul li`).removeClassAll(
      'active-nav-item'
    );
  } else if (index === '2') {
    q$.selectAll(`.third-menu-item-list ul li`).removeClassAll(
      'active-nav-item'
    );
  }
  target.classList.add('active-nav-item');
  q$.select(
    `ul.menu-items-list[data-parent-dropdown-id="${parentId}"]`
  ).removeClass('hidden');
};
window.addEventListener('DOMContentLoaded', () => {
  const menuItems = document.querySelectorAll(
    '.menu-dropdown:not(.menu-dropdown__button)'
  );

  let i = 0;
  for (i = 0; i < menuItems.length; i += 1) {
    menuItems[i].addEventListener('mouseenter', (event) => {
      document.querySelectorAll('.menu-drop-ul')?.forEach((el) => {
        el?.classList.add('hidden');
      });
      const { target: parentMenuItem } = event;
      const menuId = parentMenuItem.dataset.menuId || '';
      const menuDropDown = document.getElementById(menuId);
      if (menuDropDown) {
        menuDropDown.classList.remove('hidden');
        menuDropDown.style.position = 'absolute';
        menuDropDown.style.top = '100%';
        if (!menuDropDown.classList.contains('overflow-menu-container')) {
          menuDropDown.style.left = `${
            parentMenuItem.getBoundingClientRect().left
          }px`;
        }
      }
      document.addEventListener('mousemove', (e) => {
        const { target: hoverTarget } = e;
        const mainHeader = document.querySelector('.header-main');
        if (
          !(
            menuDropDown?.contains(hoverTarget) ||
            mainHeader?.contains(hoverTarget)
          )
        ) {
          menuDropDown?.classList?.add('hidden');
          document.removeEventListener('mousemove', () => {}, true);
        }
      });
    });
  }
});
window.addEventListener('DOMContentLoaded', () => {
  axios
    .get(
      `https://apps.mydukaan.io/public/v2/apps/store/${DukaanData.DUKAAN_STORE.id}/`
    )
    .then((response) => {
      const { store_apps_list: appList } = response.data;
      const availablePlugins = appList?.reduce((acc, item) => {
        if (item.isActive) {
          // eslint-disable-next-line no-underscore-dangle
          acc[item._id] = item;
        }
        return acc;
      }, {});
      const isStoreLocatorPresent = Boolean(
        !!availablePlugins && availablePlugins[APP_IDS.STORE_LOCATOR]
      );
      const storeLocatorTags = document.querySelectorAll('.store-locator-link');
      if (isStoreLocatorPresent) {
        storeLocatorTags.forEach((tag) => tag.classList.remove('hidden'));
      } else {
        storeLocatorTags.forEach((tag) => tag.remove());
      }
    })
    .finally(() => {
      const menuItems = document.querySelectorAll(
        '.menu-dropdown:not(.menu-dropdown__button)'
      );
      const mainMenu = document.querySelector('.menu-main');
      const mainMenuWidth = mainMenu.offsetWidth;
      let menuWidth = 0;
      let i = 0;
      for (i = 0; i < menuItems.length; i += 1) {
        menuWidth += menuItems[i].offsetWidth + 24;
        if (
          menuWidth >=
          mainMenuWidth -
            document.querySelector('.menu-dropdown__button').offsetWidth
        ) {
          document.fonts.ready.then(() => {
            document
              .querySelector('.menu-dropdown__button')
              .classList.remove('hidden');
          });
          break;
        }
      }
    })
    .catch(() => {});
});
window.handleOpenMenuChild = (e) => {
  e.currentTarget
    .querySelectorAll('svg')
    .forEach((elem) => elem.classList.toggle('hidden'));
  e.currentTarget
    .closest('.menu-item-wrapper')
    .querySelector('.mobile-menu-drop-down')
    .classList.toggle('hidden');
};

window.navContainerHandler = async () => {
  const navLinksDiv = document.querySelector('.navLinksWrapper');
  const navLinksUl = document.querySelector('.navLinks');
  const sidebarIcon = document.querySelector('.navHamburger');

  if (!sidebarIcon) return;

  if (navLinksUl?.scrollWidth <= navLinksDiv?.clientWidth) {
    sidebarIcon.classList.add('hidden');
    navLinksDiv.classList.remove('showGradient');
  } else {
    const ready = await document.fonts.ready;
    if (ready) {
      sidebarIcon.classList.remove('hidden');
      navLinksDiv.classList.add('showGradient');
    }
  }
};

window.openNavSidebar = () => {
  const modal = document.getElementById('sidebar-modal');
  modal.classList.remove('hidden');
};

window.closeNavSidebar = () => {
  const modal = document.getElementById('sidebar-modal');
  modal.classList.add('hidden');
};

window.addEventListener('DOMContentLoaded', () => {
  window.HISTORY_STORAGE_KEY = `v3-${window.DukaanData.DUKAAN_STORE.link}-search-history`;
});

window.handleNav = (activeTab) => {
  const tab = document.querySelector(`.${activeTab}`);
  const navList = document.getElementsByClassName('navButton active-nav');
  Array.from(navList).forEach((nav) => {
    nav.classList.remove('active-nav');
  });
  tab.classList.add('active-nav');
};

window.onDrawerOpened = () => {
  const drawer = document.querySelector('.sidebar');
  drawer.style.position = 'fixed';
  drawer.style.top = 0;
  drawer.style.left = 0;
  drawer.style.right = 0;
  drawer.style.bottom = 0;
  drawer.style.display = 'block';
  drawer.style.flexDirection = 'column';
  drawer.style.backgroundColor = 'white';
  drawer.style.zIndex = '10000';
  const body = document.getElementsByTagName('BODY')[0];
  body.style.overflow = 'hidden';
};

window.onDrawerClosed = (e) => {
  e.preventDefault();
  e.stopPropagation();
  const drawer = document.querySelector('.sidebar');
  drawer.style.display = 'none';
  const body = document.getElementsByTagName('BODY')[0];
  body.style.overflow = '';
};

window.openCategoryList = () => {
  const popoverElement = document.getElementById('categoryPopupWrapper');
  popoverElement.replaceChildren();
  const popup = document.getElementById('category-popup');
  const item = document.importNode(popup.content, true);
  popoverElement.appendChild(item);
};

window.closeCategoryList = () => {
  const popoverModal = document.getElementById('popover-modal');
  popoverModal.classList.add('display-none');
};

window.handleVariantChange = (productUUID) => {
  const element = document.querySelector('product-variant-selection-modal');
  const addToBagElement = element.querySelector('add-to-bag-button');
  const buyNowElement = element.querySelector('buy-now-button-load-point');
  const formData = new FormData(
    element.querySelector('form#variant-selection')
  );
  const data = [...formData.entries()].reduce((acc, [key, value]) => {
    acc[key] = value;
    return acc;
  }, {});

  const product = DukaanData.PRODUCTS_MAP[productUUID];
  const { skus } = product;
  const currentSKU = skus.find(
    (sku) =>
      (!data.size || sku.meta.size.value === data.size) &&
      (!data.color || sku.meta.color.value === data.color)
  );
  if (!currentSKU) return;

  if (data.color) {
    getTickColor(data.color);
  }

  const sizeItem = element.querySelector(`label[for='m-size-${data.size}']`);

  if (sizeItem) {
    sizeItem.querySelector('input').checked = true;
    sizeItem.querySelector('.size-selling-price').textContent = formatMoney(
      currentSKU.selling_price
    );
    if (currentSKU.selling_price < currentSKU.original_price) {
      sizeItem.querySelector('.size-original-price').classList.remove('hidden');
      sizeItem.querySelector('.size-original-price').textContent = formatMoney(
        currentSKU.original_price
      );
    } else {
      sizeItem.querySelector('.size-original-price').classList.add('hidden');
    }
  }

  addToBagElement.dataset.productUuid = productUUID;
  addToBagElement.dataset.skuUuid = currentSKU.uuid;
  addToBagButtonRenderer(addToBagElement);

  buyNowElement.dataset.productUuid = productUUID;
  buyNowElement.dataset.skuUuid = currentSKU.uuid;
  buyNowButtonRenderer(buyNowElement);
};

window.commonInitializer = () => {
  navContainerHandler();
  toggleCouponFooter();
  GAPage();
  // megamenu
  initSidebarMenuItems();

  if (DukaanData?.DUKAAN_STORE?.additional_meta?.hasB2BFlow) {
    initDukaanAuth(handleLoginSuccess);
  }
};

window.handleAfterLogin = () => {
  getUserData().then((userData) => {
    const B2B_SLUG = 'b2b';
    const tier = userData?.customer_tiers?.find(
      (item) => item?.slug === B2B_SLUG
    );
    if (!tier) {
      openRequestAccessModal();
    }
  });
};

// search to be copied from here
window.getDataFromLocalStorageV2 = (key) =>
  JSON.parse(localStorage.getItem(key)) || [];

window.getHistoryStoragekey = () =>
  `v3-${window.DukaanData.DUKAAN_STORE.link}-search-history`;

window.setDataFromLocalStorage = (key, value) => {
  localStorage.setItem(getHistoryStoragekey(), JSON.stringify(value));
};

window.setHistory = (term) => {
  const prevHistory = getDataFromLocalStorageV2(getHistoryStoragekey());
  let newHistory;
  if (prevHistory.some((historyItem) => historyItem.term === term)) {
    newHistory = [
      { term },
      ...prevHistory.filter((historyItem) => historyItem.term !== term),
    ];
  } else {
    newHistory = [{ term }, ...prevHistory.slice(0, 3)];
  }
  setDataFromLocalStorage(getHistoryStoragekey(), newHistory);
  return newHistory;
};

window.clearRecentSearches = () => {
  localStorage.removeItem(getHistoryStoragekey());
  renderRecentSearches();
};

window.clearInputSearch = () => {
  document.querySelector('.search-input').value = '';
  document.querySelector('.search-meta').classList.remove('hidden');
  document.querySelector('.search-predictions').classList.add('hidden');
  document.querySelector('.prediction-section-heading').classList.add('hidden');
  document.querySelector('.cancel-btn').classList.add('hidden');
};

window.debounce = (callback, timeout = 300) => {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => {
      callback.apply(this, args);
    }, timeout);
  };
};

// window.fillPrediction = () => {};

window.renderRecentSearches = () => {
  const recentSearchList = getDataFromLocalStorageV2(getHistoryStoragekey());
  if (recentSearchList.length > 0) {
    document
      .querySelectorAll('.recent-searches')
      .forEach((el) => el.classList.remove('hidden'));

    const recentSearchListElements = document.querySelectorAll(
      '.recent-searches-list'
    );
    recentSearchListElements.forEach((recentSearchListEl) => {
      recentSearchListEl.replaceChildren();

      const recentSearchItemTemplate = document.getElementById(
        'recent-searches-template'
      );

      recentSearchList.forEach((search) => {
        const resentSearchItemElement = document.importNode(
          recentSearchItemTemplate.content,
          true
        );
        resentSearchItemElement.querySelector(
          '.recent-search-item-text'
        ).textContent = search.term;
        resentSearchItemElement
          .querySelector('.recent-search-item')
          .setAttribute('onclick', `redirectToSearchPage('${search.term}')`);
        recentSearchListEl.appendChild(resentSearchItemElement);
      });
    });
  } else {
    document
      .querySelectorAll('.recent-searches')
      .forEach((el) => el.classList.add('hidden'));
  }
};

window.renderPredictions = (predictions) => {
  const searchPredictionsElements = document.querySelectorAll(
    '.search-predictions'
  );

  document.querySelector('.cancel-btn').classList.remove('hidden');
  document
    .querySelectorAll('.search-meta')
    .forEach((item) => item.classList.add('hidden'));

  const searchPredictionsTemplate = document.getElementById(
    'search-prediction-item'
  );

  searchPredictionsElements.forEach((searchPredictionsElement) => {
    // eslint-disable-next-line no-param-reassign
    searchPredictionsElement.innerHTML = '';
    searchPredictionsElement.classList.remove('hidden');
    if (!predictions.length) {
      document
        .querySelector('.prediction-section-heading')
        .classList.add('hidden');
      // eslint-disable-next-line no-param-reassign
      searchPredictionsElement.innerHTML = `<p class="no-prediction">${DukaanData.DUKAAN_LANGUAGE.NO_RESULTS_FOUND}</p>`;
      return;
    }

    predictions.forEach((prediction) => {
      const categoryItemElement = document.importNode(
        searchPredictionsTemplate.content,
        true
      );
      categoryItemElement
        .querySelector('.search-prediction-item')
        .setAttribute(
          'href',
          `${DukaanData.DUKAAN_BASE_URL}/products/${prediction.slug}`
        );
      // categoryItemElement.querySelector('.fill-prediction').setAttribute('onclick', `fillPrediction(event, '${prediction.name}')`)
      categoryItemElement.querySelector('.prediction-label').textContent =
        prediction.name;

      searchPredictionsElement.appendChild(categoryItemElement);
    });
  });
};

// window.fetchStoreCategories = ({ nextUrl = null, cb } = {}) => {
//   let fetchUrl = `${window.DukaanData.CLIENT_API2_ENDPOINT}/api/product/buyer/${window.DukaanData.DUKAAN_STORE.link}/product-category-list/`;
//   let isFirstFetch = true;

//   if (nextUrl) {
//     fetchUrl = nextUrl;
//     isFirstFetch = false;
//   }

//   fetch(fetchUrl, {
//     method: "GET",
//     headers: {
//       "Content-Type": "application/json",
//       // 'Content-Type': 'application/x-www-form-urlencoded',
//     },
//   })
//     .then((res) => {
//       return res.json();
//     })
//     .then((res) => {
//       const categories = res.results || [];
//       const next = res.next;
//         DukaanData.DUKAAN_CLIENT_CATEGORY_LIST = {
//           ...DukaanData?.DUKAAN_CLIENT_CATEGORY_LIST,
//           ...categories?.reduce((map, category) => {
//             map[category.uuid] = { ...category };
//             return map;
//           }, {}),
//         };
//         cb(categories, next);
//     })
//     .catch((err) => {
//       console.log("fetchStoreCategories error : ", err);
//       cb([], null);
//     });
// };

window.renderShimmerForCategoriesInSearch = (count) => {
  const categoryListElems = document.querySelectorAll('.category-list');
  const shimmerTemplate = document.getElementById('search-card-shimmer');
  categoryListElems?.forEach((categoryListElem) => {
    const shimmerCard = document.importNode(shimmerTemplate.content, true);
    [...Array(count)].forEach(() => categoryListElem.appendChild(shimmerCard));
  });
};

window.renderCategoryList = (categories, nextUrl, firstFetch = false) => {
  if (categories.length === 0 && firstFetch) {
    document
      .querySelectorAll('.category-no-result')
      ?.forEach((el) => el.classList.remove('hidden'));
    document
      .querySelectorAll('.search-content')
      ?.forEach((el) => el.classList.add('hidden'));
    return;
  }

  const shimmerElems = document.querySelectorAll('.category-list-shimmer-item');
  if (shimmerElems) {
    shimmerElems.forEach((shimmerElem) => shimmerElem.remove());
  }

  const categoryListElements = document.querySelectorAll('.category-list');
  const categoryItemTemplate = document.getElementById('category-list-item');

  categoryListElements.forEach((categoryListElement) => {
    categories.forEach((category) => {
      const categoryItemElement = document.importNode(
        categoryItemTemplate.content,
        true
      );
      categoryItemElement
        .querySelector('a')
        .setAttribute('href', `${getCategoryCardLink(category)}`);
      categoryItemElement.querySelector('.category-name').textContent =
        category.name;
      categoryItemElement
        .querySelector('.category-image')
        .setAttribute('src', `${getCdnUrl(category.image, 500)}`);
      categoryListElement.appendChild(categoryItemElement);
    });

    const currentEventObserver = categoryListElement.querySelector(
      '#search-categories-list-observer'
    );

    if (nextUrl) {
      if (currentEventObserver) {
        currentEventObserver?.remove();
      }

      const newObserverElement = document.createElement('div');
      newObserverElement.setAttribute('id', 'search-categories-list-observer');
      categoryListElement.appendChild(newObserverElement);

      const observerElement = categoryListElement.querySelector(
        '#search-categories-list-observer'
      );

      const observer = new IntersectionObserver(
        (entries) => {
          if (entries[0].isIntersecting) {
            // renderShimmerForCategoriesInSearch(4);
            fetchStoreCategoriesSearchDrawer({
              nextUrl,
              cb: renderCategoryList,
            });
          }
        },
        {
          threshold: 1,
        }
      );
      observer.observe(observerElement);
    } else {
      currentEventObserver?.remove();
    }
  });
};

window.closeSearchDrawer = () => {
  const modal = document.getElementById('m-search-modal');
  modal.classList.add('hidden');
};

window.openSearchDrawer = () => {
  const modal = document.getElementById('m-search-modal');
  modal.classList.remove('hidden');
  renderSearchContent();
};

window.handleInputChange = (event) => {
  const query = event.target.value;
  if (query.length === 0) {
    document
      .querySelectorAll('.search-meta')
      .forEach((el) => el.classList.remove('hidden'));
    document
      .querySelectorAll('.search-predictions')
      .forEach((el) => el.classList.add('hidden'));
    renderRecentSearches();
  }
  if (query.length < 2) return;
  // setHistory(query);
  fetch(
    `${window.DukaanData.DUKAAN_ADVANCED_SEARCH_API_BASE_URL}/api/advanced-search/${window.DukaanData.DUKAAN_STORE.id}/`,
    {
      method: 'post',
      body: JSON.stringify({ query, page_size: 15 }),
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
      },
    }
  )
    .then((res) => res.json())
    .then((res) => {
      const predictions = res?.data?.products || [];
      renderPredictions(predictions);
    })
    .catch(() => {});
};

window.redirectToSearchPage = (value) => {
  // eslint-disable-next-line no-param-reassign
  value = value.trim();
  if (Boolean(value) && value.length > 0) {
    setHistory(value);
    window.location.href = dknGetSearchUrl(value);
  }
};

window.redirectToSearchPageOnSubmit = (e) => {
  e.preventDefault();
  const formData = new FormData(document.querySelector('form#search-form'));
  const value = formData.get('search');
  redirectToSearchPage(value);
};

window.mobileRedirectToSearchPageOnSubmit = (e) => {
  e.preventDefault();
  const formData = new FormData(document.querySelector('form#m-search-form'));
  const value = formData.get('search');
  redirectToSearchPage(value);
};

window.onInputChange = debounce((event) => handleInputChange(event), 300);

window.openDesktopDropDown = () => {
  document.querySelector('.searchbar-backdrop').classList.remove('hidden');
  document.querySelector('.search-dropdown').classList.remove('hidden');
  document.querySelector('.search-input').focus();
  renderSearchContent();
};

window.closeDesktopDropDown = () => {
  document.querySelector('.searchbar-backdrop').classList.add('hidden');
  document.querySelector('.search-dropdown').classList.add('hidden');
};

window.fetchStoreCategoriesSearchDrawer = null;

window.renderSearchContent = () => {
  const searchContentWrappers = document.querySelectorAll(
    '.search-content-wrapper'
  );
  const searchContentTemplate = document.getElementById('search-content');

  searchContentWrappers.forEach((item) => {
    const searchContent = document.importNode(
      searchContentTemplate.content,
      true
    );
    // eslint-disable-next-line no-param-reassign
    item.innerHTML = '';
    item.appendChild(searchContent);
  });
  renderRecentSearches();
  fetchStoreCategoriesSearchDrawer = fetchStoreCategories();
  fetchStoreCategoriesSearchDrawer({
    cb: renderCategoryList,
    loadPoint: '.category-list',
    firstFetch: true,
  });
};

window.APP_IDS = {
  ...(window.APP_IDS || {}),
  STORE_LOCATOR: '6286104b4f1ca25e2256f6b7',
};

window.addEventListener('DOMContentLoaded', () => {
  axios
    .get(
      `https://apps.mydukaan.io/public/v2/apps/store/${DukaanData.DUKAAN_STORE.id}/`
    )
    .then((response) => {
      const { store_apps_list: appList } = response?.data || {};
      const availablePlugins = appList?.reduce((acc, item) => {
        if (item.isActive) {
          // eslint-disable-next-line no-underscore-dangle
          acc[item._id] = item;
        }
        return acc;
      }, {});
      const isStoreLocatorPresent = Boolean(
        !!availablePlugins && availablePlugins[APP_IDS.STORE_LOCATOR]
      );
      const storeLocatorTags = document.querySelectorAll('.store-locator-link');
      if (isStoreLocatorPresent) {
        storeLocatorTags.forEach((tag) => tag.classList.remove('hidden'));
      } else {
        storeLocatorTags.forEach((tag) => tag.remove());
      }
      navContainerHandler();
    });
});

window.getCustomDiscountText = (discount) => `(${discount}% OFF)`;

window.productCardAdditionalRenderer = (productCard, product) => {
  productCardImageCarouselRenderer(product, productCard);

  const productMRP = product?.metafields?.find(
    (el) => el.key === 'product_mrp'
  )?.value_str;
  if (productMRP) {
    productCard.querySelector(
      '.productCard .productMRP'
    ).innerText = `MRP: ${formatMoney(productMRP)}`;
  } else {
    productCard.querySelector('.productCard').classList.add('d-none');
  }
};

window.handleModalChanges = (product, currentSKU) => {
  const element = document.querySelector('product-variant-selection-modal');
  if (!element) return;
  const { name, image } = product;
  const { selling_price: sellingPrice, original_price: originalPrice } =
    currentSKU;

  if (product?.meta?.length > 0) {
    const foodIcon = getFoodTypeIcon(product?.meta);
    q$.select('.dkn-food-type-icon', element)
      .modifyInnerHTML(foodIcon)
      .removeClass('hidden');
  }
  const discount = getDiscountPercentValue(sellingPrice, originalPrice);
  q$.select('.dkn-product-name', element).modifyTextContent(name);
  q$.select('.dkn-product-selling-price', element).modifyTextContent(
    formatMoney(sellingPrice)
  );
  q$.select('.dkn-product-image', element).setAttribute(
    'src',
    `${getCdnUrl(
      image ||
        `${window.DukaanData.ENTERPRISE_API_ENDPOINT}/static/images/category-def.jpg`,
      100
    )}`
  );
  if (discount > 0) {
    q$.select('.dkn-product-original-price', element)
      .modifyTextContent(formatMoney(originalPrice))
      .removeClass('hidden');
    q$.select('.dkn-product-discount', element)
      .modifyTextContent(`(${discount}% OFF)`)
      .removeClass('hidden');
  } else {
    q$.select('.dkn-product-original-price', element).addClass('hidden');
    q$.select('.dkn-product-discount', element).addClass('hidden');
  }
};

window.couponPageProductCardTemplateId = 'product-card-template';

window.handleLoginSuccess = () => {
  if (localStorage.al_to) {
    handleAfterLogin();
  }

  getUserData().then((userData) => {
    const B2B_SLUG = 'b2b';
    const tier = userData?.customer_tiers?.find(
      (item) => item?.slug === B2B_SLUG
    );
    if (!tier) {
      DukaanData.ALLOW_ADD_TO_BAG = false;
      return;
    }
    window.q$.selectAll('body').removeClassAll('logged-out');
    DukaanData.ALLOW_ADD_TO_BAG = true;
  });
};

window.isEmptyObject = (obj) => Object.keys(obj).length === 0;

window.closeRequestAccessModal = () => {
  q$.selectById('request-access-modal').addClass('hidden');
  q$.select('body').elem.style.overflow = 'auto';
};

window.openRequestAccessModal = () => {
  q$.selectById('request-access-modal').removeClass('hidden');
  q$.select('body').elem.style.overflow = 'hidden';
};

window.getUserData = async () => {
  if (
    isEmptyObject(DukaanData?.DUKAAN_USER_DATA || {}) &&
    window?.isLoggedIn()
  ) {
    return fetch(
      `${window.DukaanData.CLIENT_API_ENDPOINT}/api/account/buyer/user-details/?store_id=${DukaanData.DUKAAN_STORE.id}`,
      {
        method: 'get',
        headers: {
          Authorization: `Bearer ${localStorage?.al_to}`,
          'Content-Type': 'application/json',
          'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
        },
      }
    )
      .then((res) => res.json())
      .then((res) => {
        const data = res?.data;
        DukaanData.DUKAAN_USER_DATA = data;
        return data;
      })
      .catch((e) => console.error(e));
  }

  return DukaanData?.DUKAAN_USER_DATA || {};
};
