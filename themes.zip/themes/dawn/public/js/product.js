window.SIMILAR_PRODUCT_LIMIT = 12;

window.scrollToSKUImage = (activeSKU) => {
  const primaryImage = activeSKU?.primary_image;
  const allImages = DukaanData?.DUKAAN_PRODUCT?.all_images;
  if (allImages?.length > 0) {
    const index = allImages?.indexOf(primaryImage);
    if (index >= 0) {
      if (typeof mainSplide !== 'undefined') {
        window?.mainSplide?.go(index);
        window?.thumbnailSplide?.go(index);
      }
    }
  }
};

window.appInitializer = () => {
  const { isMobile } = deviceType();
  SIMILAR_PRODUCT_LIMIT = isMobile ? 8 : 12;

  const productFromServer = DukaanData.DUKAAN_PRODUCT;
  const serializedSKUs = serializeSKUs(productFromServer.skus || []);
  const attributes = getAllProductAttributeValues(serializedSKUs);
  const product = {
    ...productFromServer,
    skus: serializedSKUs,
    attributes,
  };
  window.DukaanData.PRODUCTS_DETAILS = product;
  window.DukaanData.PRODUCTS_MAP = {
    ...(DukaanData.PRODUCTS_MAP || []),
    [product.uuid]: product,
  };

  productPageCommonFnCalls(product);

  if (
    document.querySelector('#splide-product-main') &&
    document.querySelector('#splide-product-thumbnail')
  ) {
    window.mainSplide = new Splide('#splide-product-main', {
      type: 'loop',
      delay: '5000',
      autoplay: false,
      rewind: true,
      pagination: false,
      arrows: false,
      width: 386,
      fixedWidth: 386,
      fixedHeight: 484,
      updateOnMove: true,
      breakpoints: {
        992: {
          pagination: false,
          width: '100%',
          fixedWidth: '100%',
          fixedHeight: 500,
        },
      },
    });

    window.mainSplide.on('click', (e) => {
      window.playProductVideo(e);
    });

    window.thumbnailSplide = new Splide('#splide-product-thumbnail', {
      autoplay: false,
      arrows: true,
      direction: 'ttb',
      perPage: 3,
      gap: '8px',
      fixedWidth: 140,
      fixedHeight: 175,
      height: 'calc(100% - 100px)',
      pagination: false,
      isNavigation: true,
      classes: {
        prev: 'active',
      },
      breakpoints: {
        992: {
          arrows: false,
          perPage: 5,
          fixedWidth: 48,
          fixedHeight: 66,
          direction: 'ltr',
        },
      },
    });

    window.thumbnailSplide.on('click', () => {
      window.pauseAllProductVideos();
    });

    window.mainSplide.sync(window.thumbnailSplide);
    window.mainSplide.mount();
    window.thumbnailSplide.mount();
  }
};
