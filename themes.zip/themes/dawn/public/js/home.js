window.fetchProductsFromParentId = ({ mountElem, parentIds, templateId }) => {
  const categoryIds = parentIds.map((el) => +el);

  const payload = {
    category_ids: categoryIds,
    offset: 0,
    page_size: 8,
    show_out_of_stock_products: true,
    continue_selling_when_oos: true,
  };

  fetch(
    `${window.DukaanData.DUKAAN_ADVANCED_SEARCH_API_BASE_URL}/api/advanced-search/${DukaanData.DUKAAN_STORE.id}/`,
    {
      method: 'post',
      body: JSON.stringify(payload),
      headers: {
        'Content-Type': 'application/json',
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
      },
    }
  )
    .then((res) => res.json())
    .then((res) => {
      if (res && res.data) {
        const { products } = res.data;

        const productSectionViewAllBtn = document.querySelector(
          '.home-product-section'
        );
        if (productSectionViewAllBtn.classList.contains('d-none')) {
          productSectionViewAllBtn.classList.remove('d-none');
        }

        DukaanData.PRODUCTS_MAP = {
          ...DukaanData.PRODUCTS_MAP,
          ...products.reduce((map, product) => {
            const serializedSKUs = serializeSKUs(product.skus || []);
            const attributes = getAllProductAttributeValues(serializedSKUs);
            map[product.uuid] = {
              ...product,
              skus: serializedSKUs,
              attributes,
            };
            return map;
          }, {}),
        };

        productListRenderer(mountElem, products, {
          templateId,
          additionalRenderer: window.productCardAdditionalRenderer,
        });
      } else {
        categoryProductListRenderer(null, []);
      }
    })
    .catch((err) => {
      renderCategoryProductList([]);
    });
};

window.getSerializedThemeSectionsData = (themeData) => {
  if (!themeData?.length) return {};
  const serializedThemeData = {};
  themeData?.forEach((item) => {
    serializedThemeData[item.title] = getSerializedItem(item.sections);
  });
  return serializedThemeData;
};

window.getSerializedItem = (data) => {
  if (!data?.length) return {};
  const serializedData = {};
  data?.forEach((item) => {
    serializedData[item.title] = item;
  });
  return serializedData;
};

window.appInitializer = () => {
  hashProductMap(window.DukaanData.DUKAAN_CATALOG);
  druidStorePageView();
  fetchCouponsAndOffersOnIndex();

  if (document.querySelector('#hero-splide-image'))
    new Splide('#hero-splide-image', {
      type: 'loop',
      autoplay: true,
      interval: 5000,
      pagination: DukaanData?.DUKAAN_WEB_BANNERS.length > 1 || false,
      arrows: false,
      perPage: 1,
    }).mount();

  if (document.querySelector('#hero-splide-image-mobile'))
    new Splide('#hero-splide-image-mobile', {
      type: 'loop',
      autoplay: true,
      interval: 5000,
      pagination: DukaanData?.DUKAAN_MOBILE_BANNERS.length > 1 || false,
      arrows: false,
      perPage: 1,
    }).mount();

  initiateCategorySplide(document.querySelector('#home-page-testimonials'));

  // home theme sections
  const homePageSection = window.getSerializedThemeSectionsData(
    window.DukaanData.DUKAAN_THEME_DATA.meta.config
  )?.Homepage;

  // for homepage product section
  const homeProductSection = document.querySelector('.dw-product-section');
  if (homeProductSection) {
    const categoryIds =
      homePageSection[
        'Main category product list section'
      ]?.fields?.[0]?.value?.map((el) => el.id) || [];

    window.fetchProductsFromParentId({
      mountElem: homeProductSection.querySelector('category-load-point'),
      parentIds: categoryIds,
      templateId: 'dkn-product-card-template',
    });
  }
};

window.initiateCategorySplide = (splideElm) => {
  const cardCount =
    (splideElm?.querySelectorAll('.splide__slide')?.length || 0) * 1;
  if (cardCount) {
    new Splide(splideElm, {
      type: 'slide',
      autoplay: true,
      interval: 5000,
      pauseOnHover: false,
      pagination: cardCount > 2 || false,
      arrows: false,
      perPage: 2,
      gap: 24,
      breakpoints: {
        768: {
          perPage: 1,
          grid: {
            rows: 2,
            cols: 1,
            gap: {
              row: 16,
              col: 16,
            },
          },
        },
      },
    }).mount(window.splide.Extensions);
  }
};
