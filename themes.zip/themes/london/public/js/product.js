// window.SIMILAR_PRODUCT_LIMIT = 8;
//  window.productCardTemplateId = 'ln-product-card-template-splide';

window.productCardTemplateId = 'ln-product-card-template-splide';
const isMobile = deviceType();
if (isMobile) {
  window.productCardTemplateId = 'london-product-card-template';
}

const { isDesktop } = deviceType();
if (isDesktop) {
  window.productCardTemplateId = 'ln-product-card-template-splide';
}

document.addEventListener('DOMContentLoaded', () => {
  window.mainSplide = new Splide('#splide-product-main-pdp', {
    type: 'slide',
    delay: '5000',
    autoplay: false,
    rewind: true,
    pagination: false,
    arrows: false,
    updateOnMove: true,
    breakpoints: {
      992: {
        gap: '16px',
        pagination: false,
        width: '100%',
      },
    },
  });

  window.mainSplide.on('click', (e) => {
    window.playProductVideo(e);
  });

  if (document.querySelector('#splide-product-thumbnail-pdp')) {
    window.thumbnailSplide = new Splide('#splide-product-thumbnail-pdp', {
      type: 'slide',
      autoplay: false,
      arrows: false,
      direction: 'ttb',
      perPage: 4,
      height: '100%',
      focus: 'start',
      pagination: false,
      isNavigation: true,
      breakpoints: {
        768: {
          direction: 'ltr',
          perPage: 8,
          gap: 4,
          arrows: false,
        },
      },
    });

    window.thumbnailSplide.on('click', () => {
      window.pauseAllProductVideos();
    });

    window?.mainSplide?.sync(window.thumbnailSplide);
    window?.mainSplide?.mount();
    window?.thumbnailSplide?.mount();
  } else {
    window?.mainSplide?.mount();
  }
});

window.splideCarousel = undefined;

window.scrollToSKUImage = (activeSKU) => {
  const primaryImage = activeSKU.primary_image;
  const allImages = DukaanData.DUKAAN_PRODUCT.all_images;
  const { isMobile } = deviceType();
  if (allImages.length > 0) {
    const index = allImages.indexOf(primaryImage);
    if (index >= 0) {
      if (isMobile) {
        window?.mainSplide?.go(index);
        window?.thumbnailSplide?.go(index);
      } else {
        document
          .getElementById(`pdp-image-${index + 1}`)
          ?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }
  }
};

// for similar products
window.customProductsForPdp = () => {
  const payload = {
    category_ids: [window.DukaanData.DUKAAN_CATEGORY.id || 0],
    offset: 0,
    page_size: 18,
  };

  const mountElem = document.querySelector(`similar-products-list`);

  fetch(
    `${window.DukaanData.DUKAAN_ADVANCED_SEARCH_API_BASE_URL}/api/advanced-search/${window.DukaanData.DUKAAN_STORE.id}/`,
    {
      method: 'post',
      body: JSON.stringify({ ...payload }),
      headers: {
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
      },
    }
  )
    .then((res) => res.json())
    .then((res) => {
      const rawProducts = res.data.products || [];
      const { isMobile } = deviceType();
      const defaultProductLimit = isMobile ? 6 : 12;
      let productLimit = defaultProductLimit;
      if (typeof SIMILAR_PRODUCT_LIMIT !== 'undefined') {
        productLimit = SIMILAR_PRODUCT_LIMIT;
      }

      const products = window.languageSerializer(
        rawProducts.slice(0, productLimit)
      );
      // const viewAllButtons = document.querySelectorAll(
      //   '.view-all-button-wrapper'
      // );

      // if (typeof viewAllButtons !== 'undefined') {
      //   viewAllButtons.forEach((button) => {
      //     if (products.length > productLimit) button.classList.remove('hidden');
      //   });
      //  }

      hashProductMapper(products);
      // renderSimilarProducts(products);
      productListRenderer(mountElem, products, {
        templateId: 'ln-product-card-template-splide',
      });

      if (typeof renderMinimalProductList !== 'undefined') {
        renderMinimalProductList(products.slice(0, 4));
      }

      if (typeof initProductSplide !== 'undefined') initProductSplide();
      // rendering similar products list splide if exist
      if (typeof renderProductsListSplide !== 'undefined') {
        renderProductsListSplide(products);
      }
    })
    .catch((err) => {
      console.log(err);
    });
};

window.renderProductsListSplide = (
  products,
  section = 'splide-similar-products'
) => {
  const splideObj = new Splide(`#${section}`, {
    type: 'slide',
    autoplay: false,
    arrows: true,
    pauseOnHover: false,
    perPage: 5,
    gap: 24,
    pagination: false,
    breakpoints: {
      768: {
        destroy: true,
        perPage: 2,
        //  gap: 16,
      },
    },
  });
  splideObj.mount();
};

window.appInitializer = () => {
  // const { isMobile } = deviceType();
  // SIMILAR_PRODUCT_LIMIT = isMobile ? 10 : 20;
  if (
    window.DukaanData.DUKAAN_PAGE_KEY == 'product' ||
    window.DukaanData.DUKAAN_PAGE_KEY == 'bundle'
  ) {
    document.querySelector('.ln-header-hide-plp').classList.add('d-none');
    document
      .querySelector('.ln-mobile-production-hide')
      .classList.add('d-none');
    document
      .querySelector('.ln-mobile-hide-categories')
      .classList.add('d-none');
  }
  const productFromServer = DukaanData.DUKAAN_PRODUCT;
  const serializedSKUs = serializeSKUs(productFromServer.skus || []);
  const attributes = getAllProductAttributeValues(serializedSKUs);
  const product = {
    ...productFromServer,
    skus: serializedSKUs,
    attributes,
  };
  window.DukaanData.PRODUCTS_DETAILS = product;
  window.DukaanData.PRODUCTS_MAP = {
    ...(DukaanData.PRODUCTS_MAP || []),
    [product.uuid]: product,
  };
  productPageCommonFnCalls(product);
};
