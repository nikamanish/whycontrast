document.addEventListener('DOMContentLoaded', () => {
  const testimonialSection = document.querySelector(
    '#customer-testimonials-home-page'
  );
  section = 'customer-testimonials-home-page';
  if (testimonialSection) {
    const customertestimonials = new Splide(`#${section}`, {
      type: 'slide',
      autoplay: false,
      arrows: true,
      pauseOnHover: false,
      perPage: 2,
      gap: 32,
      pagination: true,
      breakpoints: {
        768: {
          perPage: 1,
          arrows: false,
          pagination: true,
          gap: 16,
        },
      },
    });
    customertestimonials.mount();
  }
});

window.getSerializedItem = (data) => {
  if (!data?.length) return {};
  const serializedData = {};
  data?.forEach((item) => {
    serializedData[item.title] = item;
  });
  return serializedData;
};

window.getSerializedThemeSectionsData = (themeData) => {
  if (!themeData?.length) return {};
  const serializedThemeData = {};
  themeData?.forEach((item) => {
    serializedThemeData[item.title] = getSerializedItem(item.sections);
  });

  return serializedThemeData;
};

window.appInitializer = () => {
  const isMobile = deviceType();
  hashProductMap(window.DukaanData.DUKAAN_CATALOG);
  druidStorePageView();
  fetchCouponsAndOffersOnIndex();
  const categoryListElements = q$.selectAll(
    '.home-page-category-product-list'
  ).elem;
  categoryListElements.forEach((categoryElem) => {
    const categoryIds = [Number(categoryElem.dataset.categoryId)];
    const payload = {
      category_ids: categoryIds,
      page_size: isMobile.isMobile ? 6 : 5,
      offset: 0,
    };
    axios
      .post(
        `${window.DukaanData.DUKAAN_ADVANCED_SEARCH_API_BASE_URL}/api/advanced-search/${DukaanData.DUKAAN_STORE.id}/`,
        {
          ...payload,
        },
        {
          headers: {
            'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
          },
        }
      )
      .then((response) => {
        const { products } = response?.data?.data || [];
        DukaanData.PRODUCTS_MAP = {
          ...DukaanData.PRODUCTS_MAP,
          ...products?.reduce((map, product) => {
            const serializedSKUs = serializeSKUs(product.skus || []);
            const attributes = getAllProductAttributeValues(serializedSKUs);
            map[product.uuid] = {
              ...product,
              skus: serializedSKUs,
              attributes,
            };
            return map;
          }, {}),
        };
        productListRenderer(categoryElem, products, {
          getCustomDiscountText: window.getCustomDiscountText,
          templateId: 'london-product-card-template',
          additionalRenderer: productCardAdditionalRenderer,
        });
      })
      .catch(() => {});
  });

  if (document.querySelector('#hero-splide-image'))
    new Splide('#hero-splide-image', {
      type: 'loop',
      autoplay: true,
      interval: 5000,
      pagination: DukaanData?.DUKAAN_WEB_BANNERS.length > 1 || false,
      arrows: false,
      perPage: 1,
    }).mount();

  if (document.querySelector('#hero-splide-image-mobile'))
    new Splide('#hero-splide-image-mobile', {
      type: 'loop',
      autoplay: true,
      interval: 5000,
      pagination: DukaanData?.DUKAAN_MOBILE_BANNERS.length > 1 || false,
      arrows: false,
      perPage: 1,
    }).mount();

  const homePageSection = window.getSerializedThemeSectionsData(
    window.DukaanData.DUKAAN_THEME_DATA.meta.config
  )?.Homepage;

  const homeSecondCategoryProducts = document.querySelector(
    '.ln-best-seller-section'
  );

  const featuredProductSection = document.querySelector(
    '#featured-arrivals-section'
  );
  if (featuredProductSection) {
    const productId =
      homePageSection['Featured Product Section'].fields?.[2]?.value[0] || '';

    window.fetchFeaturedProductsOnIds({
      mountElem: document.querySelector('featured-product-load-point'),
      ids: productId,
    });
  }
};

window.fetchFeaturedProductsOnIds = ({ mountElem, ids }) => {
  const productIds = ids;
  const payload = {
    product_ids: [productIds],
  };
  fetch(
    `${window.DukaanData.DUKAAN_ADVANCED_SEARCH_API_BASE_URL}/api/advanced-search/${DukaanData.DUKAAN_STORE.id}/`,
    {
      method: 'post',
      body: JSON.stringify(payload),
      headers: {
        'Content-Type': 'application/json',
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
      },
    }
  )
    .then((res) => res.json())
    .then((res) => {
      if (res && res.data) {
        const { products } = res.data;

        DukaanData.PRODUCTS_MAP = {
          ...DukaanData.PRODUCTS_MAP,
          ...products.reduce((map, product) => {
            const serializedSKUs = serializeSKUs(product.skus || []);
            const attributes = getAllProductAttributeValues(serializedSKUs);
            map[product.uuid] = {
              ...product,
              skus: serializedSKUs,
              attributes,
            };
            return map;
          }, {}),
        };

        mountElem?.classList?.remove('d-none');

        productListRenderer(mountElem, products, {
          templateId: 'feature-product-card-template',
          additionalRenderer: window.featuredProductCardAdditionalRenderer,
        });
      } else {
        categoryProductListRenderer(null, []);
      }
    })
    .catch((err) => {
      renderCategoryProductList([]);
    });
};

window.renderCustomProductVariants = (productCard, product, options = {}) => {
  productCard.setAttribute('id', 'featured-product-home-page');
  const productUUID = product.uuid;
  dknAddProductsToProductsMap([DukaanData.PRODUCTS_MAP[productUUID]]);
  const activeProduct = DukaanData.PRODUCTS_MAP[productUUID];
  const activeSKU = dknGetFirstAvailableSKU(activeProduct.skus);
  const productContext = {
    key: 'variantModal',
    productUUID,
    skuUUID: activeSKU.uuid,
  };
  const variantFormElement = q$.select(
    '.variant-selection-form-wrapper',
    productCard
  ).elem;
  const actionButtonsElement = q$.select(
    '.dkn-action-button-wrapper',
    productCard
  ).elem;
  actionButtonsElement.appendChild(
    q$.selectById('dkn-action-button-wrapper-template').getTemplateContent()
      .elem
  );
  dknRenderProductVariantForm(productContext, variantFormElement);
  dknRenderActionButtons(productContext, actionButtonsElement);
};
window.featuredProductCardAdditionalRenderer = (cardWrapper, product) => {
  const productCard = cardWrapper.querySelector('.dkn-product-card');
  productCard.setAttribute(
    'data-card-reference-id',
    `${window.productCardCount}`
  );
  productCard.dataset.uuid = product.uuid;
  const newElement = document.createElement('div');
  newElement.innerHTML = product.description;
  const text = newElement.textContent || newElement.innerText || '';
  if (text) {
    productCard.querySelector('.featured-product-description').innerHTML = text;
  } else {
    productCard
      .querySelector('.featured-product-description-wrapper')
      .classList.add('hidden');
  }
  window.handleProductCardSplideInit(productCard, product);
  window.renderCustomProductVariants(productCard, product);
  renderProductCardButtons(productCard, product);
  const featureProductWrapper = document.querySelector(
    '.london-homepage-feature-product'
  );
  if (featureProductWrapper) {
    featureProductWrapper
      .querySelector('.dkn-view-all-button')
      .setAttribute(
        'href',
        `${DukaanData.DUKAAN_BASE_URL}/categories/${product?.categories[0]?.slug}`
      );
  }
  const featureProductWrappermobile = document.querySelector(
    '.london-homepage-feature-product-mobile'
  );
  if (featureProductWrappermobile) {
    featureProductWrappermobile
      .querySelector('.dkn-view-all-button-mobile')
      .setAttribute(
        'href',
        `${DukaanData.DUKAAN_BASE_URL}/categories/${product?.categories[0]?.slug}`
      );
  }
};

// feature product splide
window.handleProductCardSplideInit = (productCard, product) => {
  // const productCardId = productCard.dataset;
  const { all_images: productImagesArray } = product;
  const imageSlideTemplateId = 'product-splide-container';
  const imageSlideTemplateIdMain = 'product-splide-container_main';
  const imageListContainer = productCard.querySelector(
    '.dkn-product-card-image-carousel'
  );
  const imageListContainer_main = productCard.querySelector(
    '.dkn-product-card-image-carousel_main'
  );
  const productCardCarouselWrapper = productCard.querySelector(
    `#dkn-product-card-image-carousel-wrapper`
  );
  const productCardCarouselWrapper_main = productCard.querySelector(
    `#dkn-product-card-image-carousel-wrapper_main`
  );
  if (productImagesArray?.length > 0) {
    // render image carousel
    productImagesArray?.forEach((image) => {
      const imageSlideContainer = window.q$
        .selectById(imageSlideTemplateId)
        .getTemplateContent().elem;
      window.q$
        .select('.dkn-product-card-image-carousel-item', imageSlideContainer)
        .setAttribute('src', `${window.getCdnUrl(image, 700)}`);
      imageListContainer.appendChild(imageSlideContainer);
    });
  } else {
    const imageSlideContainer = window.q$
      .selectById(imageSlideTemplateId)
      .getTemplateContent().elem;
    window.q$
      .select('.dkn-product-card-image-carousel-item', imageSlideContainer)
      .setAttribute('src', product.image);
    imageListContainer.appendChild(imageSlideContainer);
  }

  if (productImagesArray?.length > 0) {
    // render image carousel
    productImagesArray?.forEach((image) => {
      const imageSlideContainer = window.q$
        .selectById(imageSlideTemplateIdMain)
        .getTemplateContent().elem;
      window.q$
        .select(
          '.dkn-product-card-image-carousel-item_main',
          imageSlideContainer
        )
        .setAttribute('src', `${window.getCdnUrl(image, 700)}`);
      imageListContainer_main.appendChild(imageSlideContainer);
    });
  } else {
    const imageSlideContainer = window.q$
      .selectById(imageSlideTemplateIdMain)
      .getTemplateContent().elem;
    window.q$
      .select('.dkn-product-card-image-carousel-item_main', imageSlideContainer)
      .setAttribute('src', product.image);
    imageListContainer_main.appendChild(imageSlideContainer);
  }
  // Thumbnail starts
  const productCardCarousel = new Splide(productCardCarouselWrapper, {
    autoplay: false,
    arrows: true,
    direction: 'ttb',
    perPage: 4,
    gap: 12,
    height: 'calc(100% - 100px)',
    pagination: false,
    isNavigation: true,
    breakpoints: {
      820: {
        fixedWidth: '56px',
        fixedHeight: '56px',
        direction: 'ltr',
        arrows: false,
        gap: 12,
        padding: {
          top: -100,
        },
      },
    },
  });

  const productCardCarouselmain = new Splide(productCardCarouselWrapper_main, {
    type: 'slide',
    autoplay: false,
    arrows: false,

    pagination: false,
    isNavigation: false,
    breakpoints: {
      768: {},
    },
  });

  productCardCarouselmain.sync(productCardCarousel);
  productCardCarouselmain.mount();
  productCardCarousel.mount();

  // Thumbnail ends
};

window.renderProductCardButtons = (productCard, product) => {
  const productContext = {
    key: product.skus[0]?.uuid || product.uuid,
    productUUID: product.uuid,
    skuUUID: product.skus[0]?.uuid || product.uuid,
  };

  const actionButtonsWrapperElement = q$.select(
    '.jm-product-button-wrapper',
    productCard
  ).elem;

  const externalQuantityFieldElement = q$.select(
    '.dkn-product-external-quantity-field',
    actionButtonsWrapperElement
  ).elem;

  if (externalQuantityFieldElement) {
    externalQuantityFieldElement.innerHTML = '';
    const quantityField = q$
      .selectById('dkn-product-qty-field-template')
      .getTemplateContent().elem;
    externalQuantityFieldElement.appendChild(quantityField);
    dknRenderProductQuantityInputField(
      productContext,
      externalQuantityFieldElement
    );
  }

  dknRenderActionButtons(productContext, actionButtonsWrapperElement);
};
