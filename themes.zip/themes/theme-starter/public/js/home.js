window.appInitializer = () => {
  hashProductMap(window.DukaanData.DUKAAN_CATALOG);
  druidStorePageView();
  fetchCouponsAndOffersOnIndex();

  if (document.querySelector('#hero-splide-image'))
    new Splide('#hero-splide-image', {
      type: 'loop',
      autoplay: true,
      interval: 5000,
      pagination: DukaanData?.DUKAAN_WEB_BANNERS.length > 1 || false,
      arrows: false,
      perPage: 1,
    }).mount();

  if (document.querySelector('#hero-splide-image-mobile'))
    new Splide('#hero-splide-image-mobile', {
      type: 'loop',
      autoplay: true,
      interval: 5000,
      pagination: DukaanData?.DUKAAN_MOBILE_BANNERS.length > 1 || false,
      arrows: false,
      perPage: 1,
    }).mount();
};
