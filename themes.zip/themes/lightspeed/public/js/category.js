const paramString = new URLSearchParams(window.location.search);
const sortBy = paramString.get('sort_by') || 'bestsellers';
const sortTypeElem = document.querySelector('.sort-type');
const dropdownOptionElem = document.querySelector(
  `.sort-by-dropdown-option[value="${sortBy}"]`
);
dropdownOptionElem.querySelector('input').checked = true;
sortTypeElem.textContent =
  dropdownOptionElem.querySelector('label').textContent;
dropdownOptionElem.querySelector('.sort-radio-button').classList.add('checked');

let rotation = 180;
window.toggleSortPopover = () => {
  document.body.style.overflow =
    document.body.style.overflow === 'hidden' ? 'auto' : 'hidden';
  document.querySelector('.sort-by-dropdown').classList.toggle('hidden');
  document.querySelector(
    '.sort-by-chevron'
  ).style.transform = `rotate(${rotation}deg)`;
  rotation += 180;
};

window.sortDropDownHandler = (sortByValue) => {
  const dropdownOption = document.querySelector(
    `.sort-by-dropdown-option[value="${sortByValue}"]`
  );
  sortTypeElem.textContent = dropdownOption.querySelector('label').textContent;
  document
    .querySelector('.sort-radio-button.checked')
    ?.classList.remove('checked');
  dropdownOption.querySelector('.sort-radio-button').classList.add('checked');
  toggleSortPopover();
};

window.noFilterDataHandler = () => {
  document
    .querySelector('.filters-layout-wrapper')
    .classList.add('no-filter-state');
  document.querySelector('advanced-filters').classList.add('hidden');
  document
    .querySelector('.custom-mobile-sort-button button:nth-of-type(2)')
    ?.classList.add('hidden');
  document
    .querySelector('.mobile-filter-button-divider')
    ?.classList.add('hidden');
};

const specifiedElement = document.querySelector('.sort-by-container');
document.addEventListener('click', (event) => {
  const isClickInside = specifiedElement.contains(event.target);
  if (
    !isClickInside &&
    document.body.style.overflow === 'hidden' &&
    !document.querySelector('.sort-by-dropdown.hidden')
  )
    toggleSortPopover();
});
