let scrollEnable = true;
let scrollTimer;

window.handleClickScroll = (e, uuid) => {
  e.preventDefault();
  const position = document.getElementById(uuid).offsetTop - 84;
  scrollEnable = false;
  const catListEl = document.querySelector(`[name="${uuid}"]`);
  document
    .querySelectorAll('.categories-sidebar-item')
    .forEach((el) => el.classList.remove('active'));
  catListEl?.classList.add('active');
  window.scrollTo({
    top: position,
    behavior: 'smooth',
  });
};

window.closeVariantModal = (e) => {
  e.preventDefault();
  e.stopPropagation();
  const element = document.querySelector('#pvs-modal');
  element.classList.add('hidden');
};

window.appInitializer = () => {
  hashProductMap(DukaanData.DUKAAN_CATALOG);
  fetchCouponsAndOffersOnIndex();

  const handleScroll = () => {
    const elems = document.querySelectorAll('.category-section');
    elems.forEach((elem) => {
      if (elem.getBoundingClientRect().top < 85 && scrollEnable) {
        const uuid = elem.attributes.id.value;
        const catListEl = document.querySelector(`[name="${uuid}"]`);
        document
          .querySelectorAll('.categories-sidebar-item')
          .forEach((el) => el.classList.remove('active'));
        catListEl?.classList.add('active');
      }
    });
    clearTimeout(scrollTimer);
    scrollTimer = setTimeout(() => {
      scrollEnable = true;
    }, 200);
  };

  const handleCategoryButtonScroll = (event) => {
    const elem = document.querySelector('.mobileCategoriesList');
    if (elem !== undefined && elem !== null) {
      if (
        event.target.querySelector('body') &&
        event.target.querySelector('body').getBoundingClientRect().top > -100
      ) {
        elem.querySelector('.categoriesButton').classList.add('active');
      } else {
        elem.querySelector('.categoriesButton').classList.remove('active');
      }
    }
  };

  druidStorePageView();
  document.querySelector('[data-button="home"]')?.classList.add('active');
  document.querySelector('.home-svg_filled')?.classList.remove('hidden');
  document.querySelector('.home-svg_unfilled')?.classList.add('hidden');

  let loading = false;
  const offsetCount = DukaanData.DUKAAN_CATALOG_PROPS.offset;
  let { offset } = DukaanData.DUKAAN_CATALOG_PROPS;
  const offsetHardCut = DukaanData.DUKAAN_CATALOG_PROPS.maxCount;
  let hasMore = true;
  let observerApplied = false;

  fetchProductCoupons(getProductIdsFromCategories(DukaanData.DUKAAN_CATALOG));

  const categorySideBarItemsRenderer = (mountElem, categories) => {
    const categorySidebarItemTemplate = document.getElementById(
      'categories-sidebar-item-template'
    );
    categories.forEach((category) => {
      const categorySidebarItemCard = document.importNode(
        categorySidebarItemTemplate.content,
        true
      );
      categorySidebarItemCard.querySelector(
        '[data-category-sidebar-item-name]'
      ).textContent = category.name;
      categorySidebarItemCard.querySelector(
        '[data-category-sidebar-item-count]'
      ).textContent = `(${category.product_count})`;
      categorySidebarItemCard
        .querySelector('[data-category-item-name-id]')
        .setAttribute('name', category.id);
      categorySidebarItemCard
        .querySelector('[data-category-item-scroll-click]')
        .setAttribute('onclick', `handleClickScroll(event, '${category.id}')`);
      mountElem.appendChild(categorySidebarItemCard);
    });
  };

  const renderCategorySideBarItems = (categories) => {
    customTag('category-sidebar-item-load-point', (element) => {
      categorySideBarItemsRenderer(element, categories);
    });
  };

  const endFetchCallCommon = () => {
    document
      .querySelectorAll('category-sidebar-item-load-point .shimmer')
      .forEach((el) => el.remove());
    document
      .querySelector(
        'category-sidebar-item-load-point > .categories-sidebar-item'
      )
      ?.classList.add('active');
    window.addEventListener('scroll', handleScroll, true);
    window.addEventListener('scroll', handleCategoryButtonScroll, true);
  };

  const applyObserverCall = () => {
    observerApplied = true;
    applyScroller({
      loading,
      hasMore,
      // eslint-disable-next-line no-use-before-define
      cb: fetchBestSellers,
      observeThis: 'bestseller-observer',
      loadPoint: document.querySelector('best-seller-load-point'),
    });
  };

  const fetchBestSellers = async () => {
    if (loading) return;
    loading = true;
    const response = await fetch(
      `${window.DukaanData.CLIENT_API2_ENDPOINT}/api/store/buyer/${window.DukaanData.DUKAAN_STORE.link}/bestseller/v3/?offset=${offset}`
    );
    const res = await response?.json();
    const { results: rawResults = [] } = res || {};
    const count = rawResults?.length;
    const results = rawResults?.filter((rR) => rR.products.length > 0);
    hashProductMap(results);
    hashCategory(results);
    renderBestSellers(results, 6);
    // debugger;
    renderCategorySideBarItems(
      results.filter((result) => result.products.length > 0)
    );
    // fetchProductCoupons(getProductIdsFromCategories(results));

    if (!observerApplied) {
      if (offset < offsetHardCut) {
        if (count < offsetCount) {
          endFetchCallCommon();
          hasMore = false;
          if (observerApplied)
            removeScroller({ observeThis: 'bestseller-observer' });
          return;
        }
        hasMore = true;
        offset += offsetCount;
        loading = false;
        fetchBestSellers();
      } else {
        endFetchCallCommon();
        if (count < offsetCount) {
          hasMore = false;
          if (observerApplied)
            removeScroller({ observeThis: 'bestseller-observer' });
        } else {
          applyObserverCall();
        }
      }
    } else if (count < offsetCount) {
      hasMore = false;
      if (observerApplied)
        removeScroller({ observeThis: 'bestseller-observer' });
    } else {
      hasMore = true;
      offset += offsetCount;
      loading = false;
    }
    loading = false;
  };

  renderCategorySideBarItems(
    DukaanData.DUKAAN_CATALOG.filter((category) => category.products.length > 0)
  );
  fetchBestSellers();
};
