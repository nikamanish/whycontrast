window.fetchQueryProducts = ({ ordering = '', page = 1 } = {}) => {
  renderShimmer('category-products-list', 'category-product-card-shimmer', 4);
  // eslint-disable-next-line no-restricted-globals
  const query = location.search.split('?q=')[1] || '';
  // document.querySelector(".search-query-name").textContent = query;
  fetch(
    `${window.DukaanData.CLIENT_API_ENDPOINT}/api/product/buyer/${DukaanData.DUKAAN_STORE.uuid}/product-list/v2/?search=${query}&ordering=${ordering}&page=${page}&pop_fields=category_data,store_data`,
    {
      headers: {
        'Content-Type': 'application/json',
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
      },
    }
  )
    .then((res) => res.json())
    .then((res) => {
      const products = res.results;
      document
        .querySelectorAll('.category-list-shimmer-item')
        ?.forEach((el) => el.remove());
      const countDiv = document.querySelector('.category-product-count');
      if (countDiv) {
        countDiv.textContent = `(${products?.length})`;
        countDiv.classList.remove('hidden');
      }
      DukaanData.PRODUCTS_MAP = {
        ...DukaanData.PRODUCTS_MAP,
        ...products.reduce((map, product) => {
          const serializedSKUs = serializeSKUs(product.skus || []);
          const attributes = getAllProductAttributeValues(serializedSKUs);
          // eslint-disable-next-line no-param-reassign
          map[product.uuid] = {
            ...product,
            skus: serializedSKUs,
            attributes,
          };
          return map;
        }, {}),
      };
      if (!res.results.length) {
        const productListingSection = document.querySelector(
          'category-products-list'
        );
        const noPredictionLottie = document
          .getElementById('no-search-result-found')
          .content.cloneNode(true);
        productListingSection.appendChild(noPredictionLottie);
        return;
      }
      renderCategoryProductList(res.results);
    })
    .catch(() => {
      renderCategoryProductList([]);
    });
};

window.appInitializer = () => {
  fetchQueryProducts();
};
