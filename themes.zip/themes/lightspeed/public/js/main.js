window.showMenuDropdown = (event, parentId, index) => {
  const { target } = event;
  if (index === '0') {
    q$.selectAll(`.second-menu-item-list ul.menu-items-list`).addClassAll(
      'hidden'
    );
    q$.selectAll(`.third-menu-item-list ul.menu-items-list`).addClassAll(
      'hidden'
    );
    q$.selectAll(`.first-menu-item-list ul li`).removeClassAll(
      'active-nav-item'
    );
    q$.selectAll(`.second-menu-item-list ul li`).removeClassAll(
      'active-nav-item'
    );
    q$.selectAll(`.third-menu-item-list ul li`).removeClassAll(
      'active-nav-item'
    );
  } else if (index === '1') {
    q$.selectAll(`.third-menu-item-list ul.menu-items-list`).addClassAll(
      'hidden'
    );
    q$.selectAll(`.second-menu-item-list ul li`).removeClassAll(
      'active-nav-item'
    );
    q$.selectAll(`.third-menu-item-list ul li`).removeClassAll(
      'active-nav-item'
    );
  } else if (index === '2') {
    q$.selectAll(`.third-menu-item-list ul li`).removeClassAll(
      'active-nav-item'
    );
  }
  target.classList.add('active-nav-item');
  q$.select(
    `ul.menu-items-list[data-parent-dropdown-id="${parentId}"]`
  ).removeClass('hidden');
};
window.addEventListener('DOMContentLoaded', () => {
  axios
    .get(
      `https://apps.mydukaan.io/public/v2/apps/store/${DukaanData.DUKAAN_STORE.id}/`
    )
    .then((response) => {
      const { store_apps_list: appList } = response.data;
      const availablePlugins = appList?.reduce((acc, item) => {
        if (item.isActive) {
          // eslint-disable-next-line no-underscore-dangle
          acc[item._id] = item;
        }
        return acc;
      }, {});
      const isStoreLocatorPresent = Boolean(
        !!availablePlugins && availablePlugins[APP_IDS.STORE_LOCATOR]
      );
      const storeLocatorTags = document.querySelectorAll('.store-locator-link');
      if (isStoreLocatorPresent) {
        storeLocatorTags.forEach((tag) => tag.classList.remove('hidden'));
      } else {
        storeLocatorTags.forEach((tag) => tag.remove());
      }
    })
    .finally(() => {
      const menuItems = document.querySelectorAll(
        '.menu-dropdown:not(.menu-dropdown__button)'
      );
      const mainMenu = document.querySelector('.menu-main');
      const mainMenuWidth = mainMenu.offsetWidth;
      let menuWidth = 0;
      let i = 0;
      for (i = 0; i < menuItems.length; i += 1) {
        menuWidth += menuItems[i].offsetWidth + 24;
        if (
          menuWidth >=
          mainMenuWidth -
            document.querySelector('.menu-dropdown__button').offsetWidth
        ) {
          document.fonts.ready.then(() => {
            document
              .querySelector('.menu-dropdown__button')
              .classList.remove('hidden');
          });
          break;
        }
      }
    })
    .catch(() => {});
});
window.addEventListener('DOMContentLoaded', () => {
  const menuItems = document.querySelectorAll(
    '.menu-dropdown:not(.menu-dropdown__button)'
  );

  let i = 0;
  for (i = 0; i < menuItems.length; i += 1) {
    menuItems[i].addEventListener('mouseenter', (event) => {
      document.querySelectorAll('.menu-drop-ul')?.forEach((el) => {
        el?.classList.add('hidden');
      });
      const { target: parentMenuItem } = event;
      const menuId = parentMenuItem.dataset.menuId || '';
      const menuDropDown = document.getElementById(menuId);
      if (menuDropDown) {
        menuDropDown.classList.remove('hidden');
        menuDropDown.style.position = 'absolute';
        menuDropDown.style.top = '100%';
        if (!menuDropDown.classList.contains('overflow-menu-container')) {
          menuDropDown.style.left = `${
            parentMenuItem.getBoundingClientRect().left
          }px`;
        }
      }
      document.addEventListener('mousemove', (e) => {
        const { target: hoverTarget } = e;
        const mainHeader = document.querySelector('.header-main');
        if (
          !(
            menuDropDown?.contains(hoverTarget) ||
            mainHeader?.contains(hoverTarget)
          )
        ) {
          menuDropDown?.classList?.add('hidden');
          document.removeEventListener('mousemove', () => {}, true);
        }
      });
    });
  }
});
window.getHistoryStoragekey = () =>
  `v3-${window.DukaanData.DUKAAN_STORE.link}-search-history`;
window.getDataFromLocalStorageV2 = (key) =>
  JSON.parse(localStorage.getItem(key)) || [];

window.setDataFromLocalStorage = (key, value) => {
  localStorage.setItem(getHistoryStoragekey(), JSON.stringify(value));
};

window.setHistory = (term) => {
  const prevHistory = getDataFromLocalStorageV2(getHistoryStoragekey());
  let newHistory;
  if (prevHistory.some((historyItem) => historyItem.term === term)) {
    newHistory = [
      { term },
      ...prevHistory.filter((historyItem) => historyItem.term !== term),
    ];
  } else {
    newHistory = [{ term }, ...prevHistory.slice(0, 3)];
  }
  setDataFromLocalStorage(getHistoryStoragekey(), newHistory);
  return newHistory;
};

window.handleQuerySearch = (e, query = '') => {
  e?.preventDefault();
  const formData = new FormData(e?.target);
  const queryData = formData?.get('search') || '';

  const rawQuery = (query || queryData)?.trim();
  if (Boolean(rawQuery) && rawQuery.length > 0) {
    setHistory(rawQuery);
    window.location.href = dknGetSearchUrl(rawQuery);
  }
};

window.clearInputSearch = (e) => {
  e.preventDefault();
  document.querySelector('.search-input').value = '';
  document.querySelector('.search-meta').classList.remove('hidden');
  document.querySelector('.search-predictions').classList.add('hidden');
  document.querySelector('.clear-search-input-btn').classList.add('hidden');
};

window.clearRecentSearches = () => {
  localStorage.removeItem(getHistoryStoragekey());
  renderRecentSearches();
};

window.handleOpenMenuChild = (e) => {
  e.currentTarget
    .querySelectorAll('svg')
    .forEach((elem) => elem.classList.toggle('hidden'));
  e.currentTarget
    .closest('.menu-item-wrapper')
    .querySelector('.mobile-menu-drop-down')
    .classList.toggle('hidden');
};

window.handleMobileDrawer = () => {
  handleBodyOverflow();
  const menuDrawer = document.querySelector('#mobileMenuDrawer');
  menuDrawer.classList.toggle('hidden');
};

window.fetchStoreCategoriesSearchDrawer = null;

window.openSearchDrawer = () => {
  // handleBodyOverflow();
  const modals = document.querySelectorAll('#search-drawer');
  const searchBoxWrapper = document.querySelector('.headerSearch');
  searchBoxWrapper.classList.add('zIndexSearch');
  modals.forEach((modal) => modal.classList.remove('hidden'));
  const searchContainer = document.querySelector('.search-dropdown');
  searchContainer.classList.remove('hidden');
  // const header = document.getElementsByTagName('header');
  renderRecentSearches();
  fetchStoreCategoriesSearchDrawer = fetchStoreCategories();
  fetchStoreCategoriesSearchDrawer({
    cb: renderCategoryList,
    loadPoint: '.category-list-load-point',
    firstFetch: true,
  });
};

window.debounce = (callback, timeout = 300) => {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => {
      callback.apply(this, args);
    }, timeout);
  };
};

window.onInputChange = debounce((event) => handleInputChange(event), 300);

window.handleInputChange = (event) => {
  const query = event.target.value;
  if (query.length === 0) {
    document
      .querySelectorAll('.search-meta')
      .forEach((el) => el.classList.remove('hidden'));
    document
      .querySelectorAll('.search-predictions')
      .forEach((el) => el.classList.add('hidden'));
    renderRecentSearches();
  }
  if (query.length < 2) return;
  fetch(
    `${window.DukaanData.DUKAAN_ADVANCED_SEARCH_API_BASE_URL}/api/advanced-search/${window.DukaanData.DUKAAN_STORE.id}/`,
    {
      method: 'post',
      body: JSON.stringify({ query, page_size: 15 }),
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
      },
    }
  )
    .then((res) => res.json())
    .then((res) => {
      const predictions = res?.data?.products || [];
      renderPredictions(predictions);
    })
    .catch(() => {});
};

window.closeSearchDrawer = () => {
  const modals = document.querySelectorAll('#search-drawer');
  const searchBoxWrapper = document.querySelector('.headerSearch');
  searchBoxWrapper.classList.remove('zIndexSearch');
  modals.forEach((modal) => modal.classList.add('hidden'));
  const searchContainer = document.querySelector('.search-dropdown');
  searchContainer.classList.add('hidden');
  handleBodyOverflow();
};

window.renderRecentSearches = () => {
  const recentSearchList = getDataFromLocalStorageV2(getHistoryStoragekey());
  if (recentSearchList.length > 0) {
    document
      .querySelectorAll('.recent-searches')
      .forEach((el) => el.classList.remove('hidden'));
    const recentSearchListElements = document.querySelectorAll(
      '.recent-searches-list'
    );
    recentSearchListElements.forEach((recentSearchListEl) => {
      recentSearchListEl.replaceChildren();

      const recentSearchItemTemplate = document.getElementById(
        'recent-searches-template'
      );

      recentSearchList.forEach((search) => {
        const resentSearchItemElement = document.importNode(
          recentSearchItemTemplate.content,
          true
        );
        resentSearchItemElement.querySelector(
          '.recent-search-item-text'
        ).textContent = search.term;
        resentSearchItemElement
          .querySelector('.recent-search-item')
          .setAttribute('onclick', `handleQuerySearch(null, '${search.term}')`);
        recentSearchListEl.appendChild(resentSearchItemElement);
      });
    });
  } else {
    document
      .querySelectorAll('.recent-searches')
      .forEach((el) => el.classList.add('hidden'));
  }
};

window.renderCategoryList = (categories, nextUrl, firstFetch) => {
  if (categories.length === 0 && firstFetch) {
    document
      .querySelectorAll('.category-no-result')
      ?.forEach((el) => el.classList.remove('hidden'));
    document
      .querySelectorAll('.category-no-result')
      ?.forEach((el) => el.classList.remove('hidden'));
    document
      .querySelectorAll('.search-content')
      ?.forEach((el) => el.classList.add('hidden'));
    return;
  }
  const categoryListElements = document.querySelectorAll(
    '.category-list-load-point'
  );
  categoryListElements.forEach((categoryListEl) => {
    // categoryListEl.replaceChildren();

    const categoryItemTemplate = document.getElementById('category-list-item');

    categories.forEach((category) => {
      const categoryItemElement = document.importNode(
        categoryItemTemplate.content,
        true
      );
      categoryItemElement
        .querySelector('a')
        .setAttribute('href', `${getCategoryCardLink(category)}`);
      categoryItemElement.querySelector('.category-name').textContent =
        category.name;
      categoryItemElement
        .querySelector('.category-image')
        .setAttribute('src', `${getCdnUrl(category.image, 500)}`);

      categoryListEl.appendChild(categoryItemElement);
    });

    const currentEventObserver = categoryListEl.querySelector(
      '#search-categories-list-observer'
    );

    if (nextUrl) {
      if (currentEventObserver) {
        currentEventObserver?.remove();
      }

      const newObserverElement = document.createElement('div');
      newObserverElement.setAttribute('id', 'search-categories-list-observer');
      categoryListEl.appendChild(newObserverElement);

      const observerElement = categoryListEl.querySelector(
        '#search-categories-list-observer'
      );

      const observer = new IntersectionObserver(
        (entries) => {
          if (entries[0].isIntersecting) {
            fetchStoreCategoriesSearchDrawer({
              nextUrl,
              cb: renderCategoryList,
            });
          }
        },
        {
          threshold: 1,
        }
      );
      observer.observe(observerElement);
    } else {
      currentEventObserver?.remove();
    }
  });
};

window.renderPredictions = (predictions) => {
  const searchPredictionsElements = document.querySelectorAll(
    '.search-predictions'
  );
  document.querySelector('.clear-search-input-btn').classList.remove('hidden');

  document
    .querySelectorAll('.recent-searches')
    .forEach((rS) => rS.classList.add('hidden'));

  searchPredictionsElements.forEach((searchPredictionsElement) => {
    searchPredictionsElement.replaceChildren();
    searchPredictionsElement.classList.remove('hidden');
    document
      .querySelectorAll('.search-meta')
      .forEach((el) => el.classList.add('hidden'));

    if (predictions.length > 0) {
      const searchPredictionsTemplate = document.getElementById(
        'search-prediction-item'
      );

      const isResto = DukaanData.DUKAAN_STORE.store_category === 6;

      predictions.forEach((prediction) => {
        const categoryItemElement = document.importNode(
          searchPredictionsTemplate.content,
          true
        );

        if (isResto) {
          categoryItemElement
            .querySelector('.search-prediction-item')
            .setAttribute('href', `${dknGetSearchUrl(prediction.name)}`);
        } else {
          categoryItemElement
            .querySelector('.search-prediction-item')
            .setAttribute(
              'href',
              `${DukaanData.DUKAAN_BASE_URL}/products/${prediction.slug}`
            );
        }

        categoryItemElement
          .querySelector('.fill-prediction')
          .setAttribute(
            'onclick',
            `fillPrediction(event, '${prediction.name}')`
          );
        categoryItemElement.querySelector('.prediction-label').textContent =
          prediction.name;
        searchPredictionsElement.appendChild(categoryItemElement);
      });
    } else {
      const searchPredictionsTemplate = document.getElementById(
        'search-prediction-failed'
      );
      const predectionFailedElement = document.importNode(
        searchPredictionsTemplate.content,
        true
      );
      predectionFailedElement.querySelector('.no-prediction').textContent =
        DukaanData.DUKAAN_LANGUAGE.NO_RESULTS;
      // 'No Results';
      searchPredictionsElement.appendChild(predectionFailedElement);
    }
  });
};

// window.fetchStoreCategories = () => {
//   let offset = 0;
//   const offsetCount = 10;

//   return fetchFn = ({ nextUrl = false, cb, initialized = false } = {}) => {
//     if (initialized) offset = 0;
//     // let fetchUrl = `${window.DukaanData.CLIENT_API2_ENDPOINT}/api/product/buyer/${window.DukaanData.DUKAAN_STORE.link}/product-category-list/`;
//     let fetchUrl = `${window.DukaanData.CLIENT_API2_ENDPOINT}/api/product/buyer/${window.DukaanData.DUKAAN_STORE.link}/product-category-list/?offset=${offset}`;

//     if (initialized) offset += offsetCount;

//     if (nextUrl) {
//       offset += offsetCount;
//       initialized = false;
//     }

//     fetch(fetchUrl,
//       {
//         method: 'get',
//         headers: {
//           'Content-Type': 'application/json',
//       'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
//           // 'Content-Type': 'application/x-www-form-urlencoded',
//         },
//       }
//     )
//       .then((res) => {
//         return res.json();
//       })
//       .then((res) => {
//         const categories = res?.results || [];
//         const next = !(categories.length < 10);
//         DukaanData.DUKAAN_CLIENT_CATEGORY_LIST = {
//           ...DukaanData?.DUKAAN_CLIENT_CATEGORY_LIST,
//           ...categories?.reduce((map, category) => {
//             map[category.uuid] = { ...category };
//             return map;
//           }, {}),
//         };
//         if (initialized) {
//           document.querySelectorAll(".category-list-load-point").forEach(el => el.innerHTML = "")
//         }
//         cb(categories, next);
//       })
//       .catch(() => {
//         console.log("fetchStoreCategories error : ", err);
//         cb([], null);
//       });
//   }
// };

window.handleVariantChange = (productUUID) => {
  const element = document.querySelector('product-variant-selection-modal');
  const addToBagElement = element.querySelector('add-to-bag-button');
  const buyNowElement = element.querySelector('buy-now-button-load-point');
  const formData = new FormData(
    element.querySelector('form#variant-selection')
  );
  const data = [...formData.entries()].reduce((acc, [key, value]) => {
    if (key === 'addon') {
      if (acc[key]) {
        acc[key].push(value);
      } else {
        acc[key] = [value];
      }
    } else {
      acc[key] = value;
    }

    return acc;
  }, {});

  const product = DukaanData.PRODUCTS_MAP[productUUID];
  const { skus } = product;
  const currentSKU = skus.find(
    (sku) =>
      (!data.size || sku.meta.size.value === data.size) &&
      (!data.color || sku.meta.color.value === data.color)
  );
  if (!currentSKU) return;

  if (data.color) {
    const { isLight } = colorLightOrDark(data.color);
    document.documentElement.style.setProperty(
      '--tick-color',
      isLight ? '#1a181e' : '#ffffff'
    );
  }

  const sizeItem = element.querySelector(`label[for='m-size-${data.size}']`);

  if (sizeItem) {
    sizeItem.querySelector('input').checked = true;
    sizeItem.querySelector('.size-selling-price').textContent = formatMoney(
      currentSKU.selling_price
    );
    if (currentSKU.selling_price < currentSKU.original_price) {
      sizeItem.querySelector('.size-original-price').classList.remove('hidden');
      sizeItem.querySelector('.size-original-price').textContent = formatMoney(
        currentSKU.original_price
      );
    } else {
      sizeItem.querySelector('.size-original-price').classList.add('hidden');
    }
  }

  addToBagElement.dataset.productUuid = productUUID;
  addToBagElement.dataset.skuUuid = currentSKU.uuid;
  addToBagElement.dataset.addOns = data?.addon?.join(',');
  addToBagButtonRenderer(addToBagElement);

  if (buyNowElement) {
    buyNowElement.dataset.productUuid = productUUID;
    buyNowElement.dataset.skuUuid = currentSKU.uuid;
    buyNowElement.dataset.addOns = data?.addon?.join(',');
    buyNowButtonRenderer(buyNowElement);
  }
};

window.renderCategoryButtonItems = (popoverElem) => {
  const categories = [...DukaanData.DUKAAN_CATALOG];
  const categoryTemplate = document.getElementById(
    'categories-button-item-template'
  );
  const mountElem = popoverElem.querySelector(
    'category-button-items-load-point'
  );
  mountElem.replaceChildren();
  if (!!categoryTemplate && !!mountElem)
    categories.forEach((category) => {
      const categoryCard = document.importNode(categoryTemplate.content, true);
      if (categoryCard) {
        categoryCard
          .querySelector('[data-category-item-scroll-click]')
          .setAttribute(
            'onclick',
            `closeCategoryList(event, '${category.id}')`
          );
        categoryCard
          .querySelector('[data-category-item-href-id')
          .setAttribute('href', `#${category.id}`);
        categoryCard.querySelector(
          '[data-category-button-item-name'
        ).textContent = category.name;
        categoryCard.querySelector(
          '[data-category-button-item-count'
        ).textContent = category.product_count;
      }
      mountElem.appendChild(categoryCard);
    });
};

window.openCategoryList = () => {
  const popoverElement = document.getElementById('categoryPopupWrapper');
  popoverElement.replaceChildren();
  const popup = document.getElementById('category-popup');
  const item = document.importNode(popup.content, true);
  renderCategoryButtonItems(item);
  popoverElement.appendChild(item);
  document.body.style.overflow = 'hidden';
};

window.closeCategoryList = (event, categoryId) => {
  const popoverModal = document.getElementById('popover-modal');
  popoverModal.classList.add('display-none');
  document.body.style.overflow = 'initial';
  window.handleClickScroll(event, categoryId);
};

window.discountBadgeFormatter = (discount) => `${discount}% OFF`;

window.commonInitializer = () => {
  toggleCouponFooter();
  GAPage();
  // megamenu init
  initSidebarMenuItems();
};

window.renderSubtotal = () => {
  const { totalProductCost } = totalBagCost();
  const subtotalElement = document.querySelector('.subtotal-cost');
  if (subtotalElement) {
    subtotalElement.innerHTML = `${formatMoney(totalProductCost)}`;
  }
};

window.clearBagHandler = () => {
  document.querySelectorAll('body')[0].style.overflow = 'hidden';
  document.getElementById('clearBagBackdrop').classList.remove('hidden');
  document.querySelector('#clearBagModal').classList.remove('hidden');
};

window.closeClearBagModal = () => {
  document.querySelectorAll('body')[0].style.overflow = 'auto';
  document.getElementById('clearBagBackdrop').classList.add('hidden');
  document.querySelector('#clearBagModal').classList.add('hidden');
};

window.clearBag = () => {
  setDataToLocalStorage(PRODUCTS_STORAGE_KEY(), {});
  dispatchProductUpdateEvent({});
  renderCartProductList();
  handleLightSpeedSideCart(0);
  closeClearBagModal();
};

window.APP_IDS = {
  ...(window.APP_IDS || {}),
  STORE_LOCATOR: '6286104b4f1ca25e2256f6b7',
};

window.addEventListener('load', () => {
  axios
    .get(
      `https://apps.mydukaan.io/public/v2/apps/store/${DukaanData.DUKAAN_STORE.id}/`
    )
    .then((response) => {
      const { store_apps_list: appList } = response?.data || {};
      const availablePlugins = appList?.reduce((acc, item) => {
        if (item.isActive) {
          // eslint-disable-next-line no-underscore-dangle
          acc[item._id] = item;
        }
        return acc;
      }, {});
      const isStoreLocatorPresent = Boolean(
        !!availablePlugins && availablePlugins[APP_IDS.STORE_LOCATOR]
      );
      const storeLocatorTags = document.querySelectorAll('.store-locator-link');
      if (isStoreLocatorPresent) {
        storeLocatorTags.forEach((tag) => tag.classList.remove('hidden'));
      } else {
        storeLocatorTags.forEach((tag) => tag.remove());
      }
    });
});

window.productCardAdditionalRenderer = (productCard) => {
  if (DukaanData.DUKAAN_STORE.store_category === 6) {
    window.q$
      .select('.dkn-product-card-item-unit', productCard)
      .addClass('hidden');
  } else {
    window.q$
      .select('.dkn-product-card-description', productCard)
      .addClass('hidden');
  }
};

window.getCustomDiscountText = (discount) => `${discount}% OFF`;

window.handleModalChanges = (product, currentSKU) => {
  const element = document.querySelector('product-variant-selection-modal');
  if (!element) return;
  const { name, image } = product;
  const { selling_price: sellingPrice, original_price: originalPrice } =
    currentSKU;

  if (product?.meta?.length > 0) {
    const foodIcon = getFoodTypeIcon(product?.meta);
    q$.select('.dkn-food-type-icon', element)
      .modifyInnerHTML(foodIcon)
      .removeClass('hidden');
  }
  const discount = getDiscountPercentValue(sellingPrice, originalPrice);
  q$.select('.dkn-product-name', element).modifyTextContent(name);
  q$.select('.dkn-product-selling-price', element).modifyTextContent(
    formatMoney(sellingPrice)
  );
  q$.select('.dkn-product-image', element).setAttribute(
    'src',
    `${getCdnUrl(
      image ||
        `${window.DukaanData.ENTERPRISE_API_ENDPOINT}/static/images/category-def.jpg`,
      100
    )}`
  );
  if (discount > 0) {
    q$.select('.dkn-product-original-price', element)
      .modifyTextContent(formatMoney(originalPrice))
      .removeClass('hidden');
    q$.select('.dkn-product-discount', element)
      .modifyTextContent(`(${discount}% OFF)`)
      .removeClass('hidden');
  } else {
    q$.select('.dkn-product-original-price', element).addClass('hidden');
    q$.select('.dkn-product-discount', element).addClass('hidden');
  }
};

window.couponPageProductCardTemplateId = 'category-product-card';
