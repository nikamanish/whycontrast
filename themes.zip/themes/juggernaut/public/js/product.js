// window.SIMILAR_PRODUCT_LIMIT = 8;
document.addEventListener('DOMContentLoaded', () => {
  window.mainSplide = new Splide('#splide-product-main', {
    type: 'slide',
    delay: '5000',
    autoplay: false,
    rewind: true,
    pagination: false,
    arrows: false,
    // width: 484,
    // fixedHeight: '545px',
    updateOnMove: true,
    breakpoints: {
      992: {
        gap: '16px',
        pagination: false,
        width: '100%',
        // fixedHeight: '410px',
      },
    },
  });

  window.mainSplide.on('click', (e) => {
    window.playProductVideo(e);
  });

  if (document.querySelector('#splide-product-thumbnail')) {
    window.thumbnailSplide = new Splide('#splide-product-thumbnail', {
      type: 'slide',
      autoplay: false,
      arrows: false,
      direction: 'ttb',
      perPage: 4,
      height: '100%',
      focus: 'center',
      pagination: false,
      isNavigation: true,
      breakpoints: {
        768: {
          direction: 'ltr',
          arrows: false,
          focus: 'none',
        },
      },
    });

    window.thumbnailSplide.on('click', () => {
      window.pauseAllProductVideos();
    });

    window.mainSplide.sync(window.thumbnailSplide);
    window.mainSplide.mount();
    window.thumbnailSplide.mount();
  } else {
    window.mainSplide.mount();
  }
});

window.splideCarousel = undefined;

window.scrollToSKUImage = (activeSKU) => {
  const primaryImage = activeSKU.primary_image;
  const allImages = DukaanData.DUKAAN_PRODUCT.all_images;
  if (allImages.length > 0) {
    const index = allImages.indexOf(primaryImage);
    if (index >= 0) {
      if (typeof mainSplide !== 'undefined') {
        mainSplide.go(index);
        document
          .getElementById(`pdp-image-${index + 1}`)
          ?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }
  }
};
window.appInitializer = () => {
  const { isMobile } = deviceType();
  SIMILAR_PRODUCT_LIMIT = isMobile ? 6 : 12;

  const productFromServer = DukaanData.DUKAAN_PRODUCT;
  const serializedSKUs = serializeSKUs(productFromServer.skus || []);
  const attributes = getAllProductAttributeValues(serializedSKUs);
  const product = {
    ...productFromServer,
    skus: serializedSKUs,
    attributes,
  };
  window.DukaanData.PRODUCTS_DETAILS = product;
  window.DukaanData.PRODUCTS_MAP = {
    ...(DukaanData.PRODUCTS_MAP || []),
    [product.uuid]: product,
  };
  productPageCommonFnCalls(product);
};
