window.appInitializer = () => {
  druidStorePageView();
  fetchCouponsAndOffersOnIndex();

  const dukaanThemeDataConfig = window.getSerializedThemeSectionsData(
    window.DukaanData.DUKAAN_THEME_DATA.meta.config
  );
  const homePageSection = dukaanThemeDataConfig?.Homepage;

  renderCategoryProductsSection(homePageSection);
  renderImageWithCategoryProductsSection(homePageSection);

  if (document.querySelector('#hero-splide'))
    window.mobileBannersSplide = new Splide('#hero-splide', {
      type: 'loop',
      autoplay: true,
      interval: 5000,
      pagination: false,
      arrows: DukaanData?.DUKAAN_WEB_BANNERS.length > 1 || false,
      perPage: 1,
    }).mount();

  if (document.querySelector('#hero-splide-mobile'))
    window.desktopBannersSplide = new Splide('#hero-splide-mobile', {
      type: 'loop',
      autoplay: true,
      interval: 5000,
      pagination: false,
      arrows: DukaanData?.DUKAAN_WEB_BANNERS.length > 1 || false,
      perPage: 1,
    }).mount();

  // const latestArrivalsSection = document.querySelector(
  //   '#latest-arrivals-section'
  // );

  // const featuredCollectionSection = document.querySelector(
  //   '#featured-collection-section'
  // );

  // const featuredCollectionSection2 = document.querySelector(
  //   '#featured-collection-section-2'
  // );

  // if (featuredCollectionSection) {
  //   const categoryIds =
  //     dukaanThemeDataConfig['Featured Product Section']?.fields[0]?.value[0] ||
  //     '';

  //   window.fetchProductsOnIds({
  //     mountElem: document.querySelector('featured-arrivals-load-point'),
  //     cids: categoryIds,
  //     templateId: 'jn-featured-product-card',
  //     pageSize: 0,
  //   });
  // }

  // if (featuredCollectionSection2) {
  //   const categoryIds2 =
  //     dukaanThemeDataConfig['Featured Product Section']?.fields[0]?.value[0] ||
  //     '';

  //   window.fetchProductsOnIds({
  //     mountElem: document.querySelector('featured-arrivals-load-point-2'),
  //     cids: categoryIds2,
  //     templateId: 'jn-featured-product-card',
  //     pageSize: 0,
  //   });
  // }

  // // Dynamic data mapping
  // const categoryListElements = q$.selectAll(
  //   '.home-page-category-product-list'
  // ).elem;

  // categoryListElements.forEach((categoryElem) => {
  //   const categoryIds = [Number(categoryElem.dataset.categoryId)];
  //   const payload = {
  //     category_ids: categoryIds,
  //     page_size: 4,
  //     offset: 0,
  //   };
  //   axios
  //     .post(
  //       `${window.DukaanData.DUKAAN_ADVANCED_SEARCH_API_BASE_URL}/api/advanced-search/${DukaanData.DUKAAN_STORE.id}/`,
  //       {
  //         ...payload,
  //       },
  //       {
  //         headers: {
  //           'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
  //         },
  //       }
  //     )
  //     .then((response) => {
  //       const { products } = response?.data?.data || [];
  //       DukaanData.PRODUCTS_MAP = {
  //         ...DukaanData.PRODUCTS_MAP,
  //         ...products?.reduce((map, product) => {
  //           const serializedSKUs = serializeSKUs(product.skus || []);
  //           const attributes = getAllProductAttributeValues(serializedSKUs);
  //           map[product.uuid] = {
  //             ...product,
  //             skus: serializedSKUs,
  //             attributes,
  //           };
  //           return map;
  //         }, {}),
  //       };

  //       if (products.length) {
  //         categoryListElements.forEach(() => {
  //           const homePageProductCards = window.document.querySelector(
  //             `.hw-home-product-cards-${categoryIds}`
  //           );
  //           const homePageProductCardShimmer = window.document.querySelector(
  //             `.hw-home-product-cards-shimmer-${categoryIds}`
  //           );
  //           homePageProductCardShimmer.classList.add('d-none');
  //           homePageProductCards.classList.remove('d-none');
  //         });
  //       }

  //       productListRenderer(categoryElem, products, {
  //         getCustomDiscountText: window.getCustomDiscountText,
  //         templateId: 'jn-featured-product-card-2',
  //         additionalRenderer: productCardAdditionalRenderer,
  //       });
  //     })
  //     .catch(() => {});
  // });
};

// window.testimonialsSectionSplide = null;
// window.mobileBannersSplide = null;
// window.desktopBannersSplide = null;
// window.imageWithCategoryProductsSectionProductCardsSplide = null;

document.addEventListener('DOMContentLoaded', () => {
  if (document.querySelector('#splide-testimonials-section'))
    window.testimonialsSectionSplide = new Splide(
      '#splide-testimonials-section',
      {
        type: 'loop',
        autoplay: true,
        interval: 5000,
        perPage: 3,
        pagination: false,
        arrows: false,
        perMove: 1,
        gap: '24px',
        breakpoints: {
          991: {
            destroy: true,
          },
        },
      }
    ).mount();
  dknRatingStarsRenderer();
});

window.renderCategoryProductsSection = (homePageSection) => {
  const sectionData = homePageSection?.['Main category product list section'];
  if (!sectionData) return;

  const categories = sectionData?.fields?.[0]?.value || [];
  if (!categories.length) return;

  const categoryProductsSectionElems =
    window.q$.selectAll('.category-products__section')?.elem || [];
  if (!categoryProductsSectionElems.length) return;

  categories.forEach((category) => {
    const mountElemWrapper = window.q$.selectById(
      `category-products-${category.id}`
    );
    if (!mountElemWrapper) return;

    const mountElem = window.q$.select(
      'category-products-section-product-cards',
      mountElemWrapper?.elem
    )?.elem;

    fetchProductsFromParentId({
      mountElem,
      parentIds: [category.id],
      options: {
        additionalRenderer: (mountEl, products, options) => {
          const { totalCount } = options;
          if (totalCount > 8) {
            window.q$
              .selectAll(
                '.view-all-anchor-tag',
                window.q$.selectById(`category-products-${category.id}`).elem
              )
              .removeClassAll('hidden');
          }
        },
      },
    });
  });
};

window.renderImageWithCategoryProductsSection = (homePageSection) => {
  const mountElems = window.q$.selectAll(
    'image-with-category-products-section-product-cards'
  ).elem;
  if (!mountElems.length) return;
  mountElems.forEach((mountElem) => {
    if (!mountElem) return;

    const { categoryId } = mountElem.dataset;
    if (!categoryId) return;

    fetchProductsFromParentId({
      mountElem,
      parentIds: [categoryId],
      templateId: 'image-with-category-products-section-product-card-template',
      splideId: `splide-image-with-category-products-section-product-cards-${categoryId}`,
      splideOptions: {
        type: 'loop',
        autoplay: true,
        interval: 5000,
        perPage: 3,
        perMove: 1,
        pagination: false,
        arrows: false,
        gap: '32px',
        breakpoints: {
          991: {
            perPage: 2,
            gap: '16px',
          },
        },
      },
    });
  });
};
