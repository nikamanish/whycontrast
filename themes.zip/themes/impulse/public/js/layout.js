window.getDataFromLocalStorageV2 = (key) =>
  JSON.parse(localStorage.getItem(key)) || [];
window.productCardReviewTemplateId = 'dkn-product-card-review-template';
window.getHistoryStoragekey = () =>
  `v3-${window.DukaanData.DUKAAN_STORE.link}-search-history`;

window.setDataFromLocalStorage = (key, value) => {
  localStorage.setItem(getHistoryStoragekey(), JSON.stringify(value));
};

window.setHistory = (term) => {
  const prevHistory = getDataFromLocalStorageV2(getHistoryStoragekey());
  let newHistory;
  if (prevHistory.some((historyItem) => historyItem.term === term)) {
    newHistory = [
      { term },
      ...prevHistory.filter((historyItem) => historyItem.term !== term),
    ];
  } else {
    newHistory = [{ term }, ...prevHistory.slice(0, 3)];
  }
  setDataFromLocalStorage(getHistoryStoragekey(), newHistory);
  return newHistory;
};

window.clearRecentSearches = () => {
  localStorage.removeItem(getHistoryStoragekey());
  renderRecentSearches();
};

window.clearInputSearch = () => {
  document.querySelector('.search-input').value = '';
  document.querySelector('.search-meta').classList.remove('hidden');
  document.querySelector('.search-predictions').classList.add('hidden');
  document.querySelector('.prediction-section-heading').classList.add('hidden');
  document.querySelector('.cancel-btn').classList.add('hidden');
};

// Search
window.debounce = (callback, timeout = 300) => {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => {
      callback.apply(this, args);
    }, timeout);
  };
};

window.renderPredictions = (predictions) => {
  const searchPredictionsElement = document.querySelector(
    '.search-predictions'
  );
  searchPredictionsElement.replaceChildren();
  searchPredictionsElement.classList.remove('hidden');
  document.querySelector('.search-meta').classList.add('hidden');

  // search prediction title
  const searchPredictionTitle = document.createElement('h6');
  searchPredictionTitle.setAttribute('class', 'search-predictions-title  mb-3');
  searchPredictionTitle.innerHTML = 'Products';
  searchPredictionsElement.appendChild(searchPredictionTitle);

  const searchPredictionsTemplate = document.getElementById(
    'search-prediction-item'
  );

  if (predictions.length === 0) {
    // add no prediction error text
    const noPredictionText = document.createElement('p');
    noPredictionText.innerText = 'We found no search results';
    noPredictionText.setAttribute('class', 'no-prediction-text');
    searchPredictionsElement.appendChild(noPredictionText);
    return;
  }

  predictions.forEach((prediction) => {
    const categoryItemElement = document.importNode(
      searchPredictionsTemplate.content,
      true
    );
    categoryItemElement
      .querySelector('.search-prediction-item')
      .setAttribute(
        'href',
        `${DukaanData.DUKAAN_BASE_URL}/products/${prediction.slug}`
      );
    categoryItemElement
      .querySelector('.fill-prediction')
      .setAttribute('onclick', `fillPrediction(event, '${prediction.name}')`);
    categoryItemElement
      .querySelector('.prediction-image')
      .setAttribute('src', getCdnUrl(prediction.image, 100));
    categoryItemElement.querySelector('.prediction-label').textContent =
      prediction.name;
    const categoryName = prediction?.categories?.[0]?.name;
    categoryItemElement.querySelector(
      '.prediction-subcategory'
    ).textContent = `In ${categoryName}`;
    searchPredictionsElement.appendChild(categoryItemElement);
  });
};

window.handleSearchRedirection = (event) => {
  window.location.href = dknGetSearchUrl(event.target.value);
};

window.renderCategoryList = (categories, nextUrl) => {
  const categoryListElement = document.querySelector(
    '.impulse-search-bar .category-list'
  );
  const categoryItemTemplate = document.getElementById('category-list-item');
  categories.forEach((category) => {
    const categoryItemElement = document.importNode(
      categoryItemTemplate.content,
      true
    );
    const categoryUrl = `${window.DukaanData.DUKAAN_BASE_URL}/collections/${category.slug}`;
    // if (category.subcategories_count > 0) {
    //   categoryUrl = `${categoryUrl}/subcategories`;
    // }
    categoryItemElement.querySelector('a').setAttribute('href', categoryUrl);
    categoryItemElement.querySelector('.category-name').textContent =
      category.name;
    categoryItemElement
      .querySelector('.category-image')
      .setAttribute('src', getCdnUrl(category.image, 500));
    categoryListElement.appendChild(categoryItemElement);
  });

  const currentEventObserver = document.getElementById(
    'search-categories-list-observer'
  );

  if (nextUrl) {
    if (currentEventObserver) {
      currentEventObserver?.remove();
    }

    const newObserverElement = document.createElement('div');
    newObserverElement.setAttribute('id', 'search-categories-list-observer');
    categoryListElement.appendChild(newObserverElement);

    const observerElement = document.getElementById(
      'search-categories-list-observer'
    );

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          fetchStoreCategories({ nextUrl, cb: renderCategoryList });
        }
      },
      {
        threshold: 1,
      }
    );
    observer.observe(observerElement);
  } else {
    currentEventObserver?.remove();
  }
};
window.renderRecentSearches = () => {
  const recentSearchList = getDataFromLocalStorageV2(getHistoryStoragekey());
  if (recentSearchList.length > 0) {
    document
      .querySelectorAll('.recent-searches')
      .forEach((el) => el.classList.remove('hidden'));
    const recentSearchListElements = document.querySelectorAll(
      '.recent-searches-list'
    );
    recentSearchListElements.forEach((recentSearchListEl) => {
      recentSearchListEl.replaceChildren();

      const recentSearchItemTemplate = document.getElementById(
        'recent-searches-template'
      );

      recentSearchList.forEach((search) => {
        const resentSearchItemElement = document.importNode(
          recentSearchItemTemplate.content,
          true
        );
        resentSearchItemElement.querySelector(
          '.recent-search-item-text'
        ).textContent = search.term;
        resentSearchItemElement
          .querySelector('.recent-search-item')
          .setAttribute('onclick', `handleQuerySearch(null, '${search.term}')`);
        recentSearchListEl.appendChild(resentSearchItemElement);
      });
    });
  } else {
    document
      .querySelectorAll('.recent-searches')
      .forEach((el) => el.classList.add('hidden'));
  }
};

window.initSearchBar = () => {
  const categoryListElm = document.querySelector(
    '.impulse-search-bar .category-list'
  );
  if (categoryListElm.children.length <= 0) {
    window.fetchSearchStoreCategoriesInit = window.fetchStoreCategories();
    window.fetchSearchStoreCategoriesInit({
      cb: window.renderCategoryList,
      firstFetch: true,
    });
  }
};

window.fetchStoreCategoriesSearchDrawer = null;

window.additionalCategoryProductCardChanges = (
  categoryProductCard,
  product
) => {
  const productPriceContainer =
    categoryProductCard.querySelector('.price-information');
  if (product.in_stock) {
    productPriceContainer.style.display = 'block';
  } else {
    productPriceContainer.style.display = 'none';
  }
};

window.handleInputChange = (event) => {
  const query = event.target.value;

  if (query.length === 0) {
    handleEmptySearchInput();
    return;
  }
  if (query.length < 2) {
    return;
  }
  const extraParams =
    window?.searchConfig?.extraParamsForFetchingPredictions || {};
  fetch(
    `${window.DukaanData.DUKAAN_ADVANCED_SEARCH_API_BASE_URL}/api/advanced-search/${window.DukaanData.DUKAAN_STORE.id}/`,
    {
      method: 'post',
      body: JSON.stringify({ query, page_size: 12, ...extraParams }),
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
      },
    }
  )
    .then((res) => res.json())
    .then((res) => {
      const predictions = res?.data || [];
      renderPredictions(predictions.products);
    })
    .catch((err) => {
      console.log(err);
    });
};

window.onInputChange = (event) => {
  const query = event.target.value;
  if (query.length === 0) {
    document
      .querySelectorAll('.search-meta')
      .forEach((el) => el.classList.remove('hidden'));
    document
      .querySelectorAll('.search-predictions')
      .forEach((el) => el.classList.add('hidden'));
    renderRecentSearches();
  }
  if (event.target.value.length > 0 && event.keyCode === 13) {
    // on enter key
    handleQuerySearch(event);
    return;
  }
  document
    .querySelector('.input-wrapper .clear-btn')
    .classList.remove('d-none');
  debounce(handleInputChange(event), 300);
};

window.onInputClear = () => {
  handleEmptySearchInput();
};

window.splideSlideIndex = (allImages, primaryImage) => {
  const index = allImages?.indexOf(primaryImage);
  window?.splideSlider?.go(index);
};

window.handleModalChanges = (product, currentSKU) => {
  const element = document.querySelector('.product-variant-selection-modal');
  if (!element) return;
  if (element !== null) {
    if (element.querySelector('.product-name')) {
      element.querySelector('.product-name').textContent = `${product.name}`;
    }

    if (element.querySelector('.stock-left-message')) {
      if (currentSKU.inventory <= 10 && !!currentSKU.inventory) {
        element.querySelector('.stock-left-message').classList.remove('hidden');
        element.querySelector('.stock-left-message').textContent =
          `${DukaanData.DUKAAN_LANGUAGE.ONLY__INVENTORY_LEFT_IN_STOCK_HURRY_UP}!`.injectText(
            {
              inventory: currentSKU.inventory,
            }
          );
      } else {
        element.querySelector('.stock-left-message').classList.add('hidden');
        element.querySelector('.stock-left-message').textContent = ``;
      }
    }

    const originalPrice = currentSKU?.original_price;
    const sellingPrice = currentSKU?.selling_price;

    if (element.querySelector('.product-selling-price')) {
      element.querySelector('.product-selling-price').textContent =
        formatMoney(sellingPrice);
    }

    if (
      (((originalPrice - sellingPrice) / originalPrice) * 100).toFixed(0) > 0
    ) {
      if (element.querySelector('.product-original-price')) {
        element.querySelector('.product-original-price').textContent =
          formatMoney(originalPrice);
      }

      if (element.querySelector('.product-discount-badge')) {
        element.querySelector(
          '.product-discount-badge'
        ).textContent = `(${calculateDiscount(
          originalPrice,
          sellingPrice
        )}% off)`;
      }
      element
        .querySelector('.product-original-price')
        .classList.remove('hidden');
      element
        .querySelector('.product-discount-badge')
        .classList.remove('hidden');
    } else {
      element.querySelector('.product-original-price').classList.add('hidden');
      element.querySelector('.product-discount-badge').classList.add('hidden');
    }

    // renders product modal carousel with splide if exist.
    const productSplideTemplate = document.querySelector(
      '#product-modal-splide-container,#product-modal-splide-container_thumbnail'
    );

    if (productSplideTemplate) {
      const productSplideList = element.querySelector('.splide__list');
      const productThumbnailList = element.querySelector(
        '.splide__list_thumbnail'
      );

      if (typeof splideSlider === 'undefined') {
        if (product.all_images?.length > 1) {
          // main splide
          productSplideList.replaceChildren();
          // eslint-disable-next-line no-restricted-syntax
          for (const image of product?.all_images || []) {
            const productSplide = document.importNode(
              productSplideTemplate.content,
              true
            );
            productSplide
              .querySelector('.product-modal-splide-image')
              .setAttribute(
                'src',
                `${getCdnUrl(image || currentSKU.primary_image, 700)}`
              );
            productSplideList.appendChild(productSplide);
          }

          window.splideSlider = new Splide('#splide-product-modal-images', {
            type: 'loop',
            delay: '5000',
            rewind: true,
            autoplay: false,
            arrows: false,
            pauseOnHover: false,
            pagination: false,
            updateOnMove: true,
            classes: {
              arrows: 'splide__arrows',
            },
            breakpoints: {
              768: {
                pagination: true,
              },
            },
          });

          // thumbnail splide

          productThumbnailList.replaceChildren();
          // eslint-disable-next-line no-restricted-syntax
          for (const image of product?.all_images || []) {
            const productSplide = document.importNode(
              productSplideTemplate.content,
              true
            );
            productSplide
              .querySelector('.product-modal-splide-image')
              .setAttribute(
                'src',
                `${getCdnUrl(image || currentSKU.primary_image, 700)}`
              );
            productThumbnailList.appendChild(productSplide);
          }

          window.thumbnailSplideSlider = new Splide(
            '#splide-product-thumbnail-image',
            {
              type: 'slide',
              autoplay: false,
              arrows: true,
              pauseOnHover: false,
              pagination: false,
              interval: 1000,
              isNavigation: true,
              fixedWidth: '88px',
              fixedHeight: '110px',
              focus: 3,
              height: '465px',
              classes: {
                arrows: 'splide__arrows',
              },
            }
          );

          window.splideSlider.sync(window.thumbnailSplideSlider);
          window.splideSlider.mount();
          window.thumbnailSplideSlider.mount();
        } else if (element.querySelector('.product-images')) {
          element.querySelector('.product-images').replaceChildren();
          const wrapper = element.querySelector('.product-images');

          const imageWrapper = document.createElement('div');
          imageWrapper.classList.add('image-wrapper');
          const imgElem = document.createElement('img');
          imgElem.setAttribute('class', 'product-image');
          imageWrapper.appendChild(imgElem);
          wrapper.appendChild(imageWrapper);

          element
            .querySelector('.product-image')
            .setAttribute(
              'src',
              `${getCdnUrl(product.image || currentSKU.primary_image, 700)}`
            );
        }
      }
      if (!currentSKU?.primary_image.includes('category-def.jpg')) {
        const allImages = product?.all_images || product?.image;
        if (typeof splideSlideIndex !== 'undefined')
          splideSlideIndex(allImages, currentSKU.primary_image);
      }
    }

    if (currentSKU.meta.size) {
      const sizeListHeadingLabel = element.querySelector(
        '.size-selection-heading'
      );
      if (sizeListHeadingLabel) {
        if (currentSKU.meta.size.attributeLabel) {
          sizeListHeadingLabel.innerHTML =
            DukaanData.DUKAAN_LANGUAGE.SELECT__ATTRIBUTE.injectText({
              attribute: currentSKU.meta.size.attributeLabel,
            });
        } else {
          sizeListHeadingLabel.innerHTML =
            DukaanData.DUKAAN_LANGUAGE.SELECT_SIZE;
        }
      }
    }

    if (currentSKU.meta.color) {
      const colorListHeadingLabel = element.querySelector(
        '.color-selection-heading'
      );
      if (colorListHeadingLabel) {
        if (currentSKU.meta.color.attributeLabel) {
          colorListHeadingLabel.innerHTML =
            DukaanData.DUKAAN_LANGUAGE.SELECT__ATTRIBUTE.injectText({
              attribute: currentSKU.meta.color.attributeLabel,
            });
        } else {
          colorListHeadingLabel.innerHTML =
            DukaanData.DUKAAN_LANGUAGE.SELECT_COLOR;
        }
      }
    }
  }
};
window.redirectToSearchPage = (value) => {
  value = value.trim();
  if (Boolean(value) && value.length > 0) {
    setHistory(value);
    window.location.href = dknGetSearchUrl(value);
  }
};
window.handleQuerySearch = (e, query = '') => {
  // let target = null;
  if (e !== null) {
    e.preventDefault();
    // target = e.target;
  }
  const rawQuery = query || e.target.value;
  setHistory(rawQuery);
  window.location.href = dknGetSearchUrl(rawQuery);
};

window.APP_IDS = {
  ...(window.APP_IDS || {}),
  STORE_LOCATOR: '6286104b4f1ca25e2256f6b7',
};

window.addEventListener('load', () => {
  axios
    .get(
      `https://apps.mydukaan.io/public/v2/apps/store/${DukaanData.DUKAAN_STORE.id}/`
    )
    .then((response) => {
      const { store_apps_list: appList } = response?.data || {};
      const availablePlugins = appList?.reduce((acc, item) => {
        if (item.isActive) {
          acc[item._id] = item;
        }
        return acc;
      }, {});
      const isStoreLocatorPresent = Boolean(
        !!availablePlugins && availablePlugins[APP_IDS.STORE_LOCATOR]
      );
      const storeLocatorTags = document.querySelectorAll('.store-locator-link');
      if (isStoreLocatorPresent) {
        storeLocatorTags.forEach((tag) => tag.classList.remove('hidden'));
      } else {
        storeLocatorTags.forEach((tag) => tag.remove());
      }
    });
});

window.getCustomDiscountText = (discount) => `(${discount}% OFF)`;

window.productCardAdditionalRenderer = (productCard, product) => {
  productCardImageCarouselRenderer(product, productCard);
};
window.redirectToSearchPageOnSubmit = (e) => {
  e.preventDefault();
  const formData = new FormData(document.querySelector('form#search-form'));
  const value = formData.get('search');
  redirectToSearchPage(value);
};

window.removeOverflowFromBody = () => {
  document.querySelector('body').classList.remove('overflow-hidden');
};
window.handleEmptySearchInput = () => {
  document.querySelector('.search-input').value = '';
  document.querySelector('.search-predictions').classList.add('hidden');
  document.querySelector('.search-meta').classList.remove('hidden');
  document.querySelector('.input-wrapper .clear-btn').classList.add('d-none');
};

window.fetchCustomStoreSubCategories = () => {
  // Common function
  let offset = 0;
  let initialized = true;
  const offsetCount = 10;
  return (fetchFn = ({
    nextUrl = false,
    cb,
    loadPoint = null,
    firstFetch = false,
    ...rest
  } = {}) => {
    const { categorySlug } = rest;
    if (!categorySlug) return;

    const fetchUrl = `https://api2.mydukaan.io/api/product/buyer/${window.DukaanData.DUKAAN_STORE.link}/product-category-list/?parent_slug=${categorySlug}&offset=${offset}`;

    if (nextUrl) {
      offset += offsetCount;
      initialized = false;
      firstFetch = false;
    }

    if (initialized) offset += offsetCount;

    fetch(fetchUrl, {
      method: 'get',
      headers: {
        'Content-Type': 'application/json',
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
      },
    })
      .then((res) => res.json())
      .then((res) => {
        const categories = res?.results || [];
        const next = !(categories.length < offsetCount);
        DukaanData.DUKAAN_CLIENT_SUB_CATEGORY_LIST = {
          ...DukaanData?.DUKAAN_CLIENT_SUB_CATEGORY_LIST,
          ...categories?.reduce((map, category) => {
            map[category.uuid] = { ...category };
            return map;
          }, {}),
        };
        cb(loadPoint, categories, next, firstFetch, rest);
      })
      .catch((err) => {
        console.log('fetchStoreSubCategories error : ', err);
        cb([], null);
      });
  });
};

window.subCategoriesRenderer = (
  mountElement,
  categories,
  nextUrl,
  firstFetch,
  { templateId = 'header-all-category-card-template', additionalRenderer }
) => {
  if (firstFetch) {
    mountElement.innerHTML = '';
  }
  const categoryCardTemplate = document.getElementById(templateId);

  categories?.forEach((category) => {
    const categoryCard = document.importNode(
      categoryCardTemplate.content,
      true
    );

    const categoryUrl = getCategoryCardLink(category);

    categoryCard
      .querySelectorAll('a')
      .forEach((el) => el.setAttribute('href', categoryUrl));

    categoryCard.querySelector('.header-dropdown-item').textContent =
      category.name;

    if (typeof additionalRenderer !== 'undefined') {
      additionalRenderer(categoryCard, category);
    }

    mountElement.appendChild(categoryCard);
  });
};

window.initSubcategoryHeader = (event) => {
  const { categorySlug, categoryCount } = event.dataset;

  if (categoryCount) {
    window.q$
      .select('.header-sub-category-item-dropdown')
      .elem.classList.add('hidden');
    window.fetchHeaderSubCategoriesInit =
      window.fetchCustomStoreSubCategories();

    if (categorySlug) {
      window.fetchHeaderSubCategoriesInit({
        cb: window.subCategoriesRenderer,
        categorySlug,
        firstFetch: true,
        templateId: 'header-all-category-card-template',
        loadPoint: window.q$.select('header-all-sub-category-list-load-point')
          .elem,
        additionalRenderer: () => {
          window.q$
            .select('.header-sub-category-item-dropdown')
            .removeClass('hidden');
        },
      });
    }
  }
};

window.commonInitializer = () => {
  dknInitHeader();
  GAPage();
};

window.dropDownClose = () => {
  window.q$.select('.header-sub-category-item-dropdown').addClass('hidden');
};

window.getCustomTotalWishlistCountText = (totalWishlistCount) =>
  `${
    window.DukaanData.DUKAAN_LANGUAGE.MY_WISHLIST || 'My wishlist'
  } (${totalWishlistCount})`;

window.couponPageProductCardTemplateId = 'dkn-product-splide-card-template';
window.productCardTemplateId = 'dkn-product-card-template';
window.toggleShowHideFilter = (evt, targetSelector) => {
  const upIcon = evt.currentTarget.firstElementChild;
  const downIcon = evt.currentTarget.lastElementChild;

  const targetElem =
    evt.currentTarget.parentNode.parentElement.querySelector(targetSelector);

  // open
  if (targetElem.classList.contains('d-none')) {
    targetElem.classList.remove('d-none');
    upIcon.classList.remove('d-none');
    downIcon.classList.add('d-none');
  } else {
    // close
    targetElem.classList.add('d-none');
    upIcon.classList.add('d-none');
    downIcon.classList.remove('d-none');
  }
};
window.getCustomReviewsCountText = (count) => {
  let text;
  if (count > 1) {
    text = `${count} ${DukaanData.DUKAAN_LANGUAGE.CUSTOMER_RATINGS}`;
  } else {
    text = `${count} ${DukaanData.DUKAAN_LANGUAGE.CUSTOMER_RATING}`;
  }
  return text;
};
