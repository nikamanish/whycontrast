window.fetchProductsFromParentId = ({
  mountElem,
  parentIds,
  splideId,
  templateId,
}) => {
  const categoryIds = parentIds.map((el) => +el);

  const payload = {
    category_ids: categoryIds,
    offset: 0,
    page_size: 8,
    show_out_of_stock_products: true,
    continue_selling_when_oos: true,
  };

  fetch(
    `${window.DukaanData.DUKAAN_ADVANCED_SEARCH_API_BASE_URL}/api/advanced-search/${DukaanData.DUKAAN_STORE.id}/`,
    {
      method: 'post',
      body: JSON.stringify(payload),
      headers: {
        'Content-Type': 'application/json',
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
      },
    }
  )
    .then((res) => res.json())
    .then((res) => {
      if (res && res.data) {
        const { products } = res.data;

        DukaanData.PRODUCTS_MAP = {
          ...DukaanData.PRODUCTS_MAP,
          ...products.reduce((map, product) => {
            const serializedSKUs = serializeSKUs(product.skus || []);
            const attributes = getAllProductAttributeValues(serializedSKUs);
            map[product.uuid] = {
              ...product,
              skus: serializedSKUs,
              attributes,
            };
            return map;
          }, {}),
        };

        productListRenderer(mountElem, products, {
          templateId,
          additionalRenderer: window.productCardAdditionalRenderer,
        });
        const category_id = `id${categoryIds[0]}`;
        if (document.querySelector(`#id${categoryIds[0]}`)) {
          renderHotCategorySplide(products, category_id);
        }
        if (splideId !== undefined) {
          renderProductsListSplide(products, splideId);
        }
      } else {
        categoryProductListRenderer(null, []);
      }
    })
    .catch((err) => {
      console.log(err);
      renderCategoryProductList([]);
    });
};
window.getSerializedItem = (data) => {
  if (!data?.length) return {};
  const serializedData = {};
  data?.forEach((item) => {
    serializedData[item.title] = item;
  });
  return serializedData;
};
//= ============== blog section ==================
window.fetchAllBlogs = () => {
  const blogPageNumber = 1;
  const fetchUrl = `${window.DukaanData.CLIENT_API_ENDPOINT}/api/store/buyer/${window.DukaanData.DUKAAN_STORE.link}/blogs/?page=${blogPageNumber}`;

  fetch(fetchUrl, {
    method: 'get',
    headers: {
      'Content-Type': 'application/json',
      'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
    },
  })
    .then((res) => res.json())
    .then((res) => {
      // debugger
      const blogs = res?.results || [];
      const customBlogs = blogs.filter((blog, index) => index < 3);
      localStorage.setItem('length', customBlogs.length);
      if (customBlogs.length > 0) {
        renderBlogsList(customBlogs);
      } else {
        document.getElementById('blog').style.display = 'none';
      }
    })
    .catch((e) => console.log(e));
};
window.renderBlogsList = (blogs) => {
  const blogsContainer = document.getElementById('blog');
  const blogsListWrapper = document.querySelector('.featured-blog-section');
  const blogCardTemplate = document.getElementById('blog-card');

  blogsContainer.classList.remove('hidden');

  const shimmerElems = document.querySelectorAll('.blog-card-shimmer');
  if (shimmerElems) {
    shimmerElems.forEach((elem) => elem.remove());
  }

  blogs?.forEach((blog) => {
    const blogCard = document.importNode(blogCardTemplate.content, true);
    const { title, featured_image, content, link, modified_at } = blog;
    window.formatBlogTime = (time) => {
      const months = [
        'Jan',
        'Feb',
        'Mar',
        'Apr',
        'May',
        'Jun',
        'Jul',
        'Aug',
        'Sep',
        'Oct',
        'Nov',
        'Dec',
      ];
      const date = new Date(time);
      const yyyy = date.getFullYear();
      let mm = months[date.getMonth()];
      let dd = date.getDate();

      if (dd < 10) dd = `0${dd}`;
      if (mm < 10) mm = `0${mm}`;

      return `${dd} ${mm} ${yyyy}`;
    };

    const imageSource =
      featured_image ||
      'https://api-enterprise.mydukaan.io/static/images/category-def.jpg';
    const blogUrl = `${DukaanData.DUKAAN_BASE_URL}/blog/${link}`;
    blogCard.querySelector('a').setAttribute('href', `${blogUrl}`);
    blogCard
      .querySelector('.blog-image img')
      .setAttribute('src', `${getCdnUrl(imageSource, 500)}`);
    blogCard.querySelector('.heading').textContent =
      formatBlogTime(modified_at);

    const desc = blogCard.querySelector('.description');
    desc.innerHTML = title;
    const formattedDescription = desc.innerText;
    desc.innerHTML = formattedDescription;
    blogsListWrapper.appendChild(blogCard);
  });
};
window.getSerializedThemeSectionsData = (themeData) => {
  if (!themeData?.length) return {};
  const serializedThemeData = {};
  themeData?.forEach((item) => {
    serializedThemeData[item.title] = getSerializedItem(item.sections);
  });

  return serializedThemeData;
};
window.appInitializer = () => {
  // for new arriaval section
  const homeNewArrivalSection = document.querySelector(
    '.am-new-arrival-section'
  );
  if (homeNewArrivalSection) {
    const categoryProductSection = document.querySelectorAll(
      '.new-arrival-wrapper'
    );
    categoryProductSection.forEach((el) => {
      const { parentId } = el.dataset;
      window.fetchProductsFromParentId({
        mountElem: el.querySelector('first-category-load-point'),
        parentIds: [parentId],
        splideId: undefined,
        templateId: 'dkn-product-splide-card-template',
      });
    });
  }

  hashProductMap(window.DukaanData.DUKAAN_CATALOG);
  druidStorePageView();
  fetchCouponsAndOffersOnIndex();
  if (DukaanData.DUKAAN_CATEGORY_LIST.length > 0) {
    const categorySec = document.querySelector('.categories-box-main');
    categorySec.classList.remove('d-none');
    const shimmerSec = document.querySelector('.categories-box-shimmer-hide');
    shimmerSec.classList.add('d-none');
  }
  if (document.querySelector('#hero-splide-image'))
    new Splide('#hero-splide-image', {
      type: 'loop',
      autoplay: true,
      interval: 5000,
      pagination: DukaanData?.DUKAAN_WEB_BANNERS.length > 1 || false,
      arrows: false,
      perPage: 1,
    }).mount();

  if (document.querySelector('#hero-splide-image-mobile'))
    new Splide('#hero-splide-image-mobile', {
      type: 'loop',
      autoplay: true,
      interval: 5000,
      pagination: false,
      arrows: false,
      perPage: 1,
    }).mount();

  // Shop the look cards section
  const homePageSection = window.getSerializedThemeSectionsData(
    window.DukaanData.DUKAAN_THEME_DATA.meta.config
  )?.Homepage;

  const featuredProductSection = document.querySelector(
    '#featured-arrivals-section'
  );
  if (featuredProductSection) {
    const productId =
      homePageSection['Feature product']?.fields[1]?.value?.[0]?.id || '';

    window.fetchFeaturedProductsOnIds({
      mountElem: document.querySelector('featured-product-load-point'),
      ids: productId,
    });
  }

  // blog section function call
  fetchAllBlogs();
};

window.fetchFeaturedProductsOnIds = ({ mountElem, ids }) => {
  const productIds = ids;
  const payload = {
    offset: 0,
    page_size: 1,
    product_ids: [productIds],
  };
  fetch(
    `${window.DukaanData.DUKAAN_ADVANCED_SEARCH_API_BASE_URL}/api/advanced-search/${DukaanData.DUKAAN_STORE.id}/`,
    {
      method: 'post',
      body: JSON.stringify(payload),
      headers: {
        'Content-Type': 'application/json',
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
      },
    }
  )
    .then((res) => res.json())
    .then((res) => {
      if (res && res.data) {
        const bestsell = document.querySelector('.featureshimmer');
        bestsell.classList.add('d-none');
        const { products } = res.data;
        DukaanData.PRODUCTS_MAP = {
          ...DukaanData.PRODUCTS_MAP,
          ...products.reduce((map, product) => {
            const serializedSKUs = serializeSKUs(product.skus || []);
            const attributes = getAllProductAttributeValues(serializedSKUs);
            map[product.uuid] = {
              ...product,
              skus: serializedSKUs,
              attributes,
            };
            return map;
          }, {}),
        };
        mountElem?.classList?.remove('d-none');
        productListRenderer(mountElem, products, {
          getCustomDiscountText: window.getCustomDiscountText,
          templateId: 'dkn-product-card-template',
          additionalRenderer: productCardAdditionalRenderer,
        });
      } else {
        categoryProductListRenderer(null, []);
      }
    })
    .catch((err) => {
      renderCategoryProductList([]);
    });
};

// popular pick section splide
window.renderHotCategorySplide = (products, section) => {
  const splideObj = new Splide(`#${section}`, {
    type: 'slide',
    autoplay: false,
    arrows: false,
    pauseOnHover: false,
    perPage: 4,
    perMove: 1,
    gap: 24,
    pagination: false,
    classes: {
      pagination: `splide__pagination ${section}-pagination`,
    },
    breakpoints: {
      992: {
        perPage: 2,
        gap: 16,
        padding: { right: products.length > 1 ? 30 : 0 },
      },
    },
  }).mount();

  if (document.querySelector(`.${section}-pagination`)) {
    const splideCatLi = document
      .querySelector(`.${section}-pagination`)
      .getElementsByTagName('li');
    const { perPage } = splideObj.options;
    const productsLength = products.length;
    const paginationWidth = `${100 / Math.ceil(productsLength / perPage)}%`;
    for (let i = splideCatLi.length - 1; i >= 0; i--) {
      splideCatLi[i].style.width = paginationWidth;
    }
  }
};
