const paramString = new URLSearchParams(window.location.search);
const sortBy = paramString.get('sort_by') || 'bestsellers';
const sortTypeElem = document.querySelector('.sortType');
sortTypeElem.textContent = document.querySelector(
  `.sortLabel input[value="${sortBy}"] + label`
).textContent;
document.querySelector(`.sortLabel input[value="${sortBy}"]`).checked = 'true';

window.sortDropDownHandler = (sortByCustom) => {
  sortTypeElem.textContent = document.querySelector(
    `.sortLabel input[value="${sortByCustom}"] + label`
  ).textContent;
  toggleSortPopover();
};

window.toggleSortPopover = () => {
  document.body.style.overflow =
    document.body.style.overflow === 'hidden' ? 'auto' : 'hidden';
  document
    .querySelector('.sort-popper .modal-content')
    .classList.toggle('hidden');
  document
    .querySelector('.sortContainer .downArrow')
    .classList.toggle('hidden');
  document.querySelector('.sortContainer .upArrow').classList.toggle('hidden');
};

window.noFilterDataHandler = () => {
  document
    .querySelector('.filters-layout-wrapper')
    .classList.add('no-filter-state');
  document.querySelector('advanced-filters').classList.add('hidden');
  document
    .querySelector('.custom-mobile-sort-button button:nth-of-type(2)')
    ?.classList.add('hidden');
  document
    .querySelector('.mobile-filter-button-divider')
    ?.classList.add('hidden');
};

const specifiedElement = document.querySelector('.sortContainer');
document.addEventListener('click', (event) => {
  const isClickInside = specifiedElement.contains(event.target);
  if (
    !isClickInside &&
    document.body.style.overflow === 'hidden' &&
    !document.querySelector('.sort-popper .modal-content.hidden')
  )
    toggleSortPopover();
});

window.customCounterRender = (str) => `${str} ${window.pluralize(str, 'item')}`;
