document.querySelector('[data-button="categories"]')?.classList.add('active');

window.renderCategoriesList = (categories, nextUrl, firstFetch) => {
  if (categories?.length === 0 && firstFetch) {
    document
      .querySelector('.main-categories-container')
      .classList.add('hidden');
    document
      .getElementById('no-categories-found-wrapper')
      .classList.remove('hidden');
    return;
  }
  categoriesRenderer(categories, nextUrl);
};

window.renderShimmerForCategories = (count) => {
  const categoryListElem = document.getElementById('categories-card-wrapper');
  const shimmerTemplate = document.getElementById('categories-card-shimmer');

  [...Array(count)].forEach(() => {
    const shimmerCard = document.importNode(shimmerTemplate.content, true);
    categoryListElem.appendChild(shimmerCard);
  });
};

window.categoriesRenderer = (categories, nextUrl) => {
  document
    .querySelectorAll('.category-list-shimmer-item')
    ?.forEach((el) => el.remove());

  const mountElement = document.getElementById('categories-card-wrapper');

  const categoryCardTemplate = document.getElementById(
    'categories-card-template'
  );

  categories?.forEach((category) => {
    const categoryCard = document.importNode(
      categoryCardTemplate.content,
      true
    );

    categoryCard
      .querySelectorAll('a')
      .forEach((el) =>
        el.setAttribute('href', `${getCategoryCardLink(category)}`)
      );

    categoryCard
      .querySelector('.category-image')
      .setAttribute('src', `${getCdnUrl(category.image, 500)}`);

    categoryCard.querySelector('.category-name').textContent = category.name;

    mountElement.appendChild(categoryCard);
  });

  const currentEventObserver = document.getElementById(
    'categories-list-observer'
  );

  if (nextUrl) {
    if (currentEventObserver) {
      currentEventObserver?.remove();
    }

    const newObserverElement = document.createElement('div');
    newObserverElement.setAttribute('id', 'categories-list-observer');
    mountElement.appendChild(newObserverElement);

    const observerElement = document.getElementById('categories-list-observer');

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          // renderShimmerForCategories(6);
          fetchStoreCategoriesInit({ nextUrl, cb: renderCategoriesList });
        }
      },
      {
        threshold: 1,
      }
    );
    observer.observe(observerElement);
  } else {
    currentEventObserver?.remove();
  }
};

window.fetchStoreCategoriesInit = null;

window.appInitializer = () => {
  document.querySelector('.active-home').classList.add('hidden');
  document.querySelector('.disable-home').classList.remove('hidden');
  document.querySelector('.bottom-active').style.color = '#999999';
  GAPage();
  fetchStoreCategoriesInit = fetchStoreCategories();
  fetchStoreCategoriesInit({ cb: renderCategoriesList, firstFetch: true });
};
