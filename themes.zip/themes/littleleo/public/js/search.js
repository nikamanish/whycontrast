window.fetchQueryProducts = ({ ordering = '', page = 1 } = {}) => {
  renderShimmer('category-products-list', 'category-product-card-shimmer', 4);
  const query = window.location.search.split('?q=')[1] || '';
  document.querySelector('.search-query-name').innerHTML = query.replace(
    /%20/g,
    ' '
  );
  fetch(
    `${window.DukaanData.CLIENT_API_ENDPOINT}/api/product/buyer/${DukaanData.DUKAAN_STORE.uuid}/product-list/v2/?search=${query}&ordering=${ordering}&page=${page}&pop_fields=category_data,store_data`,
    {
      headers: {
        'Content-Type': 'application/json',
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
        // 'Content-Type': 'application/x-www-form-urlencoded',
      },
    }
  )
    .then((res) => res.json())
    .then((res) => {
      const products = res.results;
      if (products.length === 0) {
        const noProducts = document.querySelector('.no-result');
        const noPredictionLottie = document
          .getElementById('no-search-result-found')
          .content.cloneNode(true);
        noProducts.appendChild(noPredictionLottie);
        noProducts.classList.remove('hidden');
        const productListingSection = document.querySelector(
          'category-products-list'
        );
        productListingSection.classList.add('hidden');
        return;
      }
      document
        .querySelectorAll('.category-list-shimmer-item')
        ?.forEach((el) => el.remove());
      const countDiv = document.querySelector('.category-product-count');
      if (countDiv) {
        countDiv.textContent = `${products?.length} ${pluralize(
          products?.length,
          'item'
        )}`;
        countDiv.classList.remove('hidden');
      }
      DukaanData.PRODUCTS_MAP = {
        ...DukaanData.PRODUCTS_MAP,
        ...products.reduce((map, product) => {
          const serializedSKUs = serializeSKUs(product.skus || []);
          const attributes = getAllProductAttributeValues(serializedSKUs);
          // eslint-disable-next-line no-param-reassign
          map[product.uuid] = {
            ...product,
            skus: serializedSKUs,
            attributes,
          };
          return map;
        }, {}),
      };
      renderCategoryProductList(res.results);
    })
    .catch(() => {
      renderCategoryProductList([]);
    });
};

window.appInitializer = () => {
  fetchQueryProducts();
};
