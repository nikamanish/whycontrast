document
  .querySelectorAll('#product-filter-open-btn, #product-filter-open-btn-mobile')
  .forEach((el) =>
    el?.addEventListener('click', (e) =>
      handleDesktopSidebarToggle(
        e,
        'product-filter-sidebar',
        'product-filter-sidebar-wrapper',
        'display-product-filter-sidebar',
        'display-sidebar-wrapper'
      )
    )
  );

document
  .querySelectorAll(
    '#product-filter-close-btn, #product-filter-close-btn-mobile, #product-filter-sidebar-backdrop'
  )
  .forEach((el) =>
    el?.addEventListener('click', (e) =>
      handleDesktopSidebarToggle(
        e,
        'product-filter-sidebar',
        'product-filter-sidebar-wrapper',
        'display-product-filter-sidebar',
        'display-sidebar-wrapper',
        true
      )
    )
  );

// product sortby sidebar
document
  .querySelectorAll('#product-sortby-open-btn, #product-sortby-open-btn-mobile')
  .forEach((el) =>
    el?.addEventListener('click', (e) =>
      handleDesktopSidebarToggle(
        e,
        'product-sortby-sidebar',
        'product-sortby-sidebar-wrapper',
        'display-product-sortby-sidebar',
        'display-sidebar-wrapper'
      )
    )
  );

document
  .querySelectorAll(
    '#product-sortby-close-btn, #product-sortby-close-btn-mobile, #product-sortby-sidebar-backdrop'
  )
  .forEach((el) =>
    el?.addEventListener('click', (e) =>
      handleDesktopSidebarToggle(
        e,
        'product-sortby-sidebar',
        'product-sortby-sidebar-wrapper',
        'display-product-sortby-sidebar',
        'display-sidebar-wrapper',
        true
      )
    )
  );

window.mapSortByKeyWithLabel = (key) => {
  switch (key) {
    case 'bestsellers':
      return 'Relevance';
    case 'better_discount':
      return 'Discount';
    case 'price_low_to_high':
      return 'Price - low to high';
    case 'price_high_to_low':
      return 'Price - high to low';
    default:
      return 'Relevance';
  }
};

window.handleSortByChange = () => {
  const el = document.querySelector('.product-sortby-item input:checked');
  sortByClickHandler(el.value, sortDropDownHandler);
  document.querySelector('#sortby-btn-label').textContent =
    mapSortByKeyWithLabel(el.value);
};

window.handleClearSortBy = () => {
  document.querySelector(
    '.product-sortby-item input[value="bestsellers"]'
  ).checked = true;
  sortByClickHandler('bestsellers', sortDropDownHandler);
  document.querySelector('#sortby-btn-label').textContent =
    mapSortByKeyWithLabel('bestsellers');
};

window.sortDropDownHandler = () => {
  handleDesktopSidebarToggle(
    '',
    'product-sortby-sidebar',
    'product-sortby-sidebar-wrapper',
    'display-product-sortby-sidebar',
    'display-sidebar-wrapper',
    true
  );
};

const selectedSortByValue = new URL(window.location).searchParams.get(
  'sort_by'
);

if (selectedSortByValue) {
  document.querySelector('#sortby-btn-label').textContent =
    mapSortByKeyWithLabel(selectedSortByValue);
  document.querySelector(
    `.product-sortby-item input[value="${selectedSortByValue}"]`
  ).checked = true;
}

window.noFilterDataHandler = () => {
  document
    .querySelector('.main-container')
    .classList.add('main-container__no-filter');
  document.querySelector('.shop-filter-divider').classList.add('hidden');
  document.querySelector('.filter-btn').classList.add('hidden');
};

const tagsEl = document.querySelector('filter-tags');
const config = { attributes: false, childList: true, subtree: false };

const callback = () => {
  tagsEl.style.marginBottom = tagsEl.children.length ? '24px' : 0;
};

const observer = new MutationObserver(callback);

const { isDesktop } = deviceType();
if (isDesktop) {
  observer.observe(tagsEl, config);
}

window.getProductCardsAdditionalRenderer = (products) => {
  if (!products) return;
  const productsLength = products?.length;
  const sortContainer = document.querySelector('.sort-wrapper');

  if (!productsLength && !sortContainer.classList.contains('hidden')) {
    sortContainer.classList.add('hidden');
  } else {
    sortContainer.classList.remove('hidden');
  }
};

