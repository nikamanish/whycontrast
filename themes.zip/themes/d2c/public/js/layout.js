window.toggleScroll = () =>
  document.querySelector('body').classList.toggle('no-scroll');
window.addScroll = () =>
  document.querySelector('body').classList.remove('no-scroll');
window.removeScroll = () =>
  document.querySelector('body').classList.add('no-scroll');

window.handleMobileSidebarToggle = (e, sidebarId, sidebarDisplayClass) => {
  toggleScroll();
  const sidebar = document.getElementById(sidebarId);
  sidebar.classList.toggle(sidebarDisplayClass);
};

window.handleDesktopSidebarToggle = (
  e,
  sidebarId,
  sidebarWrapperId,
  sidebarDisplayClass,
  sidebarWrapperDisplayClass,
  close = false
) => {
  console.log('hit');
  const sidebar = document.getElementById(sidebarId);
  const sidebarWrapper = document.getElementById(sidebarWrapperId);
  sidebar?.classList.toggle(sidebarDisplayClass);
  if (close) {
    addScroll();
    setTimeout(() => {
      sidebarWrapper?.classList.toggle(sidebarWrapperDisplayClass);
    }, 300);
  } else {
    removeScroll();
    sidebarWrapper?.classList.toggle(sidebarWrapperDisplayClass);
  }
  // initSidebarMenuItemsD2c();
};

// mobile side navbar
// document
//   .querySelectorAll("#mobile-sidebar-open-btn, #mobile-sidebar-close-btn").forEach(el =>
//     el.addEventListener("click", (e) =>
//       handleMobileSidebarToggle(e, "mobile-side-bar", "display-mobile-side-bar")
//     ));

document
  .querySelectorAll(
    '#mobile-sidebar-shop-open-btn, #mobile-sidebar-shop-close-btn'
  )
  .forEach((el) =>
    el.addEventListener('click', (e) =>
      handleMobileSidebarToggle(
        e,
        'mobile-side-bar-shop',
        'display-mobile-side-bar-shop'
      )
    )
  );

// menu bar sidebar
document
  .querySelectorAll('.header-menu-sidebar-open-btn')
  .forEach((el) =>
    el.addEventListener('click', () =>
      handleDesktopSidebarToggle(
        '',
        'header-menu-sidebar',
        'header-menu-sidebar-wrapper',
        'display-header-menu-sidebar',
        'display-sidebar-wrapper'
      )
    )
  );

document
  .querySelectorAll(
    '#header-menu-sidebar-close-btn, #header-menu-sidebar-backdrop'
  )
  .forEach((el) =>
    el?.addEventListener('click', () =>
      handleDesktopSidebarToggle(
        '',
        'header-menu-sidebar',
        'header-menu-sidebar-wrapper',
        'display-header-menu-sidebar',
        'display-sidebar-wrapper',
        true
      )
    )
  );

// sub menu sidebar
document.querySelectorAll('.header-sub-menu-sidebar-open-btn').forEach((el) =>
  el.addEventListener('click', (e) => {
    handleDesktopSidebarToggle(
      '',
      'header-sub-menu-sidebar',
      'header-sub-menu-sidebar-wrapper',
      'display-header-menu-sidebar',
      'display-sidebar-wrapper'
    );
    renderSubMenuSidebarContent(e);
  })
);

document.querySelectorAll('.header-sub-menu-sidebar-close-btn').forEach((el) =>
  el.addEventListener('click', () => {
    handleDesktopSidebarToggle(
      '',
      'header-sub-menu-sidebar',
      'header-sub-menu-sidebar-wrapper',
      'display-header-menu-sidebar',
      'display-sidebar-wrapper'
    );
  })
);

document
  .querySelectorAll(
    '.header-sub-menu-sidebar-close-all-btn,#header-menu-sidebar-backdrop'
  )
  .forEach((el) =>
    el?.addEventListener('click', () => handleCloseAllHeaderSidebars())
  );

window.handleCloseAllMobileSidebars = () => {
  document
    .getElementById('mobile-side-bar')
    ?.classList.remove('display-mobile-side-bar');
  document
    .getElementById('mobile-side-bar-shop')
    ?.classList.remove('display-mobile-side-bar-shop');
};

window.handleCloseAllHeaderSidebars = () => {
  document
    .getElementById('header-sub-menu-sidebar')
    ?.classList.remove('display-header-menu-sidebar');
  document
    .getElementById('header-menu-sidebar')
    ?.classList.remove('display-header-menu-sidebar');
  addScroll();
  setTimeout(() => {
    document
      .getElementById('header-menu-sidebar-wrapper')
      ?.classList.remove('display-sidebar-wrapper');
    document
      .getElementById('header-sub-menu-sidebar-wrapper')
      ?.classList.remove('display-sidebar-wrapper');
  }, 300);
};

window.fetchStoreCategoriesSearchDrawer = null;

// search sidebar
window.openSearchDrawer = () => {
  removeScroll();
  const modalWrapper = document.getElementById('search-drawer');
  const modal = document.getElementById('search-drawer-content');
  modalWrapper.classList.add('display-sidebar-wrapper');
  modal.classList.add('display-search-modal-content');
  renderRecentSearches();
  fetchStoreCategoriesSearchDrawer = fetchStoreCategories();
  fetchStoreCategoriesSearchDrawer({
    cb: renderCategoryList,
    loadPoint: '.category-list',
    firstFetch: true,
  });
};

window.closeSearchDrawer = () => {
  addScroll();
  const modalWrapper = document.getElementById('search-drawer');
  const modal = document.getElementById('search-drawer-content');
  modal.classList.remove('display-search-modal-content');
  setTimeout(() => {
    modalWrapper.classList.remove('display-sidebar-wrapper');
  }, 300);
};

// Search predictions
window.fillPrediction = () => {};

window.renderPredictions = (predictions) => {
  const searchPredictionsElement = document.querySelector(
    '.search-predictions'
  );
  searchPredictionsElement.replaceChildren();
  searchPredictionsElement.classList.remove('hidden');
  document.querySelector('.search-meta').classList.add('hidden');

  // search prediction title
  const searchPredictionTitle = document.createElement('h6');
  searchPredictionTitle.setAttribute(
    'class',
    'search-predictions-title  mb-16'
  );
  searchPredictionTitle.innerHTML = 'Products';
  searchPredictionsElement.appendChild(searchPredictionTitle);

  const searchPredictionsTemplate = document.getElementById(
    'search-prediction-item'
  );

  if (predictions.length === 0) {
    // add no prediction error text
    const noPredictionText = document.createElement('p');
    noPredictionText.innerText = 'We found no search results';
    noPredictionText.setAttribute('class', 'no-prediction-text');
    searchPredictionsElement.appendChild(noPredictionText);
    return;
  }

  predictions.forEach((prediction) => {
    const categoryItemElement = document.importNode(
      searchPredictionsTemplate.content,
      true
    );
    categoryItemElement
      .querySelector('.search-prediction-item')
      .setAttribute(
        'href',
        `${DukaanData.DUKAAN_BASE_URL}/products/${prediction.slug}`
      );
    categoryItemElement
      .querySelector('.search-prediction-item-image')
      .setAttribute('src', `${getCdnUrl(prediction.image, 500)}`);
    categoryItemElement
      .querySelector('.fill-prediction')
      .setAttribute('onclick', `fillPrediction(event, '${prediction.name}')`);
    categoryItemElement.querySelector(
      '.prediction-label-product-name'
    ).textContent = prediction.name;
    const categoryName = prediction?.categories?.[0]?.name;
    if (categoryName) {
      categoryItemElement.querySelector(
        '.prediction-label-category-name'
      ).textContent = `In ${categoryName}`;
    }

    searchPredictionsElement.appendChild(categoryItemElement);
  });
};

// search input
window.debounce = (callback, timeout = 300) => {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => {
      callback.apply(this, args);
    }, timeout);
  };
};

window.handleEmptySearchInput = () => {
  document.querySelector('.search-input').value = '';
  document.querySelector('.search-predictions').classList.add('hidden');
  document.querySelector('.search-meta').classList.remove('hidden');
  document.querySelector('.input-wrapper svg').classList.add('hidden');
};

window.handleInputChange = (event) => {
  const query = event.target.value;
  if (query.length === 0) {
    handleEmptySearchInput();
    return;
  }
  if (query.length < 2) return;

  const searchLoader = document.querySelector(
    '.search-modal .search-input-loader'
  );
  searchLoader.classList.remove('hidden');

  fetch(
    `${window.DukaanData.DUKAAN_ADVANCED_SEARCH_API_BASE_URL}/api/advanced-search/${window.DukaanData.DUKAAN_STORE.id}/`,
    {
      method: 'post',
      body: JSON.stringify({ query, page_size: 15 }),
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
      },
    }
  )
    .then((res) => res.json())
    .then((res) => {
      const predictions = res?.data?.products || [];
      renderPredictions(predictions);
      searchLoader.classList.add('hidden');
    })
    .catch(() => {
      searchLoader.classList.add('hidden');
    });
};

window.onInputChange = (event) => {
  const query = event.target.value;
  if (query.length === 0) {
    document
      .querySelectorAll('.search-meta')
      .forEach((el) => el.classList.remove('hidden'));
    document
      .querySelectorAll('.search-predictions')
      .forEach((el) => el.classList.add('hidden'));
    renderRecentSearches();
  }
  if (event.target.value.length > 0 && event.keyCode === 13) {
    // on enter key
    handleQuerySearch(event);
    return;
  }
  document.querySelector('.input-wrapper svg').classList.remove('hidden');
  debounce(handleInputChange(event), 300);
};

window.onInputClear = () => {
  handleEmptySearchInput();
};

// search categories
window.renderCategoryList = (categories, nextUrl, firstFetch) => {
  if (categories.length === 0 && firstFetch) {
    document
      .querySelectorAll('.category-no-result')
      ?.forEach((el) => el.classList.remove('hidden'));
    return;
  }
  const categoryListElement = document.querySelector('.category-list');
  const categoryItemTemplate = document.getElementById('category-list-item');

  categories.forEach((category) => {
    const categoryItemElement = document.importNode(
      categoryItemTemplate.content,
      true
    );
    const categoryUrl = getCategoryCardLink(category);

    categoryItemElement.querySelector('a').setAttribute('href', categoryUrl);
    categoryItemElement.querySelector('.category-name').textContent =
      category.name;
    categoryItemElement
      .querySelector('.category-image')
      .setAttribute('src', `${getCdnUrl(category.image, 500)}`);
    categoryListElement.appendChild(categoryItemElement);
  });

  const currentEventObserver = document.getElementById(
    'search-categories-list-observer'
  );

  if (nextUrl) {
    if (currentEventObserver) {
      currentEventObserver?.remove();
    }

    const newObserverElement = document.createElement('div');
    newObserverElement.setAttribute('id', 'search-categories-list-observer');
    categoryListElement.appendChild(newObserverElement);

    const observerElement = document.getElementById(
      'search-categories-list-observer'
    );

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          fetchStoreCategoriesSearchDrawer({ nextUrl, cb: renderCategoryList });
        }
      },
      {
        threshold: 1,
      }
    );
    observer.observe(observerElement);
  } else {
    currentEventObserver?.remove();
  }
};

// window.fetchStoreCategories = ({ nextUrl = null, cb } = {}) => {
//   let fetchUrl = `${window.DukaanData.CLIENT_API2_ENDPOINT}/api/product/buyer/${window.DukaanData.DUKAAN_STORE.link}/product-category-list/`;
//   let isFirstFetch = true;
//   console.log('nextUrl', nextUrl);

//   if (nextUrl) {
//     fetchUrl = nextUrl;
//     isFirstFetch = false;
//   }

//   if (isFirstFetch) {
//     document.querySelector(".category-list").innerHTML = '';
//   }

//   fetch(fetchUrl, {
//     method: "GET",
//     headers: {
//       "Content-Type": "application/json",
//       // 'Content-Type': 'application/x-www-form-urlencoded',
//     },
//   })
//     .then((res) => {
//       return res.json();
//     })
//     .then((res) => {
//       let categories = res.results || [];
//       let next = res.next;
//       // categories = categories?.filter((category) => isParentCategory(category));

//       // console.log(next);
//       // if (res && !!res.results && !!res.results.length) {
//       DukaanData.DUKAAN_CLIENT_CATEGORY_LIST = {
//         ...DukaanData.DUKAAN_CLIENT_CATEGORY_LIST,
//         ...categories.reduce((map, category) => {
//           map[category.uuid] = { ...category };
//           return map;
//         }, {}),
//       };
//       cb(categories, next);
//       // }
//     })
//     .catch((err) => {
//       console.log("fetchStoreCategories error : ", err);
//       cb([], null);
//     });
// };

window.renderRecentSearches = () => {
  const recentSearchList = getDataFromLocalStorageV2(getHistoryStoragekey());
  if (recentSearchList.length > 0) {
    document
      .querySelectorAll('.recent-searches')
      .forEach((el) => el.classList.remove('hidden'));
    const recentSearchListElements = document.querySelectorAll(
      '.recent-searches-list'
    );
    recentSearchListElements.forEach((recentSearchListEl) => {
      recentSearchListEl.replaceChildren();

      const recentSearchItemTemplate = document.getElementById(
        'recent-searches-template'
      );

      recentSearchList.forEach((search) => {
        const resentSearchItemElement = document.importNode(
          recentSearchItemTemplate.content,
          true
        );
        resentSearchItemElement.querySelector(
          '.recent-search-item-text'
        ).textContent = search.term;
        resentSearchItemElement
          .querySelector('.recent-search-item')
          .setAttribute('onclick', `handleQuerySearch(null, '${search.term}')`);
        recentSearchListEl.appendChild(resentSearchItemElement);
      });
    });
  } else {
    document
      .querySelectorAll('.recent-searches')
      .forEach((el) => el.classList.add('hidden'));
  }
};

window.getDataFromLocalStorageV2 = (key) =>
  JSON.parse(localStorage.getItem(key)) || [];

window.getHistoryStoragekey = () =>
  `v3-${window.DukaanData.DUKAAN_STORE.link}-search-history`;

window.setDataFromLocalStorage = (key, value) => {
  localStorage.setItem(getHistoryStoragekey(), JSON.stringify(value));
};

window.setHistory = (term) => {
  const prevHistory = getDataFromLocalStorageV2(getHistoryStoragekey());
  let newHistory;
  if (prevHistory.some((historyItem) => historyItem.term === term)) {
    newHistory = [
      { term },
      ...prevHistory.filter((historyItem) => historyItem.term !== term),
    ];
  } else {
    newHistory = [{ term }, ...prevHistory.slice(0, 3)];
  }
  setDataFromLocalStorage(getHistoryStoragekey(), newHistory);
  return newHistory;
};

window.handleQuerySearch = (e, query = '') => {
  let target = null;
  if (e !== null) {
    e.preventDefault();
    target = e.target;
  }
  const rawQuery = (query || target?.value)?.trim();
  if (Boolean(rawQuery) && rawQuery.length > 0) {
    setHistory(rawQuery);
    window.location.href = dknGetSearchUrl(rawQuery);
  }
};

window.clearRecentSearches = () => {
  localStorage.removeItem(getHistoryStoragekey());
  renderRecentSearches();
};

// render product badges dynamically
window.hideAllBadge = (similarProductCard) => {
  const badges = similarProductCard.querySelectorAll('.bxgy-badge');
  badges.forEach((badge) => {
    badge.classList.add('hidden');
  });
};

window.handleProductCardChange = (productCard, product) => {
  const couponBadge = productCard.querySelector('.bxgy-badge-nirvana');
  const onSaleBadge = productCard.querySelector('.badge-info');
  const outOfStockBadge = productCard.querySelector('.badge-white');

  hideAllBadge(productCard);
  if (product.in_stock) {
    if (product.coupon_data?.length > 0) {
      couponBadge.classList.remove('hidden');
      couponBadge.textContent = getBXGYText(product.coupon_data);
      return;
    }
    if (product.original_price > product.selling_price) {
      onSaleBadge.classList.remove('hidden');
    }
  } else {
    outOfStockBadge.classList.remove('hidden');
  }
};

window.splideSlideIndex = (allImages, primaryImage) => {
  const index = allImages?.indexOf(primaryImage);
  window?.splideSlider?.go(index);
};

// variant modal functions
window.handleModalChanges = (product, currentSKU) => {
  const element = document.querySelector('.product-variant-selection-modal');

  if (!element) return;

  if (element.querySelector('.product-modal-badge .bxgy-badge')) {
    handleProductCardChange(element, product);
  }

  if (element.querySelector('.product-name')) {
    element.querySelector('.product-name').textContent = `${product.name}`;
  }

  if (element.querySelector('.stock-left-message')) {
    if (currentSKU.inventory <= 10 && !!currentSKU.inventory) {
      element.querySelector('.stock-left-message').classList.remove('hidden');
      element.querySelector(
        '.stock-left-message'
      ).textContent = `Only ${currentSKU.inventory} left in stock. Hurry up!`;
    } else {
      element.querySelector('.stock-left-message').classList.add('hidden');
      element.querySelector('.stock-left-message').textContent = ``;
    }
  }

  // renders product modal carousel with splide if exist.
  const productSplideTemplate = document.querySelector(
    '#product-modal-splide-container'
  );

  if (productSplideTemplate) {
    const productSplideList = element.querySelector('.splide__list');

    if (typeof splideSlider === 'undefined') {
      if (product.all_images?.length > 1) {
        product?.all_images.forEach((image) => {
          const productSplide = document.importNode(
            productSplideTemplate.content,
            true
          );
          productSplide
            .querySelector('.product-modal-splide-image')
            .setAttribute(
              'src',
              `${getCdnUrl(image || currentSKU.primary_image, 700)}`
            );
          productSplideList.appendChild(productSplide);
        });

        window.splideSlider = new Splide('#splide-product-modal-images', {
          type: 'loop',
          autoplay: false,
          arrows: true,
          pauseOnHover: false,
          pagination: false,
          interval: 1000,
          classes: {
            arrows: 'splide__arrows',
          },
        }).mount();
      } else if (element.querySelector('.product-images')) {
        element.querySelector('.product-images').replaceChildren();
        const wrapper = element.querySelector('.product-images');
        wrapper.classList.add('fB', 'a-c', 'j-c');
        const imgElem = document.createElement('img');
        imgElem.setAttribute('class', 'product-image');
        element.querySelector('.product-images').appendChild(imgElem);
        element
          .querySelector('.product-image')
          .setAttribute(
            'src',
            `${getCdnUrl(product.image || currentSKU.primary_image, 700)}`
          );
      }
    }
    if (!currentSKU?.primary_image.includes('category-def.jpg')) {
      const allImages = product?.all_images || product?.image;
      if (typeof splideSlideIndex !== 'undefined')
        splideSlideIndex(allImages, currentSKU.primary_image);
    }
  }

  if (element.querySelector('.product-selling-price')) {
    element.querySelector('.product-selling-price').textContent = formatMoney(
      currentSKU.selling_price
    );
  }

  if (element.querySelector('.product-original-price')) {
    if (currentSKU.original_price === currentSKU.selling_price) {
      element.querySelector('.product-original-price').classList.add('hidden');
    } else {
      element
        .querySelector('.product-original-price')
        .classList.remove('hidden');
      element.querySelector('.product-original-price').textContent =
        formatMoney(currentSKU.original_price);
    }
  }

  if (element.querySelector('.product-discount-badge')) {
    if (
      currentSKU.original_price === currentSKU.selling_price ||
      (
        ((currentSKU.original_price - currentSKU.selling_price) /
          currentSKU.original_price) *
        100
      ).toFixed(0) <= 0
    ) {
      element.querySelector('.product-discount-badge').classList.add('hidden');
    } else {
      element
        .querySelector('.product-discount-badge')
        .classList.remove('hidden');
      element.querySelector(
        '.product-discount-badge'
      ).textContent = `(${calculateDiscount(
        currentSKU.original_price,
        currentSKU.selling_price
      )}% OFF)`;
    }
  }

  if (currentSKU.meta.size) {
    const sizeListHeadingLabel = element.querySelector('.size-selection-label');
    if (sizeListHeadingLabel) {
      if (currentSKU.meta.size.attributeLabel) {
        sizeListHeadingLabel.innerHTML =
          DukaanData.DUKAAN_LANGUAGE.SELECT__ATTRIBUTE.injectText({
            attribute: currentSKU.meta.size.attributeLabel,
          });
        // `Select ${currentSKU.meta.size.attributeLabel}`;
      } else {
        sizeListHeadingLabel.innerHTML = DukaanData.DUKAAN_LANGUAGE.SELECT_SIZE;
      }
    }
  }

  if (currentSKU.meta.color) {
    const colorListHeadingLabel = element.querySelector(
      '.color-selection-label'
    );
    if (colorListHeadingLabel) {
      if (currentSKU.meta.color.attributeLabel) {
        colorListHeadingLabel.innerHTML =
          DukaanData.DUKAAN_LANGUAGE.SELECT__ATTRIBUTE.injectText({
            attribute: currentSKU.meta.color.attributeLabel,
          });
        // `Select ${currentSKU.meta.color.attributeLabel}`;
      } else {
        colorListHeadingLabel.innerHTML =
          DukaanData.DUKAAN_LANGUAGE.SELECT_COLOR;
      }
    }
  }
};

window.handleVariantChange = (productUUID) => {
  if (!productUUID) return;

  const element = document.querySelector('product-variant-selection-modal');
  const addToBagElement = element.querySelector('add-to-bag-button');
  const buyNowElement = element.querySelector('buy-now-button-load-point');
  const formData = new FormData(
    element.querySelector('form#variant-selection')
  );
  const data = [...formData.entries()].reduce((acc, [key, value]) => {
    acc[key] = value;
    return acc;
  }, {});

  const product = DukaanData.PRODUCTS_MAP[productUUID];
  const { skus } = product;
  const currentSKU = skus.find((sku) =>
    sku.meta.color
      ? sku.meta.size.value === data.size && sku.meta.color.value === data.color
      : sku.meta.size.value === data.size
  );
  if (!currentSKU) return;

  addToBagElement.dataset.productUuid = productUUID;
  addToBagElement.dataset.skuUuid = currentSKU.uuid;
  addToBagButtonRenderer(addToBagElement);

  if (buyNowElement) {
    buyNowElement.dataset.productUuid = productUUID;
    buyNowElement.dataset.skuUuid = currentSKU.uuid;
    buyNowButtonRenderer(buyNowElement);
  }

  handleModalChanges(product, currentSKU);
};

// set navbar active element
window.handleNavActiveClass = (header, activeClass) => {
  const menu = {
    home: '/',
    shop: '/categories/',
  };
  if (window.DukaanData.STORE_MENU) {
    window.DukaanData.STORE_MENU.forEach((storeMenu) => {
      if (storeMenu.content_object?.slug)
        menu[
          storeMenu.content_object?.slug
        ] = `/p/${storeMenu.content_object.slug}/`;
    });
  }

  const btns = [...header.children];
  // const current = document.getElementsByClassName('active');

  let pathname = window.location.pathname
    .split(`/${DukaanData.DUKAAN_STORE.link}`)?.[1]
    ?.replace(/\/$/, '') // removing the trailing slash
    ?.trim();

  pathname += '/';

  if (btns.length > 1) {
    let active = '';
    Object.entries(menu).forEach((el) => {
      if (pathname === el[1]) {
        const [activeEl] = el;
        active = activeEl;
      }
    });

    [...btns].forEach((el) => {
      el.classList.remove(activeClass);
    });
    if (active) {
      const elements = [...btns].filter((el) => el.id === active);
      elements.forEach((ele) => {
        ele.classList.add(activeClass);
      });
    } else if (pathname === '/') {
      [...btns].forEach((ele) => {
        if (ele.id === 'home') {
          ele.classList.add(activeClass);
        }
      });
    }
  }
};

window.handleRenderHeaderMenuBtn = async () => {
  const navbarWidth = document.querySelector(
    '#desktop-header-nav-bar'
  ).offsetWidth;
  const menuButton = document.querySelector('.header-menu-btn');
  let navbarItemsWidth = 0;

  document
    .querySelectorAll('#desktop-header-nav-bar .header-section-nav-item')
    .forEach((el) => {
      navbarItemsWidth += el.offsetWidth;
    });

  if (navbarItemsWidth >= navbarWidth) {
    const ready = await document.fonts.ready;
    if (ready) {
      menuButton.classList.remove('hidden');
    }
  }
};
window.toggleSubMenuItems = (id) => {
  const element = q$.selectById(`${id}`).elem;

  let rotation = 0;
  rotation += 180;
  element.querySelector('.icon').style.transform = `rotate(${rotation}deg)`;
  element.nextElementSibling.classList.toggle('hidden');
  element.classList.toggle('menu-accordion-active');
};
window.renderSubMenuSidebarContent = (e) => {
  const targetName = e.currentTarget.name;
  console.log(targetName);

  const sidebarWrapper = q$.select('.menu-items-sidebar-wrapper').elem;
  q$.selectAll('.mobile-menu-dropdown', sidebarWrapper).addClassAll('hidden');
  q$.selectById(`${targetName}-sub-menu`).removeClass('hidden');
};

window.renderSocialMediaLinks = () => {
  const socialMediaLinkTags = document.querySelectorAll('social-media-links');
  socialMediaLinkTags.forEach((ele) => {
    ele.innerHTML = '';
    const socialMediaLinksTemplate = document.querySelector(
      '#social-media-links'
    );
    const socialMediaLinks = document.importNode(
      socialMediaLinksTemplate.content,
      true
    );
    ele.appendChild(socialMediaLinks);
  });
};

window.commonInitializer = () => {
  const desktopHeader = document.getElementById('desktop-header-nav-bar');
  const desktopActiveClass = 'header-item-selected';

  const mobileHeader = document.getElementById('bottom-navbar-container');
  const mobileActiveClass = 'selected-bottom-nav-item';

  renderSocialMediaLinks();
  handleMenuStates();
  toggleCouponFooter();
  handleNavActiveClass(desktopHeader, desktopActiveClass);
  handleNavActiveClass(mobileHeader, mobileActiveClass);
  checkCouponSticky();
  GAPage();

  // sidebar menu items
  // initSidebarMenuItems();
};

window.debounce = (callback, timeout = 300) => {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => {
      callback.apply(this, args);
    }, timeout);
  };
};

window.customDiscountBadgeFormatter = (product, categoryProductCard) => {
  const {
    original_price: originalPrice,
    selling_price: sellingPrice,
    in_stock: inStock,
  } = product;

  const soldOutBadge = categoryProductCard.querySelector(
    '[data-product-soldout-badge]'
  );
  const discountBadge = categoryProductCard.querySelector(
    '[data-product-discount-badge]'
  );

  if (discountBadge && originalPrice > sellingPrice) {
    discountBadge.classList.remove('hidden');
  } else if (soldOutBadge && !inStock) {
    soldOutBadge.classList.remove('hidden');
  }
};

window.APP_IDS = {
  ...(window.APP_IDS || {}),
  STORE_LOCATOR: '6286104b4f1ca25e2256f6b7',
};

window.addEventListener('load', () => {
  axios
    .get(
      `https://apps.mydukaan.io/public/v2/apps/store/${window.DukaanData.DUKAAN_STORE.id}/`
    )
    .then((response) => {
      const { store_apps_list: appList } = response.data;
      const availablePlugins = appList?.reduce((acc, item) => {
        if (item.isActive) {
          /* eslint no-underscore-dangle: 0 */
          acc[item._id] = item;
        }
        return acc;
      }, {});
      const isStoreLocatorPresent = Boolean(
        !!availablePlugins && availablePlugins[APP_IDS.STORE_LOCATOR]
      );
      const storeLocatorTags = document.querySelectorAll('.store-locator-link');
      if (isStoreLocatorPresent) {
        storeLocatorTags.forEach((tag) => tag.classList.remove('hidden'));
      } else {
        storeLocatorTags.forEach((tag) => tag.remove());
      }
      const navbarWidth = document.querySelector(
        '#desktop-header-nav-bar'
      ).offsetWidth;

      const menuButton = document.querySelector('.header-menu-btn');
      let navbarItemsWidth = 0;
      document
        .querySelectorAll('#desktop-header-nav-bar .header-section-nav-item')
        .forEach((el) => {
          const elStyle = getComputedStyle(el);
          let elRightMargin = elStyle?.marginRight ?? 0;
          if (
            typeof elRightMargin === 'string' &&
            elRightMargin.includes('px')
          ) {
            elRightMargin = parseInt(elRightMargin, 10);
          } else if (typeof elRightMargin === 'number') {
            return;
          } else {
            elRightMargin = 0;
          }
          navbarItemsWidth += el.offsetWidth + elRightMargin;
        });
      if (navbarItemsWidth > navbarWidth) {
        menuButton.classList.remove('hidden');
      }
    });
});

window.getCustomDiscountText = (discount) => `(${discount}% OFF)`;

window.productCardAdditionalRenderer = (productCard, product) => {
  const {
    in_stock: inStock,
    selling_price: sellingPrice,
    original_price: originalPrice,
  } = product;
  if (!inStock) {
    window.q$
      .select('.dkn-product-card-soldout-badge', productCard)
      .removeClass('hidden');
  }
  const discount = window.getDiscountPercentValue(sellingPrice, originalPrice);
  if (discount) {
    window.q$
      .select('.dkn-product-card-on-sale-badge', productCard)
      .removeClass('hidden');
  }
  productCardImageCarouselRenderer(product, productCard);
};

window.couponPageProductCardTemplateId = 'product-card-template';
