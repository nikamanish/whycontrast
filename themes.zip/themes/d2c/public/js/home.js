document.addEventListener('DOMContentLoaded', () => {
  if (document.querySelector('#splide-banners')) {
    new Splide('#splide-banners', {
      type: 'loop',
      autoplay: true,
      interval: 5000,
      arrows: false,
      pauseOnHover: false,
    }).mount();
  }

  if (document.querySelector('#splide-banners-mobile')) {
    new Splide('#splide-banners-mobile', {
      type: 'loop',
      autoplay: true,
      interval: 5000,
      arrows: false,
      pauseOnHover: false,
    }).mount();
  }
});

window.fetchCouponsAndOffers = () => {
  const headers = {};
  if (localStorage && localStorage.al_to) {
    headers.Authorization = `Bearer ${localStorage.al_to}`;
  }
  headers['Content-Type'] = 'application/json';
  headers['x-requested-with'] = window?.DukaanData?.DUKAAN_SESSION_ID;

  const urls = [
    `${window.DukaanData.CLIENT_API_ENDPOINT}/api/coupon/buyer/${DukaanData.DUKAAN_STORE.link}/coupon/v2/`,
    `${window.DukaanData.CLIENT_API_ENDPOINT}/api/store/buyer/${DukaanData.DUKAAN_STORE.link}/payment-discount-provider/`,
  ];

  const requests = urls.map((url) =>
    axios.get(url, {
      headers,
    })
  );

  Promise.all(requests)
    .then(([couponsDataRes, offersDataRes]) => {
      const couponsData = couponsDataRes?.data.results || [];
      const discountProviders = offersDataRes?.data.data || {};
      const background =
        window.DukaanData.DUKAAN_THEME_DATA.meta?.background?.mode ||
        window.DukaanData.DUKAAN_THEME_MODE ||
        'light';
      if (couponsData.length > 0) {
        window.DukaanData.DUKAAN_COUPONS = getCouponSerializedData(
          couponsData,
          background
        );
        customTag('mobile-coupons', mobileCouponsRenderer);
      }
      const offersData = getDiscountsArray(
        discountProviders,
        false,
        background
      );
      if (offersData.length > 0) {
        window.DukaanData.DUKAAN_PAYMENT_OFFERS = offersData;
      }
      const totalCount = couponsData.length + offersData.length;
      if (totalCount > 0)
        document.getElementById('offers-label').classList.remove('hidden');
    })
    .catch((error) => {
      console.log(error);
    });
};

window.appInitializer = () => {
  fetchCouponsAndOffersOnIndex();
  fetchCouponsAndOffers();
  hashProductMap(DukaanData.DUKAAN_CATALOG);
  druidStorePageView();
  initProductSplide();

  let loading = false;
  const offsetCount = DukaanData.DUKAAN_CATALOG_PROPS.offset;
  let { offset } = DukaanData.DUKAAN_CATALOG_PROPS;
  let hasMore = true;

  fetchProductCoupons(getProductIdsFromCategories(DukaanData.DUKAAN_CATALOG));

  const fetchBestSellers = async () => {
    if (loading) return;
    loading = true;
    const response = await fetch(
      `${window.DukaanData.CLIENT_API2_ENDPOINT}/api/store/buyer/${window.DukaanData.DUKAAN_STORE.link}/bestseller/v3/?offset=${offset}`
    );
    const res = await response?.json();
    const { results: rawResults = [] } = res || {};
    const count = rawResults?.length;
    const results = rawResults?.filter((rR) => rR.products.length > 0);
    hashProductMap(results);
    hashCategory(results);
    renderBestSellers(results, 8);
    // fetchProductCoupons(getProductIdsFromCategories(results));
    if (count < offsetCount) {
      hasMore = false;
      removeScroller({ observeThis: 'bestseller-observer' });
    } else {
      hasMore = true;
      offset += offsetCount;
    }
    loading = false;
  };

  applyScroller({
    loading,
    hasMore,
    cb: fetchBestSellers,
    observeThis: 'bestseller-observer',
    loadPoint: document.querySelector('best-seller-load-point'),
  });
};
