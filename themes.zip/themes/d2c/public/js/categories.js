window.renderCategoriesList = (categories, nextUrl, firstFetch) => {
  if (categories?.length === 0 && firstFetch) {
    document
      .getElementById('main-categories-container')
      .classList.add('hidden');
    document.getElementById('no-categories-found').classList.remove('hidden');
    return;
  }

  customTag('categories-list-template', (element) =>
    categoriesRenderer(element, categories, nextUrl)
  );
};

window.categoriesRenderer = (mountElement, categories, nextUrl) => {
  document
    .querySelectorAll('.category-list-shimmer-item')
    ?.forEach((el) => el.remove());

  const categoryCardTemplate = document.getElementById(
    'categories-card-template'
  );

  categories?.forEach((category) => {
    const categoryCard = document.importNode(
      categoryCardTemplate.content,
      true
    );

    const categoryUrl = getCategoryCardLink(category);

    categoryCard
      .querySelectorAll('a')
      .forEach((el) => el.setAttribute('href', categoryUrl));

    categoryCard
      .querySelector('.product-category-image img')
      .setAttribute('src', `${getCdnUrl(category.image, 700)}`);
    categoryCard.querySelector('.product-category-name').textContent =
      category.name;

    mountElement.appendChild(categoryCard);
  });

  const currentEventObserver = document.getElementById(
    'categories-list-observer'
  );

  if (nextUrl) {
    if (currentEventObserver) {
      currentEventObserver?.remove();
    }

    const newObserverElement = document.createElement('div');
    newObserverElement.setAttribute('id', 'categories-list-observer');
    mountElement.appendChild(newObserverElement);

    const observerElement = document.getElementById('categories-list-observer');

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          // renderShimmer(
          //   'categories-list-template',
          //   'categories-card-shimmer',
          //   9
          // );
          fetchStoreCategoriesInit({ nextUrl, cb: renderCategoriesList });
        }
      },
      {
        threshold: 1,
      }
    );
    observer.observe(observerElement);
  } else {
    currentEventObserver?.remove();
  }
};

window.fetchStoreCategoriesInit = null;

window.appInitializer = () => {
  renderShimmer('categories-list-template', 'categories-card-shimmer', 9);
  fetchStoreCategoriesInit = fetchStoreCategories();
  fetchStoreCategoriesInit({ cb: renderCategoriesList, firstFetch: true });
};
