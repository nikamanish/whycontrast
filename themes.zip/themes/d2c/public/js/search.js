window.handleSearchPageInputChange = (event) => {
  const searchVal = event.target.value;

  if (searchVal.length > 0) {
    window.location.search = `?query=${searchVal}`;
  } else {
    document.querySelector('.search-input').value = '';
    document.querySelector('.input-wrapper svg').classList.add('hidden');
  }
};

window.handleSearchPageInputKeyup = (event) => {
  const searchVal = event.target.value;
  handleEnableInputCrossBtn(searchVal);
};

window.handleSearchPageInputClear = () => {
  document.querySelector('.search-input').value = '';
  document.querySelector('.input-wrapper svg').classList.add('hidden');
};

window.handleEnableInputCrossBtn = (searchVal) => {
  if (searchVal.length > 0) {
    document.querySelector('.input-wrapper svg').classList.remove('hidden');
  } else {
    document.querySelector('.input-wrapper svg').classList.add('hidden');
  }
};
