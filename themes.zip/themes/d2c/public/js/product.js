window.mainCarousel = null;
window.thumbnails = null;

window.appInitializer = () => {
  const productFromServer = DukaanData.DUKAAN_PRODUCT;
  const serializedSKUs = serializeSKUs(productFromServer.skus || []);
  const attributes = getAllProductAttributeValues(serializedSKUs);
  const product = {
    ...productFromServer,
    skus: serializedSKUs,
    attributes,
  };
  window.DukaanData.PRODUCTS_DETAILS = product;
  window.DukaanData.PRODUCTS_MAP = {
    ...(DukaanData.PRODUCTS_MAP || []),
    [product.uuid]: product,
  };

  productPageCommonFnCalls(product);
};

document.addEventListener('DOMContentLoaded', () => {
  if (
    document.querySelector('#splide-products') &&
    document.querySelector('#thumbnail-carousel')
  ) {
    window.mainCarousel = new Splide('#splide-products', {
      type: 'fade',
      rewind: true,
      pagination: false,
      arrows: false,
      updateOnMove: true,
      breakpoints: {
        768: {
          width: '100%',
        },
      },
    });

    mainCarousel.on('click', (e) => {
      playProductVideo(e);
    });

    window.thumbnails = new Splide('#thumbnail-carousel', {
      gap: 8,
      rewind: true,
      pagination: false,
      isNavigation: true,
      arrows: false,
    });
    thumbnails.on('click', () => {
      pauseAllProductVideos();
    });

    mainCarousel?.sync(thumbnails);
    mainCarousel?.mount();
    thumbnails?.mount();
  }
});

window.scrollToSKUImage = (activeSKU) => {
  const primaryImage = activeSKU?.primary_image;
  const allImages = DukaanData?.DUKAAN_PRODUCT?.all_images;
  if (allImages?.length > 0) {
    const index = allImages?.indexOf(primaryImage);
    if (index >= 0 && !!mainCarousel) {
      if (mainCarousel) {
        const { isMobile } = deviceType();
        if (isMobile) {
          window?.mainCarousel?.go(index);
          window?.thumbnails?.go(index);
        } else {
          document
            .getElementById(`pdp-image-${index + 1}`)
            ?.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      }
    }
  }
};
