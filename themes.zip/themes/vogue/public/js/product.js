window.mainCarousel = null;
window.thumbnails = null;

document.addEventListener('DOMContentLoaded', () => {
  mainCarousel = new Splide('#main-carousel', {
    type: 'fade',
    rewind: true,
    pagination: false,
    arrows: false,
  });
  mainCarousel.on('click', (e) => {
    playProductVideo(e);
  });

  thumbnails = new Splide('#thumbnail-carousel', {
    fixedWidth: 140,
    fixedHeight: 175,
    perPage: 3,
    gap: 10,
    // rewind: true,
    pagination: false,
    isNavigation: true,
    arrows: true,
    direction: 'ttb',
    height: '420px',
    // wheel: true,
    // type : 'loop',
    classes: {
      prev: 'active',
    },
    breakpoints: {
      600: {
        direction: false,
        pagination: false,
        arrows: false,
      },
    },
  });
  thumbnails.on('click', () => {
    pauseAllProductVideos();
  });

  mainCarousel?.sync(thumbnails);
  mainCarousel?.mount();
  thumbnails?.mount();
});

window.SIMILAR_PRODUCT_LIMIT = 0;

window.appInitializer = () => {
  const { isMobile } = deviceType();
  SIMILAR_PRODUCT_LIMIT = isMobile ? 6 : 12;

  const productFromServer = DukaanData.DUKAAN_PRODUCT;
  const serializedSKUs = serializeSKUs(productFromServer.skus || []);
  const attributes = getAllProductAttributeValues(serializedSKUs);
  const product = {
    ...productFromServer,
    skus: serializedSKUs,
    attributes,
  };
  window.DukaanData.PRODUCTS_DETAILS = product;
  window.DukaanData.PRODUCTS_MAP = {
    ...(DukaanData.PRODUCTS_MAP || []),
    [product.uuid]: product,
  };
  productPageCommonFnCalls(product);

  const mountElem = document.querySelector('.detail-inner');
  if (typeof dknRenderWishlistButtons !== 'undefined')
    window.dknRenderWishlistButtons(mountElem);
};

window.scrollToSKUImage = (activeSKU) => {
  const primaryImage = activeSKU?.primary_image;
  const allImages = DukaanData?.DUKAAN_PRODUCT?.all_images;
  if (allImages?.length > 0) {
    const index = allImages?.indexOf(primaryImage);
    if (index >= 0) {
      window?.mainCarousel?.go(index);
      window?.thumbnails?.go(index);
    }
  }
};
