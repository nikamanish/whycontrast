window.appInitializer = () => {
  hashProductMap(window.DukaanData.DUKAAN_CATALOG);
  druidStorePageView();
  fetchCouponsAndOffersOnIndex();
  initProductSplide();

  let loading = false;
  const offsetCount = DukaanData.DUKAAN_CATALOG_PROPS.offset;
  let { offset } = DukaanData.DUKAAN_CATALOG_PROPS;
  let hasMore = true;

  fetchProductCoupons(getProductIdsFromCategories(DukaanData.DUKAAN_CATALOG));

  const productListMountElement = document.querySelector(
    'best-seller-load-point'
  );
  if (typeof dknRenderWishlistButtons !== 'undefined') {
    window.dknRenderWishlistButtons(productListMountElement);
  }

  const fetchBestSellers = async () => {
    if (loading) return;
    loading = true;
    // const url = [
    //   `https://staging.store-front.api.dukan.tech/api/store/buyer/${window.DukaanData.DUKAAN_STORE.link}/bestseller/v3/?offset=${offset}`,
    //   `${window.DukaanData.CLIENT_API2_ENDPOINT}/api/store/buyer/${window.DukaanData.DUKAAN_STORE.link}/bestseller/v3/?offset=${offset}`,
    // ];
    const response = await fetch(
      `${window.DukaanData.CLIENT_API2_ENDPOINT}/api/store/buyer/${window.DukaanData.DUKAAN_STORE.link}/bestseller/v3/?offset=${offset}`
    );
    const res = await response?.json();
    const { results: rawResults = [] } = res || {};
    const count = rawResults?.length;
    const results = window.bestSellerSerializer(
      rawResults?.filter((rR) => rR.products.length > 0),
      DukaanData.DUKAAN_USER_SELECTED_LANGUAGE
    );

    hashProductMap(results);
    hashCategory(results);
    renderBestSellers(results, 8);
    // fetchProductCoupons(getProductIdsFromCategories(results));
    if (count < offsetCount) {
      hasMore = false;
      removeScroller({ observeThis: 'bestseller-observer' });
    } else {
      hasMore = true;
      offset += offsetCount;
    }
    loading = false;
  };

  applyScroller({
    loading,
    hasMore,
    cb: fetchBestSellers,
    observeThis: 'bestseller-observer',
    loadPoint: document.querySelector('best-seller-load-point'),
  });

  if (!document.querySelector('#splide-banners')) return;
  new Splide('#splide-banners', {
    type: 'slide',
    autoplay: true,
    interval: 5000,
    arrows: false,
    rewind: true,
    pauseOnHover: false,
  }).mount();
  if (!document.querySelector('#splide-banners-mobile')) return;
  new Splide('#splide-banners-mobile', {
    type: 'slide',
    autoplay: true,
    interval: 5000,
    arrows: false,
    rewind: true,
    pauseOnHover: false,
  }).mount();
};
