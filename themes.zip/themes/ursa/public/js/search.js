window.handleSearchPageInputChange = (event) => {
  const searchVal = event.target.value;

  if (searchVal.length > 0) {
    window.location.search = `?query=${searchVal}`;
  } else {
    document.querySelector('.search-input').value = '';
    document.querySelector('.close-icon').classList.add('hidden');
  }
};

window.handleSearchPageInputKeyup = (event) => {
  const searchVal = event.target.value;
  handleEnableInputCrossBtn(searchVal);
};

window.handleSearchPageInputClear = () => {
  document.querySelector('.search-input').value = '';
  document.querySelector('.close-icon').classList.add('hidden');
};

window.handleEnableInputCrossBtn = (searchVal) => {
  if (searchVal.length > 0) {
    document.querySelector('.close-icon').classList.remove('hidden');
  } else {
    document.querySelector('.close-icon').classList.add('hidden');
  }
};

const productSearchCount = document.querySelector(
  '.advance-filter__product-count'
);
console.log(productSearchCount.value);
window.productCountSearch = () => {
  if (!(productSearchCount.value == 0)) {
    document.querySelector('.sort-btn-toggle').classList.add('hidden');
    document.querySelector('.sort-lable').classList.add('hidden');
  } else {
    document.querySelector('.sort-btn-toggle').classList.remove('hidden');
    document.querySelector('.sort-lable').classList.remove('hidden');
  }
};
productCountSearch();

window.customCounterRender = (count) => count;
