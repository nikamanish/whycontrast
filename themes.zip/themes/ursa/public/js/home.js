window.PRODUCT_SPLIDE_INSTANCES = {};
// window.renderCustomProductVariants = (productCard, product, options = {}) => {
//   const defaultSKU = 0;
//   productCard.setAttribute('id', 'featured-product-home-page');

//   const defaultVariantSelectionFormAdditionalRenderer = (
//     variantSelectionForm
//   ) => {
//     const addToBagElement =
//       variantSelectionForm.querySelector('add-to-bag-button');
//     if (addToBagElement) {
//       addToBagElement.dataset.productUuid = product.uuid;
//       addToBagElement.dataset.skuUuid = product.skus[defaultSKU].uuid;
//       addToBagButtonRenderer(addToBagElement);
//     }

//     const buyNowElement = variantSelectionForm.querySelector(
//       'buy-now-button-load-point'
//     );
//     if (buyNowElement) {
//       buyNowElement.dataset.productUuid = product.uuid;
//       buyNowElement.dataset.skuUuid = product.skus[defaultSKU].uuid;
//       buyNowButtonRenderer(buyNowElement);
//     }
//   };

//   const variantSelectionForm = window.renderVariantSelectionForm(
//     'variant-selection-form',
//     product.uuid,
//     defaultVariantSelectionFormAdditionalRenderer,
//     null,
//     '#featured-product-home-page'
//   );

//   const variantFormMountNode = productCard.querySelector(
//     '#variant-selection-form-wrapper'
//   );
//   variantFormMountNode.appendChild(variantSelectionForm);
// };
window.renderCustomProductVariants = (productCard, product, options = {}) => {
  productCard.setAttribute('id', 'featured-product-home-page');
  const productUUID = product.uuid;
  dknAddProductsToProductsMap([DukaanData.PRODUCTS_MAP[productUUID]]);
  const activeProduct = DukaanData.PRODUCTS_MAP[productUUID];

  const activeSKU = dknGetFirstAvailableSKU(activeProduct.skus);
  const productContext = {
    key: 'variantModal',
    productUUID,
    skuUUID: activeSKU.uuid,
  };
  const variantFormElement = q$.select(
    '.variant-selection-form-wrapper',
    productCard
  ).elem;
  const actionButtonsElement = q$.select(
    '.dkn-action-button-wrapper',
    productCard
  ).elem;
  actionButtonsElement.appendChild(
    q$.selectById('dkn-action-button-wrapper-template').getTemplateContent()
      .elem
  );

  dknRenderProductVariantForm(productContext, variantFormElement);
  dknRenderActionButtons(productContext, actionButtonsElement);
};

window.featuredProductCardAdditionalRenderer = (cardWrapper, product) => {
  const productCard = cardWrapper.querySelector('.dkn-product-card');

  productCard.setAttribute(
    'data-card-reference-id',
    `${window.productCardCount}`
  );
  productCard.dataset.uuid = product.uuid;
  const newElement = document.createElement('div');
  newElement.innerHTML = product.description;
  const text = newElement.textContent || newElement.innerText || '';
  if (text) {
    productCard.querySelector('.featured-product-description').innerHTML = text;
  } else {
    productCard
      .querySelector('.featured-product-description-wrapper')
      .classList.add('hidden');
  }

  window.handleProductCardSplideInit(productCard, product);

  window.renderCustomProductVariants(productCard, product);
};

// feature product splide
window.handleProductCardSplideInit = (productCard, product) => {
  // const productCardId = productCard.dataset;

  const { all_images: productImagesArray } = product;
  const imageSlideTemplateId = 'product-splide-container';
  const imageListContainer = productCard.querySelector(
    '.dkn-product-card-image-carousel'
  );

  const productCardCarouselWrapper = productCard.querySelector(
    `#dkn-product-card-image-carousel-wrapper`
  );

  if (productImagesArray?.length > 0) {
    // render image carousel
    productImagesArray?.forEach((image) => {
      const imageSlideContainer = window.q$
        .selectById(imageSlideTemplateId)
        .getTemplateContent().elem;
      window.q$
        .select('.dkn-product-card-image-carousel-item', imageSlideContainer)
        .setAttribute('src', `${window.getCdnUrl(image, 700)}`);
      imageListContainer.appendChild(imageSlideContainer);
    });
  } else {
    const imageSlideContainer = window.q$
      .selectById(imageSlideTemplateId)
      .getTemplateContent().elem;
    window.q$
      .select('.dkn-product-card-image-carousel-item', imageSlideContainer)
      .setAttribute('src', product.image);
    imageListContainer.appendChild(imageSlideContainer);
  }
  // initialize splide
  const productCardCarousel = new Splide(productCardCarouselWrapper, {
    type: 'fade',
    autoplay: false,
    interval: 1500,
    arrows: productImagesArray?.length > 1,
    pauseOnHover: false,
    pagination: false,
    rewind: true,
    breakpoints: {
      768: {
        arrows: false,
        pagination: true,
      },
    },
  });

  productCardCarousel.mount();
};

window.fetchProductsFromIds = (productIds, callbackFn) => {
  let paramString = '';
  productIds.forEach((productId) => {
    paramString += `&id=${+productId}`;
  });

  fetch(
    `${window.DukaanData.CLIENT_API_ENDPOINT}/api/product/buyer/${DukaanData.DUKAAN_STORE.uuid}/product-list/v2/?pop_fields=category_data,store_data${paramString}`,
    {
      headers: {
        'Content-Type': 'application/json',
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
      },
    }
  )
    .then((res) => res.json())
    .then((res) => {
      if (res && res.results.length > 0) {
        const products = res.results;

        DukaanData.PRODUCTS_MAP = {
          ...DukaanData.PRODUCTS_MAP,
          ...products.reduce((map, product) => {
            const serializedSKUs = serializeSKUs(product.skus || []);
            const attributes = getAllProductAttributeValues(serializedSKUs);
            map[product.uuid] = {
              ...product,
              skus: serializedSKUs,
              attributes,
            };
            return map;
          }, {}),
        };

        const mountElem = document.querySelector(
          `feature-product-list-load-point`
        );

        window.productListRenderer(mountElem, products, {
          templateId: 'feature-product-card-template',
          additionalRenderer: window.featuredProductCardAdditionalRenderer,
        });

        // callbackFn();
      }
    })
    .catch((err) => {});
};

// window.handleVariantModalChange = (
//   mountElement,
//   event,
//   {
//     variantSelectionFormTemplateId = 'variant-selection-form',
//     variantSelectionFormAdditionalRenderer,
//     buttonTemplateId,
//   } = {}
// ) => {
//   mountElement.innerHTML = '';
//   const productUUID = event.value;
//   const activeProduct = window.DukaanData.PRODUCTS_MAP[productUUID];
//   const modalTemplate = document.getElementById(
//     'product-variant-selection-modal'
//   );
//   const wrapperElement = document.importNode(modalTemplate.content, true);
//   const element = wrapperElement.querySelector('.modal');
//   const variantFormMountNode =
//     element.querySelector('.variant-selection-form-wrapper') ||
//     element.querySelector('.modal-content');

//   if (!productUUID) {
//     element.classList.add('hidden');
//     variantFormMountNode.innerHTML = '';
//     /**
//      * Splide Slider added in window to be accessible from all files
//      * Need to set SplideSlider to undefined on modal close
//      */
//     if (typeof window.splideSlider === 'object')
//       window.splideSlider = undefined;
//   } else {
//     variantFormMountNode.innerHTML = '';
//     element.classList.remove('hidden');

//     const defaultSKU = 0;

//     const defaultVariantSelectionFormAdditionalRenderer = (
//       variantSelectionForm
//     ) => {
//       const addToBagElement =
//         variantSelectionForm.querySelector('add-to-bag-button');
//       if (addToBagElement) {
//         addToBagElement.dataset.productUuid = activeProduct.uuid;
//         addToBagElement.dataset.skuUuid = activeProduct.skus[defaultSKU].uuid;
//         addToBagButtonRenderer(addToBagElement);
//       }

//       const buyNowElement = variantSelectionForm.querySelector(
//         'buy-now-button-load-point'
//       );
//       if (buyNowElement) {
//         buyNowElement.dataset.productUuid = activeProduct.uuid;
//         buyNowElement.dataset.skuUuid = activeProduct.skus[defaultSKU].uuid;
//         buyNowButtonRenderer(buyNowElement);
//       }
//     };

//     // render reviews data in add to bag modal
//     window.q$
//       .select('.dkn-product-card-review-info', element)
//       .modifyInnerHTML('');

//     window.q$
//       .select('.dkn-product-card-review-info', element)
//       .setAttribute('data-product-id', activeProduct.id);

//     window.fetchRatingsDataFromProductIds([activeProduct.id], element, {
//       reviewInfoTemplateId: 'dkn-product-review-with-count-template',
//       getCustomReviewsCountText: window.getCustomReviewsCountText,
//       starHeight: window.modalStarHeight,
//       starWidth: window.modalStarWidth,
//     });

//     const variantSelectionForm = renderVariantSelectionForm(
//       variantSelectionFormTemplateId,
//       productUUID,
//       variantSelectionFormAdditionalRenderer ||
//         defaultVariantSelectionFormAdditionalRenderer,
//       buttonTemplateId
//     );

//     variantFormMountNode.appendChild(variantSelectionForm);

//     mountElement.appendChild(element);
//     if (typeof handleModalChanges !== 'undefined')
//       handleModalChanges(activeProduct, activeProduct.skus[defaultSKU]);
//   }
// };

window.renderFeaturedProduct = () => {};

window.appInitializer = () => {
  fetchCouponsAndOffersOnIndex();
  hashProductMap(DukaanData.DUKAAN_CATALOG);
  druidStorePageView();
  const featureProductData =
    DukaanData?.DUKAAN_THEME_DATA?.meta?.sections?.featureProduct || {};
  if (featureProductData?.isActive) {
    const productIds = featureProductData.products.map((product) => product.id);
    fetchProductsFromIds(productIds, renderFeaturedProduct);
  }
};

document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('main-carousel') !== null)
    new Splide('#main-carousel', {
      type: 'loop',
      autoplay: true,
      pauseOnHover: false,
      width: '100%',
      pagination: true,
      arrows: false,
    }).mount();
  if (document.getElementById('main-carousel-mobile') !== null)
    new Splide('#main-carousel-mobile', {
      type: 'loop',
      autoplay: true,
      pauseOnHover: false,
      width: '100%',
      pagination: true,
      arrows: false,
    }).mount();
});

document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('feature-product-section') !== null)
    new Splide('#feature-product-section', {
      type: 'loop',
      autoplay: true,
      pauseOnHover: false,
      width: '50%',
      pagination: true,
      arrows: false,
      breakpoint: {
        768: {
          arrows,
        },
      },
    }).mount();
});

document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('customer-section-banner') !== null)
    new Splide('#customer-section-banner', {
      type: 'loop',
      autoplay: true,
      delay: 5000,
      pauseOnHover: false,
      width: '100%',
      pagination: true,
      arrows: false,
    }).mount();
});
