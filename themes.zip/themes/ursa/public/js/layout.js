// window.showMenuDropdown = (event, parentId, index) => {
//   const { target } = event;
//   if (index === '0') {
//     q$.selectAll(`.second-menu-item-list ul.menu-items-list`).addClassAll(
//       'hidden'
//     );
//     q$.selectAll(`.third-menu-item-list ul.menu-items-list`).addClassAll(
//       'hidden'
//     );
//     q$.selectAll(`.first-menu-item-list ul li`).removeClassAll(
//       'active-nav-item'
//     );
//     q$.selectAll(`.second-menu-item-list ul li`).removeClassAll(
//       'active-nav-item'
//     );
//     q$.selectAll(`.third-menu-item-list ul li`).removeClassAll(
//       'active-nav-item'
//     );
//   } else if (index === '1') {
//     q$.selectAll(`.third-menu-item-list ul.menu-items-list`).addClassAll(
//       'hidden'
//     );
//     q$.selectAll(`.second-menu-item-list ul li`).removeClassAll(
//       'active-nav-item'
//     );
//     q$.selectAll(`.third-menu-item-list ul li`).removeClassAll(
//       'active-nav-item'
//     );
//   } else if (index === '2') {
//     q$.selectAll(`.third-menu-item-list ul li`).removeClassAll(
//       'active-nav-item'
//     );
//   }
//   target.classList.add('active-nav-item');
//   q$.select(
//     `ul.menu-items-list[data-parent-dropdown-id="${parentId}"]`
//   ).removeClass('hidden');
// };

window.getDataFromLocalStorageV2 = (key) =>
  JSON.parse(localStorage.getItem(key)) || [];

window.getHistoryStoragekey = () =>
  `v3-${window.DukaanData.DUKAAN_STORE.link}-search-history`;

window.setDataFromLocalStorage = (key, value) => {
  localStorage.setItem(getHistoryStoragekey(), JSON.stringify(value));
};

window.handleNavActiveClass = (header, activeClass) => {
  const menu = {
    home: '/',
    shop: '/categories/',
  };
  if (window.DukaanData.STORE_MENU) {
    window.DukaanData.STORE_MENU.forEach((storeMenu) => {
      if (storeMenu.content_object?.slug)
        menu[storeMenu.content_object?.slug] =
          storeMenu.content_type === 'productcategory'
            ? `/categories/${storeMenu.content_object.slug}/`
            : `/p/${storeMenu.content_object.slug}/`;
    });
  }

  const btns = [...header.children];
  // const current = document.getElementsByClassName('active');

  let pathname = window.location.pathname
    .split(`/${DukaanData.DUKAAN_STORE.link}`)?.[1]
    ?.replace(/\/$/, '') // removing the trailing slash
    ?.trim();

  pathname += '/';

  if (btns.length > 1) {
    let active = '';
    Object.entries(menu).forEach((el) => {
      if (pathname === el[1]) {
        const [activeEl] = el;
        active = activeEl;
      }
    });

    [...btns].forEach((el) => {
      el.classList.remove(activeClass);
    });
    if (active) {
      const elements = [...btns].filter((el) => el.id === active);
      elements.forEach((ele) => {
        ele.classList.add(activeClass);
      });
    } else if (pathname === '/') {
      [...btns].forEach((ele) => {
        if (ele.id === 'home') {
          ele.classList.add(activeClass);
        }
      });
    }
  }
};

window.handleActiveNavStateMobile = () => {
  const pathName = location.pathname.split(DukaanData.DUKAAN_BASE_URL);
  const currentPath = pathName[pathName.length - 1].replace('/', '');
  const mobileNavBar = window.q$.select('#mobile-bottom-nav-bar').elem;
  if (currentPath === '') {
    const homeSvg = window.q$.select('#home-svg-mobile-nav').elem;
    const homeSvgFilled = window.q$.select('.home-svg-mobile-nav-filled').elem;
    const homeLabel = window.q$.select('.home-mob-nav-label').elem;
    mobileNavBar.classList.remove('d-none');
    homeLabel.classList.add('mob-nav-label-active');
    homeSvg.classList.add('hidden', 'mob-nav-label-active');
    homeSvgFilled.classList.remove('hidden');
  } else if (
    currentPath.includes('categories') &&
    !currentPath.includes('categories/')
  ) {
    const shopSvg = window.q$.select('#shop-svg-mobile-nav').elem;
    const shopSvgFilled = window.q$.select('.shop-svg-mobile-nav-filled').elem;
    const shopLabel = window.q$.select('.shop-mob-nav-label').elem;
    mobileNavBar.classList.remove('d-none');
    shopLabel.classList.add('mob-nav-label-active');
    shopSvg.classList.add('hidden', 'mob-nav-label-active');
    shopSvgFilled.classList.remove('hidden');
  } else if (currentPath.includes('bag')) {
    const bagSvg = window.q$.select('#bag-svg-mobile-nav').elem;
    const bagSvgFilled = window.q$.select('.bag-svg-mobile-nav-filled').elem;
    mobileNavBar.classList.remove('d-none');
    bagSvg.classList.add('hidden', 'mob-nav-label-active');
    bagSvgFilled.classList.remove('hidden');
  }
};

window.setHistory = (term) => {
  const prevHistory = getDataFromLocalStorageV2(getHistoryStoragekey());
  let newHistory;
  if (prevHistory.some((historyItem) => historyItem.term === term)) {
    newHistory = [
      { term },
      ...prevHistory.filter((historyItem) => historyItem.term !== term),
    ];
  } else {
    newHistory = [{ term }, ...prevHistory.slice(0, 3)];
  }
  setDataFromLocalStorage(getHistoryStoragekey(), newHistory);
  return newHistory;
};

window.clearRecentSearches = () => {
  localStorage.removeItem(getHistoryStoragekey());
  renderRecentSearches();
};

window.clearInputSearch = () => {
  document.querySelector('.search-input').value = '';
  document.querySelector('.search-meta').classList.remove('hidden');
  document.querySelector('.search-predictions').classList.add('hidden');
  document.querySelector('.prediction-section-heading').classList.add('hidden');
  document.querySelector('.cancel-btn').classList.add('hidden');
};

// Search

window.commonInitializer = () => {
  const desktopHeader = document.getElementById('desktop-header-nav-bar');
  const desktopActiveClass = 'header-item-selected';

  handleNavActiveClass(desktopHeader, desktopActiveClass);
  handleActiveNavStateMobile();
  GAPage();
  handleMenuStates();
  window.DukaanData.DUKAAN_THEME_MODE = 'dark';
};

window.debounce = (callback, timeout = 300) => {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => {
      callback.apply(this, args);
    }, timeout);
  };
};

// window.fillPrediction = () => {};

window.renderRecentSearches = () => {
  const recentSearchList = getDataFromLocalStorageV2(getHistoryStoragekey());
  if (recentSearchList.length > 0) {
    document
      .querySelectorAll('.recent-searches')
      .forEach((el) => el.classList.remove('hidden'));

    const recentSearchListElements = document.querySelectorAll(
      '.recent-searches-list'
    );
    recentSearchListElements.forEach((recentSearchListEl) => {
      recentSearchListEl.replaceChildren();

      const recentSearchItemTemplate = document.getElementById(
        'recent-searches-template'
      );

      recentSearchList.forEach((search) => {
        const resentSearchItemElement = document.importNode(
          recentSearchItemTemplate.content,
          true
        );
        resentSearchItemElement.querySelector(
          '.recent-search-item-text'
        ).textContent = search.term;
        resentSearchItemElement
          .querySelector('.recent-search-item')
          .setAttribute('onclick', `redirectToSearchPage('${search.term}')`);
        recentSearchListEl.appendChild(resentSearchItemElement);
      });
    });
  } else {
    document
      .querySelectorAll('.recent-searches')
      .forEach((el) => el.classList.add('hidden'));
  }
};

window.renderPredictions = (predictions) => {
  const searchPredictionsElement = document.querySelector(
    '.search-predictions'
  );
  const heading = document.querySelector('.prediction-section-heading');
  document.querySelector('.cancel-btn').classList.remove('hidden');
  searchPredictionsElement.innerHTML = '';
  searchPredictionsElement.classList.remove('hidden');
  heading.classList.remove('hidden');
  document.querySelector('.search-meta').classList.add('hidden');

  const searchPredictionsTemplate = document.getElementById(
    'search-prediction-item'
  );

  if (!predictions.length) {
    document
      .querySelector('.prediction-section-heading')
      .classList.add('hidden');
    searchPredictionsElement.innerHTML = `<p class="no-prediction">${DukaanData.DUKAAN_LANGUAGE.WE_FOUND_NO_SEARCH_RESULTS}!</p>`;
    return;
  }

  predictions.forEach((prediction) => {
    const categoryItemElement = document.importNode(
      searchPredictionsTemplate.content,
      true
    );
    categoryItemElement
      .querySelector('.search-prediction-item')
      .setAttribute(
        'href',
        `${DukaanData.DUKAAN_BASE_URL}/products/${prediction.slug}`
      );
    // categoryItemElement.querySelector('.fill-prediction').setAttribute('onclick', `fillPrediction(event, '${prediction.name}')`)
    categoryItemElement.querySelector('.prediction-label').textContent =
      prediction.name;

    categoryItemElement
      .querySelector('.prediction-image')
      .setAttribute('src', getCdnUrl(prediction.image, 100));

    searchPredictionsElement.appendChild(categoryItemElement);
  });
};

window.handleSearchRedirection = (event) => {
  window.location.href = dknGetSearchUrl(event.target.value);
};

window.removeOverflowFromBody = () => {
  document.querySelector('body').classList.remove('overflow-hidden');
};

window.renderCategoryList = (categories, nextUrl, isFirstFetch) => {
  const categoryListElement = document.querySelector('.category-list');
  const categoryItemTemplate = document.getElementById('category-list-item');

  if (!categories?.length && isFirstFetch) {
    categoryListElement.innerHTML = '';
    return;
  }

  if (isFirstFetch) {
    categoryListElement.innerHTML = '';
  }

  categories.forEach((category) => {
    const categoryItemElement = document.importNode(
      categoryItemTemplate.content,
      true
    );
    if (category?.parent_id !== null) {
      categoryItemElement
        .querySelector('a')
        .setAttribute(
          'href',
          `${window.DukaanData.DUKAAN_BASE_URL}/categories/${category.slug}?category_ids=${category.id}`
        );
    } else {
      categoryItemElement
        .querySelector('a')
        .setAttribute(
          'href',
          `${getCategoryCardLink(category, DukaanData?.DUKAAN_BASE_URL)}`
        );
    }
    categoryItemElement.querySelector('.category-name').textContent =
      category.name;
    categoryItemElement
      .querySelector('.category-image')
      .setAttribute('src', `${getCdnUrl(category.image, 500)}`);
    categoryListElement.appendChild(categoryItemElement);
  });

  const currentEventObserver = document.getElementById(
    'search-categories-list-observer'
  );

  if (nextUrl) {
    if (currentEventObserver) {
      currentEventObserver?.remove();
    }

    const newObserverElement = document.createElement('div');
    newObserverElement.setAttribute('id', 'search-categories-list-observer');
    categoryListElement.appendChild(newObserverElement);

    const observerElement = document.getElementById(
      'search-categories-list-observer'
    );

    const observer = new IntersectionObserver((entries) => {
      if (entries[0].isIntersecting) {
        fetchStoreCategoriesSearchDrawer({ nextUrl, cb: renderCategoryList });
      }
    });
    observer.observe(observerElement);
  } else {
    currentEventObserver?.remove();
  }
};

window.closeSearchDrawer = () => {
  const modal = document.getElementById('search-drawer');
  modal.classList.add('hidden');
  document.body.style.overflow = 'initial';
};

window.fetchStoreCategoriesSearchDrawer = null;

window.openSearchDrawer = () => {
  const modal = document.getElementById('search-drawer');
  modal.classList.remove('hidden');
  modal.querySelector('.search-input').focus();
  document.body.style.overflow = 'hidden';
  renderRecentSearches();
  fetchStoreCategoriesSearchDrawer = fetchStoreCategories();
  fetchStoreCategoriesSearchDrawer({
    cb: renderCategoryList,
    firstFetch: true,
  });
};

window.handleInputChange = (event) => {
  const query = event.target.value;
  if (query.length === 0) {
    document
      .querySelectorAll('.search-meta')
      .forEach((el) => el.classList.remove('hidden'));
    document
      .querySelectorAll('.prediction-section-heading')
      .forEach((el) => el.classList.add('hidden'));
    document
      .querySelectorAll('.search-predictions')
      .forEach((el) => el.classList.add('hidden'));
    document.querySelector('.cancel-btn').classList.add('hidden');
    renderRecentSearches();
  }
  if (query.length < 2) return;
  // setHistory(query);
  fetch(
    `${window.DukaanData.DUKAAN_ADVANCED_SEARCH_API_BASE_URL}/api/advanced-search/${window.DukaanData.DUKAAN_STORE.id}/`,
    {
      method: 'post',
      body: JSON.stringify({ query, page_size: 15 }),
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
      },
    }
  )
    .then((res) => res.json())
    .then((res) => {
      const predictions = res?.data?.products || [];
      renderPredictions(predictions);
    })
    .catch(() => {});
};
window.additionalCategoryProductCardChanges = (
  categoryProductCard,
  product
) => {
  const productPriceContainer =
    categoryProductCard.querySelector('.price-information');
  if (product.in_stock) {
    productPriceContainer.style.display = 'block';
  } else {
    productPriceContainer.style.display = 'none';
  }
};

window.splideSlideIndex = (allImages, primaryImage) => {
  const index = allImages?.indexOf(primaryImage);
  window?.splideSlider?.go(index);
};

window.handleModalChanges = (product, currentSKU) => {
  const element = document.querySelector('.product-variant-selection-modal');
  if (!element) return;

  if (element.querySelector('.product-modal-badge .bxgy-badge')) {
    handleProductCardChange(element, product);
  }
  if (element !== null) {
    if (element.querySelector('.product-name')) {
      element.querySelector('.product-name').textContent = `${product.name}`;
    }

    if (element.querySelector('.stock-left-message')) {
      if (currentSKU.inventory <= 10 && !!currentSKU.inventory) {
        element.querySelector('.stock-left-message').classList.remove('hidden');
        element.querySelector('.stock-left-message').textContent =
          `${DukaanData.DUKAAN_LANGUAGE.ONLY__INVENTORY_LEFT_IN_STOCK_HURRY_UP}!`.injectText(
            {
              inventory: currentSKU.inventory,
            }
          );
      } else {
        element.querySelector('.stock-left-message').classList.add('hidden');
        element.querySelector('.stock-left-message').textContent = ``;
      }
    }

    const originalPrice = currentSKU?.original_price;
    const sellingPrice = currentSKU?.selling_price;

    if (element.querySelector('.product-selling-price')) {
      element.querySelector('.product-selling-price').textContent =
        formatMoney(sellingPrice);
    }

    if (
      (((originalPrice - sellingPrice) / originalPrice) * 100).toFixed(0) > 0
    ) {
      if (element.querySelector('.product-original-price')) {
        element.querySelector('.product-original-price').textContent =
          formatMoney(originalPrice);
      }

      if (element.querySelector('.product-discount-badge')) {
        element.querySelector(
          '.product-discount-badge'
        ).textContent = `(${calculateDiscount(
          originalPrice,
          sellingPrice
        )}% off)`;
      }
      element
        .querySelector('.product-original-price')
        .classList.remove('hidden');
      element
        .querySelector('.product-discount-badge')
        .classList.remove('hidden');
    } else {
      element.querySelector('.product-original-price').classList.add('hidden');
      element.querySelector('.product-discount-badge').classList.add('hidden');
    }

    // renders product modal carousel with splide if exist.
    const productSplideTemplate = document.querySelector(
      '#product-modal-splide-container'
    );

    if (productSplideTemplate) {
      const productSplideList = element.querySelector('.splide__list');

      if (typeof splideSlider === 'undefined') {
        if (product.all_images?.length > 1) {
          productSplideList.replaceChildren();
          // eslint-disable-next-line no-restricted-syntax
          for (const image of product?.all_images || []) {
            const productSplide = document.importNode(
              productSplideTemplate.content,
              true
            );
            productSplide
              .querySelector('.product-modal-splide-image')
              .setAttribute(
                'src',
                `${getCdnUrl(image || currentSKU.primary_image, 700)}`
              );
            productSplideList.appendChild(productSplide);
          }

          window.splideSlider = new Splide('#splide-product-modal-images', {
            type: 'loop',
            autoplay: false,
            arrows: true,
            pauseOnHover: false,
            pagination: false,
            interval: 1000,
            classes: {
              arrows: 'splide__arrows',
            },
          }).mount();
        } else if (element.querySelector('.product-images')) {
          element.querySelector('.product-images').replaceChildren();
          const wrapper = element.querySelector('.product-images');
          wrapper.classList.add('fB', 'a-c', 'j-c');
          const imgElem = document.createElement('img');
          imgElem.setAttribute('class', 'product-image w-100');
          element.querySelector('.product-images').appendChild(imgElem);
          element
            .querySelector('.product-image')
            .setAttribute(
              'src',
              `${getCdnUrl(product.image || currentSKU.primary_image, 700)}`
            );
        }
      }
      if (!currentSKU?.primary_image.includes('category-def.jpg')) {
        const allImages = product?.all_images || product?.image;
        if (typeof splideSlideIndex !== 'undefined')
          splideSlideIndex(allImages, currentSKU.primary_image);
      }
    }

    if (currentSKU.meta.size) {
      const sizeListHeadingLabel = element.querySelector(
        '.size-selection-heading'
      );
      if (sizeListHeadingLabel) {
        if (currentSKU.meta.size.attributeLabel) {
          sizeListHeadingLabel.innerHTML =
            DukaanData.DUKAAN_LANGUAGE.SELECT__ATTRIBUTE.injectText({
              attribute: currentSKU.meta.size.attributeLabel,
            });
          // `Select ${currentSKU.meta.size.attributeLabel}`;
        } else {
          sizeListHeadingLabel.innerHTML =
            DukaanData.DUKAAN_LANGUAGE.SELECT_SIZE;
        }
      }
    }

    if (currentSKU.meta.color) {
      const colorListHeadingLabel = element.querySelector(
        '.color-selection-heading'
      );
      if (colorListHeadingLabel) {
        if (currentSKU.meta.color.attributeLabel) {
          colorListHeadingLabel.innerHTML =
            DukaanData.DUKAAN_LANGUAGE.SELECT__ATTRIBUTE.injectText({
              attribute: currentSKU.meta.color.attributeLabel,
            });
          // `Select ${currentSKU.meta.color.attributeLabel}`;
        } else {
          colorListHeadingLabel.innerHTML =
            DukaanData.DUKAAN_LANGUAGE.SELECT_COLOR;
        }
      }
    }
  }
};

window.handleVariantChange = (productUUID, options) => {
  if (!productUUID) return;
  const { mountElem, buttonTemplateId } = options;
  const element =
    document.querySelector(mountElem) ||
    document.querySelector('product-variant-selection-modal');

  const addToBagElement = element.querySelector('add-to-bag-button');
  const buyNowElement = element.querySelector('buy-now-button-load-point');
  const formData = new FormData(
    element.querySelector('form#variant-selection')
  );
  const data = [...formData.entries()].reduce((acc, [key, value]) => {
    acc[key] = value;
    return acc;
  }, {});

  const product = DukaanData.PRODUCTS_MAP[productUUID];
  const { skus } = product;
  const currentSKU = skus.find(
    (sku) =>
      (!data.size || sku.meta.size.value === data.size) &&
      (!data.color || sku.meta.color.value === data.color)
  );

  if (!currentSKU) return;

  if (addToBagElement) {
    addToBagElement.dataset.productUuid = productUUID;
    addToBagElement.dataset.skuUuid = currentSKU.uuid;
    addToBagButtonRenderer(addToBagElement);
  }

  if (buyNowElement) {
    buyNowElement.dataset.productUuid = productUUID;
    buyNowElement.dataset.skuUuid = currentSKU.uuid;
    buyNowButtonRenderer(buyNowElement);
  }

  if (buttonTemplateId) {
    const additionalButtonElement = document.querySelector(buttonTemplateId);
    additionalButtonElement.dataset.productUuid = productUUID;
    additionalButtonElement.dataset.skuUuid = currentSKU.uuid;

    if (
      buttonTemplateId === `[data-template-id="modal-wishlist-button-template"]`
    ) {
      if (typeof addToWishlistButtonRenderer !== 'undefined') {
        addToWishlistButtonRenderer(additionalButtonElement);
      }
    }
  }

  handleModalChanges(product, currentSKU);
};

window.redirectToSearchPage = (value) => {
  value = value.trim();
  if (Boolean(value) && value.length > 0) {
    setHistory(value);
    window.location.href = dknGetSearchUrl(value);
  }
};

window.APP_IDS = {
  ...(window.APP_IDS || {}),
  STORE_LOCATOR: '6286104b4f1ca25e2256f6b7',
};

window.getCustomDiscountText = (discount) => `(${discount}% OFF)`;

window.productCardAdditionalRenderer = (productCard, product) => {
  productCardImageCarouselRenderer(product, productCard);
};
window.redirectToSearchPageOnSubmit = (e) => {
  e.preventDefault();
  const formData = new FormData(document.querySelector('form#search-form'));
  const value = formData.get('search');
  redirectToSearchPage(value);
};

window.onInputChange = debounce((event) => handleInputChange(event), 300);

window.addEventListener('DOMContentLoaded', () => {
  axios
    .get(
      `https://apps.mydukaan.io/public/v2/apps/store/${DukaanData.DUKAAN_STORE.id}/`
    )
    .then((response) => {
      const { store_apps_list: appList } = response.data;
      const availablePlugins = appList?.reduce((acc, item) => {
        if (item.isActive) {
          // eslint-disable-next-line no-underscore-dangle
          acc[item._id] = item;
        }
        return acc;
      }, {});
      const isStoreLocatorPresent = Boolean(
        !!availablePlugins && availablePlugins[APP_IDS.STORE_LOCATOR]
      );
      const storeLocatorTags = document.querySelectorAll(
        '.dkn-store-locator-link'
      );
      if (isStoreLocatorPresent) {
        storeLocatorTags.forEach((tag) => tag.classList.remove('hidden'));
      } else {
        storeLocatorTags.forEach((tag) => tag.remove());
      }
    })
    .finally(() => {
      const menuItems = document.querySelectorAll('.header-section-nav-item');
      const mainMenu = document.querySelector('.header-section-menu-list');
      const mainMenuWidth = mainMenu.offsetWidth;
      let menuWidth = 0;
      let i = 0;
      for (i = 0; i < menuItems.length; i += 1) {
        menuWidth += menuItems[i].offsetWidth + 24;
        if (
          menuWidth >=
          mainMenuWidth -
            document.querySelector('.header-section-nav-item-hamburger')
              .offsetWidth
        ) {
          document.fonts.ready.then(() => {
            document
              .querySelector('.header-section-nav-item-hamburger')
              .classList.remove('hidden');
          });
          break;
        }
      }
    })
    .catch(() => {});
});

window.handleMenuStates = () => {
  const menuItems = document.querySelectorAll(
    '.header-section-nav-item:not(.header-section-nav-item-hamburger)'
  );

  let i = 0;
  for (i = 0; i < menuItems.length; i += 1) {
    menuItems[i].addEventListener('mouseenter', (event) => {
      document.querySelectorAll('.header-menu-item-dropdown')?.forEach((el) => {
        el?.classList.add('hidden');
      });
      const { target: parentMenuItem } = event;
      const menuId = parentMenuItem.dataset.menuId || '';
      const menuDropDown = document.getElementById(menuId);
      if (menuDropDown) {
        menuDropDown.classList.remove('hidden');
        menuDropDown.style.position = 'absolute';
        menuDropDown.style.top = `calc(100% - 8px)`;
        menuDropDown.style.left = `${
          parentMenuItem.getBoundingClientRect().left
        }px`;
      }
      document.addEventListener('mousemove', (e) => {
        const { target: hoverTarget } = e;
        const mainHeader = document.querySelector('.header-section-menu-list');
        if (
          !(
            menuDropDown?.contains(hoverTarget) ||
            mainHeader?.contains(hoverTarget)
          )
        ) {
          menuDropDown?.classList?.add('hidden');
          document.removeEventListener('mousemove', () => {}, true);
        }
      });
    });
  }
};

window.closeMobileModal = () => {
  const modal = window.Offcanvas.getOrCreateInstance(
    window.q$.selectById('offcanvasLeftMenu').elem
  );
  modal.toggle();
};

const formSearch = document.querySelector('#search-form');
window.changeSVGcolor = () => {
  formSearch.addEventListener('mousedown', (e) => {
    if (!(e.target.value > 0)) {
      document
        .querySelector('.searchCircle')
        .setAttribute('fill', 'var( --black-12)');
      document
        .querySelector('.searchline')
        .setAttribute('fill', 'var( --black-12)');
    }
  });
};
changeSVGcolor();

window.getCustomTotalWishlistCountText = (totalWishlistCount) =>
  `${
    window.DukaanData.DUKAAN_LANGUAGE.MY_WISHLIST || 'My wishlist'
  } <span>(${totalWishlistCount})</span>`;
