const VUSTORE_VIBE_TV_43_IMAGES = [
  'https://dms.mydukaan.io/original/webp/media/0fdef1ef-f34d-45bd-8925-876ea193cdab.png',
  'https://dms.mydukaan.io/original/webp/media/feee9092-fe8c-4550-838f-2398a928ef4f.png',
  'https://dms.mydukaan.io/original/webp/media/e8a17b85-1100-4723-8aaa-7945a66485d6.png',
  'https://dms.mydukaan.io/original/webp/media/616e3d50-ee36-4250-bc82-7ea8b20c90c6.png',
  'https://dms.mydukaan.io/original/webp/media/b721f0af-b6b4-4bb3-b43e-fce4fbd6cad1.png',
  'https://dms.mydukaan.io/original/webp/media/8b632c10-dc76-4d9f-a4d9-dd4b5c366468.png',
  'https://dms.mydukaan.io/original/webp/media/da356f80-797d-4f45-a462-e6aac129dc59.png',
  'https://dms.mydukaan.io/original/webp/media/10cdb953-9bdd-4cd0-879d-2bcd0e2b01a1.png',
  'https://dms.mydukaan.io/original/webp/media/0d6f82a4-cd3d-4532-beae-da452a801ec7.png',
  'https://dms.mydukaan.io/original/webp/media/47ddeb7d-1b09-43a2-a769-818ba072b5b7.png',
  'https://dms.mydukaan.io/original/webp/media/296aed22-ae36-4347-af6f-7247a8487d0d.png',
  'https://dms.mydukaan.io/original/webp/media/56228ca9-d7fc-423c-8f40-a37f8a93bacf.png',
  'https://dms.mydukaan.io/original/webp/media/857169f0-54c9-46e1-a64e-1bb6cd4ef2d0.png',
  'https://dms.mydukaan.io/original/webp/media/15e4c9c0-377c-492f-bea9-5050b42147ba.png',
  'https://dms.mydukaan.io/original/webp/media/ccd474cc-de57-4fd1-a346-840503c733f1.png',
  'https://dms.mydukaan.io/original/webp/media/b156e9c2-a9cc-46b8-b676-8fb13cc024d7.png',
  'https://dms.mydukaan.io/original/webp/media/7e93d1e8-ce66-456f-98ff-cd7c260266f7.png',
  'https://dms.mydukaan.io/original/webp/media/5087a41d-70d5-4a5b-82d5-2d5104b3e1b5.png',
  'https://dms.mydukaan.io/original/webp/media/dee6d58e-0e42-4c61-9ed7-6f4ad85ab355.png',
  'https://dms.mydukaan.io/original/webp/media/dbfbc6bd-a499-4002-91a6-cb0dc66824ad.png',
  'https://dms.mydukaan.io/original/webp/media/dbefe151-5a48-40a7-9a1b-d0455d6752e6.png',
  'https://dms.mydukaan.io/original/webp/media/749fd505-7a87-419a-b82b-5d1575fb0236.png',
  'https://dms.mydukaan.io/original/webp/media/cfb0708b-95a1-49c1-a8ca-494253a659ca.png',
  'https://dms.mydukaan.io/original/webp/media/4c1de481-7fb5-4c82-87b6-686f3d61c945.png',
  'https://dms.mydukaan.io/original/webp/media/d69f79d2-210e-4eb5-9833-dc847e4ada47.png',
  'https://dms.mydukaan.io/original/webp/media/da77be70-ebb8-4b6f-82c6-df19bb048c04.png',
  'https://dms.mydukaan.io/original/webp/media/5ef90d58-33ca-4afa-8f6c-d7c5b01326b8.png',
  'https://dms.mydukaan.io/original/webp/media/96a73b8c-763d-4f17-a0f1-d0c6531ae7e6.png',
  'https://dms.mydukaan.io/original/webp/media/0de2640e-883e-421f-9dbe-04f3980f7809.png',
  'https://dms.mydukaan.io/original/webp/media/081e7168-5aea-43cc-a154-a6d274c431b2.png',
  'https://dms.mydukaan.io/original/webp/media/80739f09-2f07-4fd2-953b-847429b23851.png',
  'https://dms.mydukaan.io/original/webp/media/d21d9618-f743-43ea-9825-96e1e73b3993.png',
  'https://dms.mydukaan.io/original/webp/media/4aadb2bd-0c01-4706-ba13-fe45caa12d09.png',
  'https://dms.mydukaan.io/original/webp/media/c8fa43fb-3c52-4f06-ab18-4e840484b91d.png',
  'https://dms.mydukaan.io/original/webp/media/a8d2a628-43ed-4dd9-9490-9fba84170887.png',
  'https://dms.mydukaan.io/original/webp/media/6a741c77-5622-48a4-8cb2-1ad41fdba385.png',
  'https://dms.mydukaan.io/original/webp/media/ac24fa2a-e10c-4181-a799-ab181fc97690.png',
  'https://dms.mydukaan.io/original/webp/media/d177dbe7-e1f1-4669-92cf-54ac51e11146.png',
  'https://dms.mydukaan.io/original/webp/media/f97ab6d1-850c-4700-b1a4-80c8365d6152.png',
  'https://dms.mydukaan.io/original/webp/media/8d2e743c-7d35-459b-9e96-b24c759035e1.png',
  'https://dms.mydukaan.io/original/webp/media/e91ce346-b252-40b1-a9a2-fe9d8be82dd2.png',
  'https://dms.mydukaan.io/original/webp/media/28ad45d6-5525-43a8-8da3-2f993d239d2d.png',
  'https://dms.mydukaan.io/original/webp/media/0382ef92-9c0d-4c05-971e-d23a338eeed1.png',
  'https://dms.mydukaan.io/original/webp/media/9da60642-2b77-40c4-b5d0-4896b77142be.png',
  'https://dms.mydukaan.io/original/webp/media/9617d8cc-9e28-4b09-b457-222bb2bd7032.png',
  'https://dms.mydukaan.io/original/webp/media/12b518e4-5192-42a2-b4b6-281b15579bb2.png',
  'https://dms.mydukaan.io/original/webp/media/fb81ec57-0a42-4938-a46d-6ed59594d3d5.png',
  'https://dms.mydukaan.io/original/webp/media/8d7479dc-2c6d-4280-94dd-750d515fbee3.png',
  'https://dms.mydukaan.io/original/webp/media/6b1824bd-5220-42b3-81f5-1a5228879433.png',
  'https://dms.mydukaan.io/original/webp/media/51e8b327-6ab3-4a8a-87fe-cebbeef1c5bf.png',
  'https://dms.mydukaan.io/original/webp/media/541153c2-f119-444e-a5c6-12ff4e099e55.png',
  'https://dms.mydukaan.io/original/webp/media/4810d985-1353-4e76-9b08-c92d86d799fb.png',
  'https://dms.mydukaan.io/original/webp/media/7be1d85a-33a2-4a2c-963d-6d9abd7f9427.png',
  'https://dms.mydukaan.io/original/webp/media/916f841b-781f-40fd-9854-10bf4b641def.png',
  'https://dms.mydukaan.io/original/webp/media/9f7b78bc-11f2-4804-9e1c-c15bd2b72218.png',
  'https://dms.mydukaan.io/original/webp/media/85724510-debc-4087-aaa1-0acbe1fb39ae.png',
  'https://dms.mydukaan.io/original/webp/media/64548884-2994-46b1-ae6e-c962f5b70564.png',
  'https://dms.mydukaan.io/original/webp/media/feb5e38c-070a-42f4-ba23-cf7a6dfb4335.png',
  'https://dms.mydukaan.io/original/webp/media/1e88d340-f327-4001-bad6-7d301437dc78.png',
  'https://dms.mydukaan.io/original/webp/media/e2511dca-2128-4d6e-b814-2e108eba039b.png',
  'https://dms.mydukaan.io/original/webp/media/68ab383a-20e0-4bf5-be91-2a4a52753ddd.png',
  'https://dms.mydukaan.io/original/webp/media/4485b5bc-98ca-4f8a-a147-25b9406da085.png',
  'https://dms.mydukaan.io/original/webp/media/573607e7-bcf9-4ad7-843f-e71477dfc56f.png',
  'https://dms.mydukaan.io/original/webp/media/70db368c-7cdb-4c31-a5b6-75c52cdc2b16.png',
  'https://dms.mydukaan.io/original/webp/media/a2a3b8a3-7626-428d-86fa-9ec96f69e5c3.png',
  'https://dms.mydukaan.io/original/webp/media/2453a704-d279-4dd7-bc7c-82ffdcdda0e1.png',
  'https://dms.mydukaan.io/original/webp/media/f3e26dae-b90f-427a-9e8f-91589605486c.png',
  'https://dms.mydukaan.io/original/webp/media/9f3bf41e-8740-4454-b94e-dc06d56f3076.png',
  'https://dms.mydukaan.io/original/webp/media/237c1617-860e-4eb1-8fa3-060b83a44466.png',
  'https://dms.mydukaan.io/original/webp/media/f3e5b2eb-a939-44ad-ad5a-d8bb5be98ca6.png',
  'https://dms.mydukaan.io/original/webp/media/afaed0f6-50d0-4566-a11b-23dff9caef70.png',
  'https://dms.mydukaan.io/original/webp/media/ba38d794-4b7e-4465-929c-bc6e91283ff6.png',
];

const VUSTORE_VIBE_TV_65_IMAGES = [
  'https://dms.mydukaan.io/original/webp/media/2b774c55-93f2-4e69-b531-0cbd0a33628b.png',
  'https://dms.mydukaan.io/original/webp/media/825b8a8a-9150-4246-97b3-60de5bc948fb.png',
  'https://dms.mydukaan.io/original/webp/media/7a66afb6-ba7e-4b26-b96e-d96f4312d8ed.png',
  'https://dms.mydukaan.io/original/webp/media/8f0e1739-f34d-4a64-9d3e-e5e4a11bddec.png',
  'https://dms.mydukaan.io/original/webp/media/88a6291d-4734-4569-b28f-adc58dbdfcf3.png',
  'https://dms.mydukaan.io/original/webp/media/1498254a-bb84-4f96-9898-1d879db16c60.png',
  'https://dms.mydukaan.io/original/webp/media/e6c29975-825c-4c73-ac97-681b59a11604.png',
  'https://dms.mydukaan.io/original/webp/media/922e82c1-cef9-467d-a88e-dd4cbceb973e.png',
  'https://dms.mydukaan.io/original/webp/media/cf9a1556-3af2-4705-b837-f71d8d37716b.png',
  'https://dms.mydukaan.io/original/webp/media/a368b34d-c7a4-43b9-a6af-fe745c329d20.png',
  'https://dms.mydukaan.io/original/webp/media/f9429ff4-f872-4a66-90d9-dc0820d6b209.png',
  'https://dms.mydukaan.io/original/webp/media/1a21aa25-1050-4142-9d8c-dc127e6b23fc.png',
  'https://dms.mydukaan.io/original/webp/media/4b115753-a50e-44af-b485-a8a50d27ac2f.png',
  'https://dms.mydukaan.io/original/webp/media/3609cf41-6967-4d04-addd-b2212f5b5766.png',
  'https://dms.mydukaan.io/original/webp/media/c60955e9-c564-4d44-9321-f67981cce694.png',
  'https://dms.mydukaan.io/original/webp/media/5797fb8d-073d-4617-a245-5c82f0e42711.png',
  'https://dms.mydukaan.io/original/webp/media/cffd4146-bdf1-43d5-9191-b1e8bd8d35c8.png',
  'https://dms.mydukaan.io/original/webp/media/43f43041-3593-4425-a25a-c3c94cce7222.png',
  'https://dms.mydukaan.io/original/webp/media/e0d834c4-4905-473f-9fc1-8fb5320671c8.png',
  'https://dms.mydukaan.io/original/webp/media/34d75dab-ce9c-4d23-896d-780285ed9d75.png',
  'https://dms.mydukaan.io/original/webp/media/fabd37e8-41c3-413e-8efc-25d749a461a2.png',
  'https://dms.mydukaan.io/original/webp/media/f0a50b38-bb0d-4773-820f-b400633b7977.png',
  'https://dms.mydukaan.io/original/webp/media/9e759ff4-60ef-4af2-92ae-82d04b4171b5.png',
  'https://dms.mydukaan.io/original/webp/media/629a7ad7-1e5b-4ccf-bbed-6b73299f8ac9.png',
  'https://dms.mydukaan.io/original/webp/media/a5769797-8e53-4225-b3c7-330aee4af3ac.png',
  'https://dms.mydukaan.io/original/webp/media/48a32afe-33b7-4de6-b486-4cdfb9e10be1.png',
  'https://dms.mydukaan.io/original/webp/media/a5727c8b-1e11-4eee-85a2-bac786bac087.png',
  'https://dms.mydukaan.io/original/webp/media/bae35539-3662-4718-8b2a-f8af7eee43d2.png',
  'https://dms.mydukaan.io/original/webp/media/3d4343cc-eee8-4dfb-a209-c78b35b2e66f.png',
  'https://dms.mydukaan.io/original/webp/media/a970ac1f-f9c8-43c9-b974-4228eeede227.png',
  'https://dms.mydukaan.io/original/webp/media/14b5ad52-874d-4fc3-8ef7-5c08068a421c.png',
  'https://dms.mydukaan.io/original/webp/media/101aa8f7-c7cb-4c70-845a-d664320db874.png',
  'https://dms.mydukaan.io/original/webp/media/c8c875ad-ff32-433d-b71e-15c62efe3c1e.png',
  'https://dms.mydukaan.io/original/webp/media/5c31ac6d-9df6-4f32-9d44-eb2c929aca26.png',
  'https://dms.mydukaan.io/original/webp/media/8c34f9de-735c-4940-ab47-04c330bd8ab0.png',
  'https://dms.mydukaan.io/original/webp/media/67a1df64-5aa2-466c-8252-f5ad0e1b37d6.png',
  'https://dms.mydukaan.io/original/webp/media/95ea553a-ae31-43ea-8a41-8a93410d4a4f.png',
  'https://dms.mydukaan.io/original/webp/media/36373202-11d0-4681-8b9d-b895b74f8b1c.png',
  'https://dms.mydukaan.io/original/webp/media/a1dc2f71-8d8e-42c4-be24-6c13fb5c41e3.png',
  'https://dms.mydukaan.io/original/webp/media/13110c76-287e-444a-8a8a-b5980034f3c4.png',
  'https://dms.mydukaan.io/original/webp/media/1408a82f-f436-4eac-83ff-f4901da6dfb3.png',
  'https://dms.mydukaan.io/original/webp/media/f9a0fbdd-a7e4-49e5-a88e-d77d88262740.png',
  'https://dms.mydukaan.io/original/webp/media/928b3528-cb75-4b02-802d-23763dff374a.png',
  'https://dms.mydukaan.io/original/webp/media/7082928f-e09c-4fb2-bd34-54d1257a1782.png',
  'https://dms.mydukaan.io/original/webp/media/fd22d72f-02d2-42f1-9df5-ea7efbaba599.png',
  'https://dms.mydukaan.io/original/webp/media/904ccd28-702c-4a81-b73c-ea8793ab81d6.png',
  'https://dms.mydukaan.io/original/webp/media/0a9e71e4-003c-407a-a5f8-ff7759dae57e.png',
  'https://dms.mydukaan.io/original/webp/media/904bc691-f2a0-4a01-ac45-1ed296a80cf3.png',
  'https://dms.mydukaan.io/original/webp/media/5b367414-f8e1-4bc4-87fc-9267f996eb5d.png',
  'https://dms.mydukaan.io/original/webp/media/3332cb4e-9134-45a1-a1e1-bfd259f1babf.png',
  'https://dms.mydukaan.io/original/webp/media/474aa5fa-8afa-46e0-9ad2-616f4972691a.png',
  'https://dms.mydukaan.io/original/webp/media/109caa86-94bb-42b8-9f78-6b1dbcdf148f.png',
  'https://dms.mydukaan.io/original/webp/media/2e450f07-5408-4ba2-b2d6-79cbbe58ca18.png',
  'https://dms.mydukaan.io/original/webp/media/732803e4-ffd5-41a3-8f79-b12c0685e42b.png',
  'https://dms.mydukaan.io/original/webp/media/0095c61a-1644-4d97-b8fd-81b45a313525.png',
  'https://dms.mydukaan.io/original/webp/media/62e7d39e-75bc-4702-aaa8-909a2eae7df3.png',
  'https://dms.mydukaan.io/original/webp/media/b623dcbc-6d24-479a-82e0-1ccda89174bd.png',
  'https://dms.mydukaan.io/original/webp/media/fb7c6f75-d268-41ea-aa32-3176abe10a09.png',
  'https://dms.mydukaan.io/original/webp/media/2b2a7b7a-cbce-49d0-bc79-5af58545f4cc.png',
  'https://dms.mydukaan.io/original/webp/media/5a3ceff1-8411-4943-beda-137c023fdacd.png',
  'https://dms.mydukaan.io/original/webp/media/c0aa1d92-f125-4913-9684-d83fab6826ae.png',
  'https://dms.mydukaan.io/original/webp/media/70184f07-f7d9-42bf-9bbb-da9fece6f35a.png',
  'https://dms.mydukaan.io/original/webp/media/90028dca-dfc0-48e3-89a5-51d7f24e337b.png',
  'https://dms.mydukaan.io/original/webp/media/0735c261-94d1-427b-8ea0-5df3909527cb.png',
  'https://dms.mydukaan.io/original/webp/media/d3f51bf7-3545-49da-a756-b29ed3c28114.png',
  'https://dms.mydukaan.io/original/webp/media/d480a10c-9a96-4f27-85df-c69c72fe91ab.png',
  'https://dms.mydukaan.io/original/webp/media/d6e888a4-0c70-400a-b78f-8364ac715ff3.png',
  'https://dms.mydukaan.io/original/webp/media/51a9a317-a1f5-477c-bdc9-2d80659ed352.png',
  'https://dms.mydukaan.io/original/webp/media/8acd4497-f5bc-4636-a90e-3283e83e9cf4.png',
  'https://dms.mydukaan.io/original/webp/media/8c0e8a79-80cc-4db3-899c-4b759311e277.png',
  'https://dms.mydukaan.io/original/webp/media/6c909c07-e0f0-4081-93e7-8c48b70762bf.png',
  'https://dms.mydukaan.io/original/webp/media/fa5c217b-0f93-4031-89c2-86c933bd399b.png',
];

window.PRODUCT_SLUGS = {
  VUSTORE_GLO_LED_TV_43: 'vu-glo-led-tv',
  VUSTORE_GLO_LED_TV_50: 'vu-glo-led-tv-50',
  VUSTORE_GLO_LED_TV_55: 'vu-glo-led-tv-55',
  VUSTORE_GLO_LED_TV_65: 'vu-glo-led-tv-65',
  VUSTORE_MASTERPIECE_TV_55: 'vu-masterpiece-tv',
  VUSTORE_MASTERPIECE_TV_65: 'vu-masterpiece-tv-65',
  VUSTORE_MASTERPIECE_TV_75: 'vu-masterpiece-tv-75',
  VUSTORE_PREMIUM_GOOGLE_OS_TV_43: 'vu-premium-4k-tv',
  VUSTORE_PREMIUM_GOOGLE_OS_TV_55: 'vu-premium-google-os-4k-tv-55',
  VUSTORE_PREMIUM_FHD_TV_43: 'vu-premium-fhd-tv',
  VUSTORE_MASTERPIECE_QLED_TV_85: 'vu-masterpiece-qled-tv-85',
  VUSTORE_MASTERPIECE_QLED_TV_98: 'vu-masterpiece-qled-tv-98',
  VUSTORE_CINEMA_2024_43: 'vu-cinema-tv-43-2024',
  VUSTORE_CINEMA_2024_55: 'vu-cinema-tv-55-2024',
  VUSTORE_VIBE_TV_43: 'vu-vibe-tv-43',
  VUSTORE_VIBE_TV_50: 'vu-vibe-tv-50',
  VUSTORE_VIBE_TV_55: 'vu-vibe-tv-55',
  VUSTORE_VIBE_TV_65: 'vu-vibe-tv-65',
};

window.COMING_SOON_PRODUCTS = [
  PRODUCT_SLUGS.VUSTORE_PREMIUM_GOOGLE_OS_TV_55,
  // PRODUCT_SLUGS.VUSTORE_GLO_LED_TV_55,
  // PRODUCT_SLUGS.VUSTORE_GLO_LED_TV_65,
];
window.DIWALI_LAUNCH_PRODUCTS = [
  // PRODUCT_SLUGS.VUSTORE_GLO_LED_TV_43
];
window.VIEW_ONLY_PRODUCTS = [
  // PRODUCT_SLUGS.VUSTORE_GLO_LED_TV_43,
  // PRODUCT_SLUGS.VUSTORE_GLO_LED_TV_50,
  // PRODUCT_SLUGS.VUSTORE_GLO_LED_TV_55,
  // PRODUCT_SLUGS.VUSTORE_GLO_LED_TV_65,
  PRODUCT_SLUGS.VUSTORE_PREMIUM_GOOGLE_OS_TV_55,
];

window.RESOLUTION_MAP = {
  [PRODUCT_SLUGS.VUSTORE_GLO_LED_TV_43]: '4K 3840 x 2160 Pixels',
  [PRODUCT_SLUGS.VUSTORE_GLO_LED_TV_50]: '4K 3840 x 2160 Pixels',
  [PRODUCT_SLUGS.VUSTORE_GLO_LED_TV_55]: '4K 3840 x 2160 Pixels',
  [PRODUCT_SLUGS.VUSTORE_GLO_LED_TV_65]: '4K 3840 x 2160 Pixels',
  [PRODUCT_SLUGS.VUSTORE_MASTERPIECE_TV_55]: '4K 3824 x 2160 Pixels',
  [PRODUCT_SLUGS.VUSTORE_MASTERPIECE_TV_65]: '4K 3824 x 2160 Pixels',
  [PRODUCT_SLUGS.VUSTORE_MASTERPIECE_TV_75]: '4K 3824 x 2160 Pixels',
  [PRODUCT_SLUGS.VUSTORE_PREMIUM_GOOGLE_OS_TV_43]: '4K 3824 x 2160 Pixels',
  [PRODUCT_SLUGS.VUSTORE_PREMIUM_GOOGLE_OS_TV_55]: '4K 3824 x 2160 Pixels',
  [PRODUCT_SLUGS.VUSTORE_MASTERPIECE_QLED_TV_85]: '4K 3824 x 2160 Pixels',
  [PRODUCT_SLUGS.VUSTORE_MASTERPIECE_QLED_TV_98]: '4K 3824 x 2160 Pixels',
  [PRODUCT_SLUGS.VUSTORE_CINEMA_2024_43]: '4K 3824 x 2160 Pixels',
  [PRODUCT_SLUGS.VUSTORE_CINEMA_2024_55]: '4K 3824 x 2160 Pixels',
  [PRODUCT_SLUGS.VUSTORE_PREMIUM_FHD_TV_43]: 'Full HD 1920 x 1080 Pixels',
};

window.OS_MAP = {
  [PRODUCT_SLUGS.VUSTORE_GLO_LED_TV_43]: 'Google TV OS',
  [PRODUCT_SLUGS.VUSTORE_GLO_LED_TV_50]: 'Google TV OS',
  [PRODUCT_SLUGS.VUSTORE_GLO_LED_TV_55]: 'Google TV OS',
  [PRODUCT_SLUGS.VUSTORE_GLO_LED_TV_65]: 'Google TV OS',
  [PRODUCT_SLUGS.VUSTORE_CINEMA_2024_43]: 'webOS',
  [PRODUCT_SLUGS.VUSTORE_CINEMA_2024_55]: 'webOS',
  //   [PRODUCT_SLUGS.PREMIUM_WEBOS_4K_TV_43]: 'webOS',
  //   [PRODUCT_SLUGS.PREMIUM_WEBOS_4K_TV_55]: 'webOS',
  [PRODUCT_SLUGS.VUSTORE_PREMIUM_FHD_TV_43]: 'Official Android',
  [PRODUCT_SLUGS.VUSTORE_PREMIUM_GOOGLE_OS_TV_43]: 'Google OS',
  [PRODUCT_SLUGS.VUSTORE_PREMIUM_GOOGLE_OS_TV_43]: 'Google OS',
};

window.VU_GROUP_SLUGS = {
  VUSTORE_CINEMA_TV_2024: 'vu-cinema-tv-2024',
  VUSTORE_MASTERPIECE_GLO_QLED_TV: 'vu-masterpiece-tv',
  VUSTORE_GLO_LED_TV: 'vu-glo-led-tv',
  VUSTORE_PREMIUM_GOOGLE_OS_TV: 'vu-premium-google-os-4k-tv',
  VUSTORE_PREMIUM_FHD_TV: 'vu-premium-fhd-tv',
  VUSTORE_MASTERPIECE_QLED_TV: 'vu-masterpiece-qled-tv',
  VUSTORE_VIBE_TV: 'vu-vibe-tv-43',
};

window.VU_GROUP_PRODUCT_MAP = {
  [VU_GROUP_SLUGS.VUSTORE_CINEMA_TV_2024]: [
    PRODUCT_SLUGS.VUSTORE_CINEMA_2024_43,
    PRODUCT_SLUGS.VUSTORE_CINEMA_2024_55,
  ],
  [VU_GROUP_SLUGS.VUSTORE_GLO_LED_TV]: [
    PRODUCT_SLUGS.VUSTORE_GLO_LED_TV_43,
    PRODUCT_SLUGS.VUSTORE_GLO_LED_TV_50,
    PRODUCT_SLUGS.VUSTORE_GLO_LED_TV_55,
    PRODUCT_SLUGS.VUSTORE_GLO_LED_TV_65,
  ],
  [VU_GROUP_SLUGS.VUSTORE_MASTERPIECE_GLO_QLED_TV]: [
    PRODUCT_SLUGS.VUSTORE_MASTERPIECE_TV_55,
    PRODUCT_SLUGS.VUSTORE_MASTERPIECE_TV_65,
    PRODUCT_SLUGS.VUSTORE_MASTERPIECE_TV_75,
  ],
  [VU_GROUP_SLUGS.VUSTORE_PREMIUM_GOOGLE_OS_TV]: [
    PRODUCT_SLUGS.VUSTORE_PREMIUM_GOOGLE_OS_TV_43,
    PRODUCT_SLUGS.VUSTORE_PREMIUM_GOOGLE_OS_TV_55,
  ],
  [VU_GROUP_SLUGS.VUSTORE_PREMIUM_FHD_TV]: [
    PRODUCT_SLUGS.VUSTORE_PREMIUM_FHD_TV_43,
  ],
  [VU_GROUP_SLUGS.VUSTORE_MASTERPIECE_QLED_TV]: [
    PRODUCT_SLUGS.VUSTORE_MASTERPIECE_QLED_TV_85,
    PRODUCT_SLUGS.VUSTORE_MASTERPIECE_QLED_TV_98,
  ],
  [VU_GROUP_SLUGS.VUSTORE_VIBE_TV]: [
    PRODUCT_SLUGS.VUSTORE_VIBE_TV_43,
    PRODUCT_SLUGS.VUSTORE_VIBE_TV_50,
    PRODUCT_SLUGS.VUSTORE_VIBE_TV_55,
    PRODUCT_SLUGS.VUSTORE_VIBE_TV_65,
  ],
};

window.nArray = (n) => [...Array(n).keys()].map((key) => key + 1);

window.IMAGE_RESOURCE_MAP = {
  [PRODUCT_SLUGS.VUSTORE_GLO_LED_TV_43]: nArray(72).map((index) =>
    getCdnUrl(
      `https://dukaan-us.s3.us-west-2.amazonaws.com/vu-images/43inch-vu-gloled-tv-360deg-images/${
        73 - index
      }.png`,
      700
    )
  ),
  [PRODUCT_SLUGS.VUSTORE_GLO_LED_TV_50]: nArray(72).map((index) =>
    getCdnUrl(
      `https://dukaan-us.s3.us-west-2.amazonaws.com/vu-images/VuGloLed360/${
        73 - index
      }.png`,
      700
    )
  ),
  [PRODUCT_SLUGS.VUSTORE_GLO_LED_TV_55]: nArray(72).map((index) =>
    getCdnUrl(
      `https://dukaan-us.s3.us-west-2.amazonaws.com/vu-images/VuGloLed360/${
        73 - index
      }.png`,
      700
    )
  ),
  [PRODUCT_SLUGS.VUSTORE_GLO_LED_TV_65]: nArray(72).map((index) =>
    getCdnUrl(
      `https://dukaan-us.s3.us-west-2.amazonaws.com/vu-images/VuGloLed360/${
        73 - index
      }.png`,
      700
    )
  ),
  [PRODUCT_SLUGS.VUSTORE_PREMIUM_GOOGLE_OS_TV_43]: nArray(72).map((index) =>
    getCdnUrl(
      `https://dukaan-us.s3.us-west-2.amazonaws.com/vu-images/VuPremium4kNew360Images/${
        73 - index
      }.png`,
      700
    )
  ),
  [PRODUCT_SLUGS.VUSTORE_PREMIUM_GOOGLE_OS_TV_55]: nArray(72).map((index) =>
    getCdnUrl(
      `https://dukaan-us.s3.us-west-2.amazonaws.com/vu-images/VuPremium4kNew360Images/${
        73 - index
      }.png`,
      700
    )
  ),
  [PRODUCT_SLUGS.VUSTORE_PREMIUM_FHD_TV_43]: nArray(72).map((index) =>
    getCdnUrl(
      `https://dukaan-us.s3.us-west-2.amazonaws.com/vu-images/Vu+Premium+FHD+TV+43+New/${
        73 - index
      }.png`,
      700
    )
  ),
  [PRODUCT_SLUGS.VUSTORE_MASTERPIECE_TV_55]: nArray(72).map((index) =>
    getCdnUrl(
      `https://dukaan.b-cdn.net/original/dukaan-media/vu-images/Vu%20Masterpiece%20Glo%20QLED%20TV/${
        73 - index
      }.jpg`,
      700
    )
  ),
  [PRODUCT_SLUGS.VUSTORE_MASTERPIECE_TV_65]: nArray(72).map((index) =>
    getCdnUrl(
      `https://dukaan.b-cdn.net/original/dukaan-media/vu-images/Vu%20Masterpiece%20Glo%20QLED%20TV/${
        73 - index
      }.jpg`,
      700
    )
  ),
  [PRODUCT_SLUGS.VUSTORE_MASTERPIECE_TV_75]: nArray(72).map((index) =>
    getCdnUrl(
      `https://dukaan.b-cdn.net/original/dukaan-media/vu-images/Vu%20Masterpiece%20Glo%20QLED%20TV/${
        73 - index
      }.jpg`,
      700
    )
  ),
  [PRODUCT_SLUGS.VUSTORE_VIBE_TV_43]: VUSTORE_VIBE_TV_43_IMAGES.map(
    (imageUrl) => imageUrl
  ),
  [PRODUCT_SLUGS.VUSTORE_VIBE_TV_50]: VUSTORE_VIBE_TV_43_IMAGES.map(
    (imageUrl) => imageUrl
  ),
  [PRODUCT_SLUGS.VUSTORE_VIBE_TV_55]: VUSTORE_VIBE_TV_43_IMAGES.map(
    (imageUrl) => imageUrl
  ),
  [PRODUCT_SLUGS.VUSTORE_VIBE_TV_65]: VUSTORE_VIBE_TV_65_IMAGES.map(
    (imageUrl) => imageUrl
  ),
};

window.WARRANTY_TEXT_MAP = {
  '1 Year Warranty': 'One year',
  '3 Years Warranty': 'Three years',
};

window.appInitializer = () => {
  window.BUY_NOW_TEXT =
    window.DukaanData.DUKAAN_LANGUAGE.ADD_TO_CART ?? 'Add to Cart';
  window.GO_TO_BAG_TEXT =
    window.DukaanData.DUKAAN_LANGUAGE.ADD_TO_CART ?? 'Add to Cart';

  druidProductPageView();
  GAPage();

  // setting active vu category tab item & bringing it into view
  const vuCategoryTabItems = window.q$.selectAll('.vu-category-tab-item').elem;
  [...vuCategoryTabItems].forEach((tab) => {
    if (
      tab.getAttribute('href').includes(window.DukaanData.DUKAAN_PRODUCT.slug)
    ) {
      tab.classList.add(
        'vu-category-tab-active-item',
        'text-decoration-underline'
      );
      tab.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  });

  // rendering pdp products
  const vuProductListingSection = window.q$.select(
    '.vu-pdp-product-listing-section'
  ).elem;
  const productListLoadPoint = window.q$.select(
    '.vu-pdp-product-listing-section product-list-mount-point'
  ).elem;

  const defaultActiveGroup =
    vuProductListingSection.getAttribute('data-active-group');
  const productSlugsToFetch = window.VU_GROUP_PRODUCT_MAP[defaultActiveGroup];

  const fetchVuPdpProducts = async () => {
    const request = (productSlug) =>
      fetch(
        `${window.DukaanData.CLIENT_API2_ENDPOINT}/api/product/buyer/${window.DukaanData.DUKAAN_STORE.link}/product/${productSlug}/v2/`,
        {
          method: 'GET',
        }
      ).catch((e) => console.log(e));

    const requests = productSlugsToFetch.map((productSlug) =>
      request(productSlug)
    );

    return Promise.all(requests).then((responses) =>
      Promise.all(responses.map((res) => res.json())).then((res) => {
        const products = res.map((r) => r.data);
        if (products?.length) {
          productListLoadPoint.innerHTML = '';
          products.forEach((prod, index) => {
            productCardRenderer(productListLoadPoint, prod, {
              templateId: 'dkn-pdp-product-card-template',
              additionalRenderer: vuProductCardAdditionalRenderer,
              getCustomOriginalPriceText: (originalPrice) =>
                `MRP : ${window.formatMoney(originalPrice)}`,
            });
            const productCard = window.q$.select(
              `.dkn-product-card[data-product-id='${prod.id}']`,
              productListLoadPoint
            ).elem;
            const product360Images = window.IMAGE_RESOURCE_MAP[prod.slug] || [];
            if (typeof dkn360ImageViewerInit === 'function')
              dkn360ImageViewerInit(productCard, product360Images, {
                clickHandlerTargetSelector: '.dkn-product-card-image-wrapper',
                percentageTextSelector: '.dkn-360-image-viewer-percentage',
                elementToReplace: '.dkn-product-card-image',
              });

            const splideParent = q$
              .select('.dkn-product-card-splide', productCard)
              .setAttribute('id', `splide-${index}-${prod.slug}`).elem;

            if (prod?.all_images?.length > 1 && splideParent) {
              const splideList = q$.select(
                '.dkn-product-card-splide-list',
                splideParent
              ).elem;
              prod?.all_images?.forEach((image) => {
                const imageCard = q$
                  .selectById('splide-image-template')
                  .getTemplateContent().elem;
                q$.select('.dkn-product-card-image', imageCard).setAttribute(
                  'src',
                  getCdnUrl(image, 800)
                );
                splideList.appendChild(imageCard);
              });
              const productCardSplide = new Splide(
                `#splide-${index}-${prod.slug}`,
                {
                  type: 'slide',
                  autoplay: false,
                  pagination: true,
                  arrows: true,
                  drag: false,
                  perPage: 1,
                }
              );
              productCardSplide.mount();
            }
          });
          const paramString = new URLSearchParams(window.location.search);
          const productSlug = paramString.get('product_slug');

          if (productSlug) {
            q$.select(
              `product-list-mount-point .dkn-product-card[data-product-slug="${productSlug}"]`
            ).elem?.scrollIntoView({ behavior: 'smooth', block: 'center' });
          }
        } else {
          productListLoadPoint.classList.add('hidden');
        }
      })
    );
  };

  fetchVuPdpProducts();
};

window.vuProductCardAdditionalRenderer = (productCard, product, options) => {
  if (
    COMING_SOON_PRODUCTS.includes(product.slug) ||
    DIWALI_LAUNCH_PRODUCTS.includes(product.slug)
  ) {
    window.q$
      .select('.dkn-product-card-coming-soon-text', productCard)
      .removeClass('hidden');
  }
  if (!product.in_stock) {
    window.q$.select('.dkn-sold-out-label', productCard).removeClass('hidden');
  }
  if (product.in_stock && VIEW_ONLY_PRODUCTS.includes(product.slug)) {
    window.q$.select('.pdp-button-wrapper', productCard).addClass('hidden');
  }

  window.q$
    .select('.dkn-product-card-resolution-value', productCard)
    .modifyTextContent(`Resolution: ${RESOLUTION_MAP[product.slug]}`);

  if (OS_MAP[product.slug]) {
    window.q$
      .select('.dkn-product-card-operating-system-value', productCard)
      .modifyTextContent(`OS: ${OS_MAP[product.slug] || 'Official Android'}`);
  } else {
    window.q$
      .select('.dkn-product-card-operating-system-value-wrapper', productCard)
      .addClass('hidden');
  }
  window.q$
    .select('.dkn-product-card-warranty-text', productCard)
    .modifyTextContent(
      `${
        WARRANTY_TEXT_MAP[
          window.DukaanData.DUKAAN_PRODUCT.slug === 'vu-vibe-tv-43'
            ? '1 Year Warranty'
            : '3 Years Warranty'
        ]
      } brand warranty` // TODO : get from active sku ka value
    );
  const variantFormElement = window.q$.select(
    '.dkn-variant-selection-form-wrapper',
    productCard
  ).elem;
  const actionButtonsElements = window.q$.selectAll(
    '.pdp-button-wrapper',
    productCard
  ).elem;

  window.q$
    .selectAll('.dkn-product-card', productCard)
    .setAttributeAll('data-product-slug', `${product.slug}`);

  retrieveVuProductSKUs(product, () => {}, {
    variantFormElement,
    actionButtonsElements,
  });
};

window.retrieveVuProductSKUs = (
  productFromClient,
  successCallback = () => {},
  options = {}
) => {
  fetch(
    `${window.DukaanData.CLIENT_API2_ENDPOINT}/api/product/buyer/${productFromClient.id}/product-details/`,
    {
      method: 'get',
      headers: {
        'Content-Type': 'application/json',
        'x-requested-with': window?.DukaanData?.DUKAAN_SESSION_ID,
      },
    }
  )
    .then((res) => res.json())
    .then((res) => {
      const skus = res?.data.skus || [];
      const rawProduct = {
        ...productFromClient,
        skus,
        skusApi: true,
      };
      dknAddProductsToProductsMap([rawProduct]);
      const product = DukaanData.PRODUCTS_MAP[productFromClient.uuid];
      const activeSKU = dknGetFirstAvailableSKU(product.skus);
      const key = 'productPage';
      const productUUID = product.uuid;
      const productContext = {
        key,
        productUUID,
        skuUUID: activeSKU.uuid,
      };
      const renderAddons = DukaanData.DUKAAN_STORE.store_category === 6;
      const { variantFormElement, actionButtonsElements } = options;

      if (variantFormElement) {
        variantFormElement.innerHTML = '';
        dknRenderProductVariantForm(productContext, variantFormElement, {
          renderAddons,
        });
      }

      actionButtonsElements?.forEach((actionButtonsElement) => {
        actionButtonsElement.innerHTML = '';
        actionButtonsElement.appendChild(
          window.q$.selectById('pdp-button-wrapper').getTemplateContent().elem
        );
        dknRenderActionButtons(productContext, actionButtonsElement);
      });

      dknViewContentEvent(activeSKU, product);
      successCallback();
    })
    .catch((err) => {
      console.log(`retrieveProductSKUs error : ${err}`);
      if (typeof options.errorCallback === 'function') {
        options.errorCallback();
      }
    });
};
