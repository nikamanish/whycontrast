window.appInitializer = () => {
  const splide = new Splide('#hero-splide-banner', {
    arrows: false,
    autoplay: true,
    type: 'loop',
    pagination: false,
    interval: 3000,
  });
  splide.mount();
};
