window.productCardTemplateId = 'dkn-product-card-template';

window.getCustomVariantsConfig = (productContext) => {
  const getVariantHeading = ({ attrLabel }) => `Brand warranty`; // TODO: get this added from seller side

  return {
    size: { getVariantHeadingFn: getVariantHeading },
    color: { getVariantHeadingFn: getVariantHeading },
  };
};

// custom dropdown
window.toggleDropdown = (evt) => {
  // window.toggleSortByChevronIconsForDropdown({ evt });
  const dropdownElem = evt.currentTarget;
  const dropdownContentElem = dropdownElem.children[1];

  if (dropdownContentElem) {
    if (dropdownContentElem.classList.contains('d-none')) {
      dropdownContentElem.classList.remove('d-none');
    } else {
      dropdownContentElem.classList.add('d-none');
    }
  }
};

window.sortByDropdownClickHandler = (evt, sortType, callback = () => {}) => {
  const payload = window.getPayloadDataFromFilters();
  payload[window.filterCategoryParams.SORT_BY] = sortType;
  const url = new URL(window.location);
  url.searchParams.set(window.filterCategoryParams.SORT_BY, sortType);
  url.searchParams.set(window.filterCategoryParams.PAGE_NUMBER, 1);
  window.history.replaceState({}, '', url);
  window.getProductCards(payload, 1);
  callback(sortType, evt);
};

window.sortDropDownHandler = (sortBy, evt) => {
  window.q$
    .selectAll('.dkn-dropdown-sort-radio-button')
    .removeClassAll('selected');
  window.q$.selectAll('.dkn-dropdown-sort-label').removeClassAll('selected');

  const selectedOption = window.q$.select(
    `.dkn-dropdown-option[value="${sortBy}"]`
  ).elem;

  if (selectedOption) {
    window.q$
      .select('.dkn-dropdown-sort-radio-button', selectedOption)
      .addClass('selected');
    window.q$
      .select('.dkn-dropdown-sort-label', selectedOption)
      .addClass('selected');
  }
  window.q$
    .select('.dkn-sort-by-selected-option-label')
    .modifyTextContent(window.getSortTypeText(sortBy));
  const dropdownEl = evt.currentTarget.offsetParent.offsetParent;
  // window.toggleSortByChevronIconsForDropdown({ dropdownEl });
  evt.currentTarget.offsetParent.classList.add('d-none');
};

window.getSortTypeText = (ordering) => {
  switch (ordering) {
    case 'bestsellers':
      // return 'Relevance';
      return DukaanData.DUKAAN_LANGUAGE.RELEVANCE;
    case 'better_discount':
      // return 'Discount';
      return DukaanData.DUKAAN_LANGUAGE.DISCOUNT;
    case 'price_low_to_high':
      // return 'Price - low to high';
      return DukaanData.DUKAAN_LANGUAGE.PRICE_LOW_TO_HIGH;
    case 'price_high_to_low':
      // return 'Price - high to low';
      return DukaanData.DUKAAN_LANGUAGE.PRICE_HIGH_TO_LOW;
    default:
      // return 'Relevance';
      return DukaanData.DUKAAN_LANGUAGE.RELEVANCE;
  }
};

window.toggleShowHideFilter = (evt, targetSelector) => {
  const upIcon = evt.currentTarget.firstElementChild;
  const downIcon = evt.currentTarget.lastElementChild;

  const targetElem =
    evt.currentTarget.parentNode.parentElement.querySelector(targetSelector);

  // open
  if (targetElem.classList.contains('d-none')) {
    targetElem.classList.remove('d-none');
    upIcon.classList.remove('d-none');
    downIcon.classList.add('d-none');
  } else {
    // close
    targetElem.classList.add('d-none');
    upIcon.classList.add('d-none');
    downIcon.classList.remove('d-none');
  }
};

window.customAdvanceFiltersConfig = {
  priceFieldRoundingFactor: 25000,
};
